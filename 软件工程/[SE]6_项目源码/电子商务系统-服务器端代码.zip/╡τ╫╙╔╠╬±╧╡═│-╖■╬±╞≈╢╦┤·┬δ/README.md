# SoftwareProject

文件夹**backend**中为此次软工大程后端的代码

### backend

1. 目前的几点说明
   - backend\src\db.js 第6行，填写mysql数据库root用户的密码。
   - 后端使用的语言是JavaScript，使用的数据库是MySQL。
   - 在存储图片信息时，会在与 backend 平行的目录下创建一个 assets 目录，请勿删除。
2. 编译运行指南
   1. 在第一次编译运行时，先在 backend目录下运行 `npm install`，安装相应的依赖包。
   2. 在第一次编译运行时，需要在MySQL中创建数据库和数据表，所以要先在 backend\src 目录下运行 `node initDB.js`。在之后的操作中，如果不涉及创建数据表，则不需要再运行该文件。
   3. 启动后端服务器时，在 backend 目录下运行 `npm run serve`。
