import  express  from "express";
import { Buffer } from 'buffer';

import {loginRes,registerRes,displayUserInformationRes,modifyUserInformationRes,BalanceInquiryRes,InvestMoneyRes} from "./UserManagement.js";
import {CreateGoodsRes,DeleteGoodsRes,ModifyGoodsRes,ShowUserGoodsRes,ShowGoodsByTypeRes,ShowGoodsByNameRes,ShowGoodsByIdRes} from "./GoodsManagement.js"
import {UserAddLikeRes,UserShowLikeRes,UserDeleteLikeRes,InLikeRes} from "./GoodsManagement.js"
import {BuyGoodRes,DeliveryGoodRes,ReceiptGoodRes,ShowBuyerOrdersRes,ShowSellerOrdersRes} from "./OrderManagement.js"
import {ShowAllUserRes} from "./Admin.js"

const router = express.Router()


/*
    模块1：用户信息模块
*/

// 子模块1-1：注册用户
router.post('/register', registerRes);

//子模块1-2：登录系统
router.post('/login', loginRes);

//子模块1-3：修改信息
//子模块1-3-1：显示用户信息
router.post('/displayUserInformation', displayUserInformationRes);

//子模块1-3-2：修改用户信息
router.post('/modifyUserInformation', modifyUserInformationRes);

/*
  模块2：商品信息模块
*/

//子模块2-1：单个商品操作
//子模块2-1-1：创建商品(商品上架)
router.post('/CreateGoods', CreateGoodsRes);

//子模块2-1-2：下架商品
router.post('/DeleteGoods', DeleteGoodsRes);
      
//子模块2-1-3：编辑修改商品
router.post('/ModifyGoods', ModifyGoodsRes);

//子模块2-2：展示多个商品

//子模块2-2-1：卖方归属商品展示
router.post('/ShowUserGoods', ShowUserGoodsRes);

//子模块2-2-2：按类商品展示
//notice: type === 0时，表示展示全部商品
router.post('/ShowGoodsByType', ShowGoodsByTypeRes);

//子模块2-2-3：查找商品展示
router.post('/ShowGoodsByName', ShowGoodsByNameRes);

//子模块2-2-4：按ID检索商品
router.post('/ShowGoodsById', ShowGoodsByIdRes);

//子模块2-3：收藏管理

//子模块2-3-1：添加收藏商品
router.post('/UserAddLike', UserAddLikeRes);

//子模块2-3-2：展示收藏商品
router.post('/UserShowLike', UserShowLikeRes);

//子模块2-3-3：删除收藏商品
router.post('/UserDeleteLike', UserDeleteLikeRes);

//子模块2-3-4：查看商品是否被收藏
router.post('/InLike', InLikeRes);

/*
  模块3：商品交易模块
*/

//子模块3-1：订单管理
//子模块3-1-1：买家创建订单
router.post('/BuyGood', BuyGoodRes);

//子模块3-1-2：卖家发货
router.post('/DeliveryGood', DeliveryGoodRes);

//子模块3-1-3：买家确认收货
router.post('/ReceiptGood', ReceiptGoodRes);

//子模块3-2：订单查看

//子模块3-2-1：买家查看订单
router.post('/ShowBuyerOrders', ShowBuyerOrdersRes);

//子模块3-2-2：卖家查看订单
router.post('/ShowSellerOrders', ShowSellerOrdersRes);

/*
  模块4：储值管理模块
*/

//子模块4-1：用户余额查询
router.post('/BalanceInquiry', BalanceInquiryRes);

//子模块4-2：充值
router.post('/InvestMoney', InvestMoneyRes);

/*
  模块5：管理员模块
*/

//模块5-1：用户列表展示
router.post('/ShowAllUser', ShowAllUserRes);

export default router;