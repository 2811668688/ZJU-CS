import { nanoid } from 'nanoid';
import {jsonWrite,tmkdir,storePhoto,getPhoto} from "./utils.js";
import conn from "./db.js";

/*
  模块5：管理员模块
*/

//组装展示多个用户信息数据包
const displaySomeUsers = function(sqlresult) {
	let i;
	let users = [];

	for (i=0;i<sqlresult.length;i++){
		let userinfo = {};
		
		userinfo.userid = sqlresult[i].userid;
		userinfo.user_phone = sqlresult[i].user_phone;
		userinfo.password = sqlresult[i].password;
		userinfo.username = sqlresult[i].username;
		userinfo.mail = sqlresult[i].mail;
		userinfo.personid = sqlresult[i].personid;
		userinfo.gender = sqlresult[i].gender;
		userinfo.birthday = sqlresult[i].birthday;
		userinfo.location = sqlresult[i].location;
		userinfo.postCode = sqlresult[i].postCode;
		userinfo.savings = sqlresult[i].savings;
		let res_photo = {};
		getPhoto(sqlresult[i].userid,res_photo);
		userinfo.picture = res_photo.photo;
		users.push(userinfo);
	}
	// console.log("in displaySomeGoods - goods: ",goods);
	return users;
}

export const ShowAllUserRes = (req, res)=>{
  let users = [];
  let sql;
  let errmark = 0;

  //step1 -- 查询users
  sql = "SELECT userid,user_phone,password,username,mail,personid,gender,birthday,\
        location,postcode as postCode,savings FROM users";
  conn.query(sql, [], function (err, result) {
    if(err) {
      jsonWrite(res, {msg: "Database error: " + err.sqlMessage});
    }
    else if (result && result.length === 0) {
      jsonWrite(res, {
        msg: "Fail",
        userInfors: undefined
      });
      errmark=1;
    }
    else{
      users = displaySomeUsers(result);
      jsonWrite(res, {
        msg: "Succeed",
        userInfors: users
      });
    }
  })
};
