import { nanoid } from 'nanoid';
import moment from 'moment';
import {jsonWrite,tmkdir,storePhoto,getPhoto} from "./utils.js";
import conn from "./db.js";

/*
  模块3：商品交易模块
*/

//子模块3-1：订单管理
//子模块3-1-1：买家创建订单
export const BuyGoodRes = (req, res)=>{
	const orderid = nanoid(15);
	const buyerid = req.body.buyerid;
	const goodid = req.body.goodid;
	const buynum = req.body.buynum;
	let errmark = 0;
	let sql;
	let ordertime = moment().format('YYYY-MM-DD HH:mm:ss');

	//step1 -- 判断商品是否存在、库存是否充足
	sql = "SELECT storage_amount,price,sellerid FROM goods WHERE goodid = ?";
	conn.query(sql, [goodid], function(err, result){
		if(err) {
			jsonWrite(res, {msg: "Database error1: " + err.sqlMessage});
		}
		else if (result && result.length === 0) {
			jsonWrite(res, {
				msg: "Good not exist",
				orderid: undefined
			});
			errmark=1;
		}
		else if (result && result[0].storage_amount < buynum ) {
			jsonWrite(res, {
				msg: "Good out of stock",
				orderid: undefined
			});
			errmark=1;
		}
		//step2 -- 判断买家是否存在、存款是否充足
		sql = "SELECT savings FROM users WHERE userid = ?";
		if (errmark === 0){
			conn.query(sql, [buyerid], function(err, result1){
				if(err) {
					jsonWrite(res, {msg: "Database error2: " + err.sqlMessage});
				}
				else if (result1 && result1.length === 0) {
					jsonWrite(res, {
						msg: "Buyer not exist",
						orderid: undefined
					});
					errmark=1;
				}
				else if (result1 && result1[0].savings < buynum*result[0].price ) {
					jsonWrite(res, {
						msg: "Insufficient fund",
						orderid: undefined
					});
					errmark=1;
				}
				else{
					//step3 -- 创建订单
					sql = "INSERT INTO orders (orderid,sellerid,buyerid,goodid,buynum,ordertime) value (?,?,?,?,?,?)";
					conn.query(sql, [orderid,result[0].sellerid,buyerid,goodid,buynum,ordertime], function(err, result2){
						if(err) {
							jsonWrite(res, {msg: "Database error3: " + err.sqlMessage});
						}
						else if (result2) {
							jsonWrite(res, {
								msg: "Success",
								orderid: orderid
							});
							//step4 -- 修改用户储值
							sql = "UPDATE users SET savings = ? where userid = ?";
							conn.query(sql, [result1[0].savings - buynum*result[0].price, buyerid], function(err, result3){
								if(err) {
									jsonWrite(res, {msg: "Database error4: " + err.sqlMessage});
								}
							})
						}
					})
				}
			})
		}
	})
};

//子模块3-1-2：卖家发货
export const DeliveryGoodRes = (req, res)=>{
  const orderid = req.body.orderid;
  let errmark = 0;
  let sql;
  
  //step1 -- 查询订单是否存在
  sql = "SELECT buynum,goodid FROM orders WHERE orderid = ?";
  conn.query(sql, [orderid], function (err, result0) {
    if(err) {
      jsonWrite(res, {msg: "Database error: " + err.sqlMessage});
    }
    else if (result0 && result0.length === 0) {
      jsonWrite(res, {
        msg: "Order not found"
      });
      errmark=1;
    }
    else{
      //step2 -- 修改订单状态
      sql = "UPDATE orders SET state = 1 where orderid = ?";
      conn.query(sql, [orderid], function (err, result1) {
        if(err) {
          jsonWrite(res, {msg: "Database error: " + err.sqlMessage});
          errmark = 1;
        }
        else if (errmark === 0){
          //step3 -- 修改商品库存
          sql = "SELECT storage_amount FROM goods WHERE goodid = ?";
          conn.query(sql, [result0[0].goodid], function(err, result2){
            if(err) {
              jsonWrite(res, {msg: "Database error: " + err.sqlMessage});
            }
            else{
              sql = "UPDATE goods SET storage_amount = ? where goodid = ?";
              conn.query(sql, [result2[0].storage_amount - result0[0].buynum, result0[0].goodid], function(err, result3){
                if(err) {
                  jsonWrite(res, {msg: "Database error: " + err.sqlMessage});
                }
                else{
                  jsonWrite(res, {
                    msg: "Succeed"
                  });
                }
              })
            }
          })
        }
      })
    }
  })
};

//子模块3-1-3：买家确认收货
export const ReceiptGoodRes = (req, res)=>{
  const orderid = req.body.orderid;
  let errmark = 0;
  let sql;
  
  //step1 -- 查询订单是否存在
  sql = "SELECT buynum,sellerid,goodid,state FROM orders WHERE orderid = ?";
  conn.query(sql, [orderid], function (err, result0) {
    if(err) {
      jsonWrite(res, {msg: "Database error: " + err.sqlMessage});
    }
    else if (result0 && result0.length === 0) {
      jsonWrite(res, {
        msg: "Order not found"
      });
      errmark=1;
    }
    else if (result0 && result0[0].state !== 1) {
      jsonWrite(res, {
        msg: "Order state Incorrect"
      });
      errmark=1;
    }
    else{
      //step2 -- 修改订单状态
      sql = "UPDATE orders SET state = 2 where orderid = ?";
      conn.query(sql, [orderid], function (err, result1) {
        if(err) {
          jsonWrite(res, {msg: "Database error: " + err.sqlMessage});
          errmark = 1;
        }
        else if (errmark === 0){
          //step3 -- 查询商品单价
          sql = "SELECT price FROM goods WHERE goodid = ?";
          conn.query(sql, [result0[0].goodid], function(err, result2){
            if(err) {
              jsonWrite(res, {msg: "Database error: " + err.sqlMessage});
              errmark = 1;
            }
            else{
              //step4 -- 修改卖家储值
              sql = "SELECT savings FROM users WHERE userid = ?";
              conn.query(sql, [result0[0].sellerid], function(err, result3){
                if(err) {
                  jsonWrite(res, {msg: "Database error: " + err.sqlMessage});
                  errmark = 1;
                }
                else{
                  sql = "UPDATE users SET savings = ? where userid = ?";
                  conn.query(sql, [result3[0].savings + result0[0].buynum*result2[0].price, result0[0].sellerid], function(err, result4){
                    if(err) {
                      jsonWrite(res, {msg: "Database error: " + err.sqlMessage});
                    }
                    else{
                      jsonWrite(res, {
                        msg: "Succeed"
                      });
                    }
                  })
                }
              })
            }
          })  
        }
      })
    }
  })
};

//子模块3-2：订单查看
//组装展示多个订单数据包
const displaySomeOrders = function(sqlresult) {
  let i;
  let orders = [];

  for (i=0;i<sqlresult.length;i++){
    let orderinfo = {};
    
    orderinfo.orderid = sqlresult[i].orderid;
    orderinfo.orderstate = sqlresult[i].orderstate;
    orderinfo.buyerid = sqlresult[i].buyerid;
    orderinfo.sellerid = sqlresult[i].sellerid;
    orderinfo.goodid = sqlresult[i].goodid;
    orderinfo.goodname = sqlresult[i].goodname;
    orderinfo.buytime = sqlresult[i].buytime;
    orderinfo.unitprice = sqlresult[i].unitprice;
    orderinfo.goodnum = sqlresult[i].goodnum;
    orderinfo.totalprice = sqlresult[i].unitprice * sqlresult[i].goodnum;
    let res_photo = {};
    getPhoto(sqlresult[i].goodid,res_photo);
    orderinfo.picture = res_photo.photo;
    orders.push(orderinfo);
  }
  // console.log("in displaySomeGoods - goods: ",goods);
  return orders;
}

//子模块3-2-1：买家查看订单
export const ShowBuyerOrdersRes = (req, res)=>{
  const buyerid = req.body.userid;
  let orders = [];
  let sql;
  let errmark = 0;

  //step1 -- 查询users, 判定userid是否存在
  sql = "SELECT username FROM users WHERE userid=?";
  conn.query(sql, [buyerid], function (err, result) {
    if(err) {
      jsonWrite(res, {msg: "Database error: " + err.sqlMessage});
    }
    else if (result && result.length === 0) {
      jsonWrite(res, {
        msg: "User not found",
        buyerOrders: undefined
      });
      errmark=1;
    }
    else{
      //step2 -- 查询orders, 判断当前seller是否有订单
      sql = "SELECT orderid FROM orders WHERE buyerid=?";
      conn.query(sql, [buyerid], function (err, result) {
        if(err) {
          jsonWrite(res, {msg: "Database error: " + err.sqlMessage});
        }
        else if (result && result.length === 0) {
          jsonWrite(res, {
            msg: "No orders"
          });
          errmark = 1;
        }
        else{
          //step3 -- 返回当前seller的全部订单
          sql = "SELECT orders.orderid as orderid, orders.state as orderstate, orders.buyerid as buyerid,\
                orders.sellerid as sellerid, orders.goodid as goodid, orders.ordertime as buytime,\
                orders.buynum as goodnum, goods.goodname as goodname, goods.price as unitprice \
                FROM orders INNER JOIN goods ON orders.goodid = goods.goodid WHERE orders.buyerid=?";
          conn.query(sql, [buyerid], function (err, result) {
            if(err) {
              jsonWrite(res, {msg: "Database error: " + err.sqlMessage});
            }
            else{
              orders = displaySomeOrders(result);
              jsonWrite(res, {
                msg: "Succeed",
                buyerOrders: orders
              });
            }
          });
        }
      });
    }
  })
};

//子模块3-2-2：卖家查看订单
export const ShowSellerOrdersRes = (req, res)=>{
  const sellerid = req.body.userid;
  let orders = [];
  let sql;
  let errmark = 0;

  //step1 -- 查询users, 判定userid是否存在
  sql = "SELECT username FROM users WHERE userid=?";
  conn.query(sql, [sellerid], function (err, result) {
    if(err) {
      jsonWrite(res, {msg: "Database error: " + err.sqlMessage});
    }
    else if (result && result.length === 0) {
      jsonWrite(res, {
        msg: "User not found",
        sellerOrders: undefined
      });
      errmark=1;
    }
    else{
      //step2 -- 查询orders, 判断当前seller是否有订单
      sql = "SELECT orderid FROM orders WHERE sellerid=?";
      conn.query(sql, [sellerid], function (err, result) {
        if(err) {
          jsonWrite(res, {msg: "Database error: " + err.sqlMessage});
        }
        else if (result && result.length === 0) {
          jsonWrite(res, {
            msg: "No orders",
            sellerOrders: undefined
          });
          errmark = 1;
        }
        else{
          //step3 -- 返回当前seller的全部订单
          sql = "SELECT orders.orderid as orderid, orders.state as orderstate, orders.buyerid as buyerid,\
                orders.sellerid as sellerid, orders.goodid as goodid, orders.ordertime as buytime,\
                orders.buynum as goodnum, goods.goodname as goodname, goods.price as unitprice \
                FROM orders INNER JOIN goods ON orders.goodid = goods.goodid WHERE orders.sellerid=?";
          conn.query(sql, [sellerid], function (err, result) {
            if(err) {
              jsonWrite(res, {msg: "Database error: " + err.sqlMessage});
            }
            else{
              orders = displaySomeOrders(result);
              jsonWrite(res, {
                msg: "Succeed",
                sellerOrders: orders
              });
            }
          });
        }
      });
    }
  })
};


