import fs from "fs";

export const jsonWrite = function (res, ret) {
	if (typeof ret === 'undefined') {
		res.json({
			code: '1', msg: '操作失败'
		})
	} else {
		res.json(ret)
	}
}

export const tmkdir = function(dirname) {
	if (fs.existsSync(dirname)) {
		return true;
	} else if(fs.mkdirSync(dirname, {recursive: true})) {
		return true;
	} else {
		return false;
	}
}

//存图像
export const storePhoto = function(passname,photo) {
	const directory = "../assets/"+passname+"/";
	const filename = "image-"+passname;
	let errmark = 0;
	
	if(!tmkdir(directory)) {
		jsonWrite(res, {msg: "Cannot create directory for photo"});
		return;
	}
	else{
		fs.writeFile(directory+filename, photo, "utf-8", function(err) {
			if(err){
				jsonWrite(res, {msg: "photo store error: " + err});
				errmark = 1;
			}
		});
	}  
	return errmark;
}

//取图像
export const getPhoto = function(passname,res) {
	const directory = "../assets/"+passname+"/";
	const filename = "image-"+passname;

	if(!fs.existsSync(directory+filename)) {
		res.photo = undefined;
		// console.log(1);
	}
	else{
		res.photo = fs.readFileSync(directory+filename, 'utf-8');
	}
}

export default {
	jsonWrite, tmkdir, storePhoto, getPhoto
}