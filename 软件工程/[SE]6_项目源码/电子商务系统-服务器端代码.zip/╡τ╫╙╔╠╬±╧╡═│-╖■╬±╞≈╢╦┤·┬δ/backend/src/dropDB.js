// 1 引入
import mysql from "mysql";
// 2 创建链接配置
const conn = mysql.createConnection({
    host:'localhost',   // 主机名 （服务器地址）
    user:'root',    //用户名
    password:'1897Zd2020',    // 密码
    port: 3306,
})

console.log("conn:", conn);

const queryFeedback = (err, result) => {
    if(err){
        // console.log(err);
        return
    }
    // 显示处理结果
    // console.log("success!result:",result);
};

// conn.query("use online_shopping;", queryFeedback);
conn.query("use online_shopping1;", queryFeedback);

conn.query("drop table savings;", queryFeedback);

conn.query("drop table collections;", queryFeedback);

conn.query("drop table loads_unloads;", queryFeedback);

conn.query("drop table orders;", queryFeedback);

conn.query("drop table goods;", queryFeedback);

conn.query("drop table users;", queryFeedback);

// conn.query("drop database online_shopping;", queryFeedback);
conn.query("drop database online_shopping1;", queryFeedback);
