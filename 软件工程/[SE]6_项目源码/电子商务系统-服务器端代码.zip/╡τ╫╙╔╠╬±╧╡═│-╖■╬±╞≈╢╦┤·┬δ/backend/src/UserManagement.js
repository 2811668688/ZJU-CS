import { nanoid } from 'nanoid';
import {jsonWrite,tmkdir,storePhoto,getPhoto} from "./utils.js";
import conn from "./db.js";

/*
    模块1：用户信息模块
*/

// 子模块1-1：注册用户
export const registerRes = (req, res)=>{
	const userid = nanoid(15);
	const user_phone = req.body.user_phone;
	const password = req.body.password;
  const username = req.body.username;
  const mail = req.body.mail;

	const sql = "INSERT INTO users (userid,user_phone,password,username,mail) value (?,?,?,?,?)";

	conn.query(sql, [userid,user_phone,password,username,mail], function(err, result){
			if(!err) {
			jsonWrite(res, {msg: "Succeed"});
			return;
			} else if(err.code === "ER_DUP_ENTRY") {
			jsonWrite(res, {msg: "Telephone number exists"});
			}
	})
};

//子模块1-2：登录系统
export const loginRes = (req, res) => {
  const req_phone = req.body.user_phone;
  const req_password = req.body.password;
  const sql = "SELECT password, user_phone, userid FROM users WHERE user_phone=?";
  conn.query(sql, [req_phone], function (err, result) {
    if (err) {
      // console.log(err)
    }
    if (result && result.length === 1) {
      if (result[0].password === req_password) {
        jsonWrite(res, {
          msg: "Succeed", 
          userid: result[0].userid,
        });
      }
      else {
        jsonWrite(res, {
          msg: "Password error"
        });
      }
    } else {
      jsonWrite(res, {
        msg: "Telephone not found"
      });
    }
  })
};

//子模块1-3：修改信息
//子模块1-3-1：显示用户信息
export const displayUserInformationRes = (req, res) => {
  const userid = req.body.userid;
  const sql = "SELECT * FROM users WHERE userid=?";
  let user_phone, password, username, mail, personid, gender, birthday, location, postCode, photo;
  let res_photo = {};

  conn.query(sql, [userid], function (err, result) {
    if (err) {
      // console.log(err);
      jsonWrite(res, {msg: "Database error: " + err.sqlMessage});
    }
    if (result && result.length === 1) {
      user_phone = result[0].user_phone;
      password = result[0].password;
      gender = result[0].gender;
      if (result[0].username !== null){
        username = result[0].username;
      }else{
        username = undefined;
      }
      if (result[0].mail !== null){
        mail = result[0].mail;
      }else{
        mail = undefined;
      }
      if (result[0].personid !== null){
        personid = result[0].personid;
      }else{
        personid = undefined;
      }
      if (result[0].birthday !== null){
        birthday = result[0].birthday;
      }else{
        birthday = undefined;
      }
      if (result[0].location !== null){
        location = result[0].location;
      }else{
        location = undefined;
      }
      if (result[0].postcode !== null){
        postCode = result[0].postCode;
      }else{
        postCode = undefined;
      }

      //console.log("before getphoto");
      photo = getPhoto(userid,res_photo);
      //console.log("after getphoto");
      //console.log("display中photo = "+res_photo.photo);

      jsonWrite(res, {
        msg: "Succeed",
        userid: userid,
        password: password,
        username: username,
        mail: mail,
        personid: personid,
        gender: gender,
        birthday: birthday,
        location: location,
        postCode: postCode,
        photo: res_photo.photo});
    }
  });
};

//子模块1-3-2：修改用户信息
export const modifyUserInformationRes = (req, res) => {
  const userid = req.body.userid;
  const new_password = req.body.password;
  const new_username = req.body.username;
  const new_mail = req.body.mail;
  const new_personid = req.body.personid;
  const new_gender = req.body.gender;
  const new_birthday = req.body.birthday;
  const new_location = req.body.location;
  const new_postCode = req.body.postCode;
  const new_photo = req.body.photo;

  //console.log(new_photo);

  let sql;
  let errmark = 0;
  if (new_password !== undefined){
    sql = "UPDATE users SET password=? WHERE userid=?;";
    conn.query(sql, [new_password,userid], function (err, result) {
      if(err) {
        jsonWrite(res, {msg: "Database error: " + err.sqlMessage});
        errmark = 1;
      }
    })
  }
  if (new_username !== undefined){
    sql = "UPDATE users SET username=? WHERE userid=?;";
    conn.query(sql, [new_username,userid], function (err, result) {
      if(err) {
        jsonWrite(res, {msg: "Database error: " + err.sqlMessage});
        errmark = 1;
      }
    })
  }
  if (new_mail !== undefined){
    sql = "UPDATE users SET mail=? WHERE userid=?;";
    conn.query(sql, [new_mail,userid], function (err, result) {
      if(err) {
        jsonWrite(res, {msg: "Database error: " + err.sqlMessage});
        errmark = 1;
      }
    })
  }
  if (new_personid !== undefined){
    sql = "UPDATE users SET personid=? WHERE userid=?;";
    conn.query(sql, [new_personid,userid], function (err, result) {
      if(err) {
        jsonWrite(res, {msg: "Database error: " + err.sqlMessage});
        errmark = 1;
      }
    })
  }
  if (new_gender !== undefined){
    sql = "UPDATE users SET gender=? WHERE userid=?;";
    conn.query(sql, [new_gender,userid], function (err, result) {
      if(err) {
        jsonWrite(res, {msg: "Database error: " + err.sqlMessage});
        errmark = 1;
      }
    })
  }
  if (new_birthday !== undefined){
    sql = "UPDATE users SET birthday=? WHERE userid=?;";
    conn.query(sql, [new_birthday,userid], function (err, result) {
      if(err) {
        jsonWrite(res, {msg: "Database error: " + err.sqlMessage});
        errmark = 1;
      }
    })
  }
  if (new_location !== undefined){
    sql = "UPDATE users SET location=? WHERE userid=?;";
    conn.query(sql, [new_location,userid], function (err, result) {
      if(err) {
        jsonWrite(res, {msg: "Database error: " + err.sqlMessage});
        errmark = 1;
      }
    })
  }
  if (new_postCode !== undefined){
    sql = "UPDATE users SET postcode=? WHERE userid=?;";
    conn.query(sql, [new_postCode,userid], function (err, result) {
      if(err) {
        jsonWrite(res, {msg: "Database error: " + err.sqlMessage});
        errmark = 1;
      }
    })
  }
  if (new_photo !== undefined){
    storePhoto(userid,new_photo);
  }
  if (errmark === 0){
    jsonWrite(res, {msg: "Succeed"});
  }
};

/*
  模块4：储值管理模块
*/

//子模块4-1：用户余额查询
export const BalanceInquiryRes = (req, res)=>{
  const userid = req.body.userid;
  let sql;

  sql = "SELECT savings FROM users WHERE userid = ?";
  conn.query(sql, [userid], function (err, result) {
    if (result && result.length === 0) {
      jsonWrite(res, {
        msg: "User not exist",
        savings: undefined
      });
    } else {
      jsonWrite(res, {
        msg: "Succeed",
        savings: result[0].savings
      });
    }
  })
};

//子模块4-2：充值
export const InvestMoneyRes = (req, res)=>{
  const userid = req.body.userid;
  const investnum = req.body.investnum;
  let sql;

  //step1 -- 判断用户是否存在并获取余额
  sql = "SELECT savings FROM users WHERE userid = ?";
  conn.query(sql, [userid], function (err, result) {
    if (result && result.length === 0) {
      jsonWrite(res, {
        msg: "User not exist"
      });
    } else {
      //step2 -- 更新用户余额（充值）
      sql = "UPDATE users SET savings = ? WHERE userid = ?";
      conn.query(sql, [result[0].savings + investnum, userid], function (err, result1) {
        if (result1) {
          jsonWrite(res, {
            msg: "Succeed"
          });
        }
      })
    }
  })
};

