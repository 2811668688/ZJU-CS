import { nanoid } from 'nanoid';
import {jsonWrite,tmkdir,storePhoto,getPhoto} from "./utils.js";
import conn from "./db.js";

/*
  模块2：商品信息模块
*/

//子模块2-1：单个商品操作

//修改商品数据库
const modifyGoods = function(goodid,goodname,price,type,storage_amount,description,postage,res) {
	let origin_sto;
	let errmark = 0;
	let sql;

	if (goodname !== undefined){
		sql = "UPDATE goods SET goodname=? WHERE goodid=?;";
		conn.query(sql, [goodname,goodid], function (err, result) {
			if(err) {
				jsonWrite(res, {msg: "Database error: " + err.sqlMessage});
				errmark = 1;
			}
		})
	}
	if (price !== undefined){
		sql = "UPDATE goods SET price=? WHERE goodid=?;";
		conn.query(sql, [price,goodid], function (err, result) {
			if(err) {
				jsonWrite(res, {msg: "Database error: " + err.sqlMessage});
				errmark = 1;
			}
		})
	}
	if (type !== undefined){
		sql = "UPDATE goods SET type=? WHERE goodid=?;";
		conn.query(sql, [type,goodid], function (err, result) {
			if(err) {
				jsonWrite(res, {msg: "Database error: " + err.sqlMessage});
				errmark = 1;
			}
		})
	}
	if (storage_amount !== undefined){
		sql = "SELECT storage_amount FROM goods WHERE goodid=?";
		conn.query(sql, [goodid], function (err, result) {
			if(err) {
				jsonWrite(res, {msg: "Database error: " + err.sqlMessage});
				errmark = 1;
			}
			else
			{
				origin_sto = result[0].storage_amount;
				sql = "UPDATE goods SET storage_amount=? WHERE goodid=?;";
				conn.query(sql, [storage_amount+origin_sto,goodid], function (err, result) {
					if(err) {
						jsonWrite(res, {msg: "Database error: " + err.sqlMessage});
						errmark = 1;
					}
				})
			}
		})   
	}
	if (description !== undefined){
		sql = "UPDATE goods SET description=? WHERE goodid=?;";
		conn.query(sql, [description,goodid], function (err, result) {
			if(err) {
				jsonWrite(res, {msg: "Database error: " + err.sqlMessage});
				errmark = 1;
			}
		})
	}
	if (postage !== undefined){
		sql = "UPDATE goods SET postage=? WHERE goodid=?;";
		conn.query(sql, [postage,goodid], function (err, result) {
			if(err) {
				jsonWrite(res, {msg: "Database error: " + err.sqlMessage});
				errmark = 1;
			}
		})
	}
	return errmark;
}

//子模块2-1-1：创建商品(商品上架)
export const CreateGoodsRes = (req, res)=>{
	const goodid = nanoid(15);
	const sellerid = req.body.userid;
	const goodname = req.body.goodname;
	const price = req.body.price;
	const type = req.body.type;
	const storage_amount = req.body.goodnumber;
	const description = req.body.description;
	const postage = req.body.postage;
	const picture = req.body.goodpic;

	//console.log(new_photo);

	let sql;
	let errmark=0;
	//step1 -- 查询users, 判定userid是否存在
	sql = "SELECT user_phone FROM users WHERE userid=?";
	conn.query(sql, [sellerid], function (err, result) {
		if(err) {
			jsonWrite(res, {msg: "Database error: " + err.sqlMessage});
		}
		else if (result && result.length === 0) {
			jsonWrite(res, {
				msg: "User not found", 
				goodid: undefined,
			});
			errmark=1;
			//console.log("errmark="+errmark);
			//console.log("!!user not found!!");
		}
		else{
			sql="INSERT INTO goods (sellerid,goodid) value (?,?)";
			conn.query(sql, [sellerid,goodid], function (err, result) {
				if(err) {
					jsonWrite(res, {msg: "Database error: " + err.sqlMessage});
					errmark = 1;
				}
			})
			if (errmark===0){
				errmark = modifyGoods(goodid,goodname,price,type,storage_amount,description,postage,res);
				if (picture !== undefined){
					errmark = storePhoto(goodid,picture);
				}
			}
			if (errmark===0){
				jsonWrite(res, {
					msg: "Succeed",
					goodid: goodid});
			}
		}
	})
};

//子模块2-1-2：下架商品
export const DeleteGoodsRes = (req, res)=>{
	const goodid = req.body.goodid;
	const sellerid = req.body.userid;
	let sql;
	//step1 -- 查询users, 判定userid是否存在
	sql = "SELECT user_phone FROM users WHERE userid=?";
	conn.query(sql, [sellerid], function (err, result) {
		if(err) {
			jsonWrite(res, {msg: "Database error: " + err.sqlMessage});
		}
		else if (result && result.length === 0) {
			jsonWrite(res, {
				msg: "User not found"
			});
		}
		else{
			//step2 -- 查询goods, 判断goodid是否存在
			sql = "SELECT type FROM goods WHERE goodid=?";
			conn.query(sql, [goodid], function (err, result) {
				if(err) {
					jsonWrite(res, {msg: "Database error: " + err.sqlMessage});
				}
				else if (result && result.length === 0) {
					jsonWrite(res, {
						msg: "Good not found"
					});
				}
				else{
					//step3 -- 下架商品
					sql = "DELETE FROM goods WHERE goodid=?";
					conn.query(sql, [goodid], function (err, result) {
						if(err) {
							jsonWrite(res, {msg: "Database error: " + err.sqlMessage});
						}
						else if (result) {
							jsonWrite(res, {
								msg: "Succeed"
							});
						}
					});
				}
			});
		}
	});
};

//子模块2-1-3：编辑修改商品
export const ModifyGoodsRes = (req, res)=>{
  const goodid = req.body.goodid;
  const sellerid = req.body.userid;
  const goodname = req.body.goodname;
  const price = req.body.price;
  const type = req.body.type;
  const storage_amount = req.body.goodnumber;
  const description = req.body.description;
  const postage = req.body.postage;
  const picture = req.body.goodpic;

  let sql;
  let errmark=0;
  //step1 -- 查询users, 判定userid是否存在
  sql = "SELECT user_phone FROM users WHERE userid=?";
  conn.query(sql, [sellerid], function (err, result) {
    if(err) {
      jsonWrite(res, {msg: "Database error: " + err.sqlMessage});
    }
    else if (result && result.length === 0) {
      jsonWrite(res, {
        msg: "User not found"
      });
      errmark=1;
    }
    else{
      //step2 -- 查询goods, 判断goodid是否存在
      sql = "SELECT sellerid FROM goods WHERE goodid=?";
      conn.query(sql, [goodid], function (err, result) {
        //console.log("result = ",result);

        if(err) {
          jsonWrite(res, {msg: "Database error: " + err.sqlMessage});
        }
        else if (result && result.length === 0) {
          jsonWrite(res, {
            msg: "Good not found"
          });
          errmark = 1;
        }
        else if (result[0].sellerid !== sellerid) {
          //step3 -- 用户无权限修改商品信息
          jsonWrite(res, {
            msg: "No permission to modify"
          });
          errmark = 1;
        }
        else{
          //step4 -- 可以修改商品信息
          errmark = modifyGoods(goodid,goodname,price,type,storage_amount,description,postage,res);
          if (picture !== undefined){
            errmark = storePhoto(goodid,picture);
          }
          if (errmark===0){
            jsonWrite(res, {
              msg: "Succeed"});
          }
        }
      });
    }
  })
};

//子模块2-2：展示多个商品

//组装展示多个商品数据包
const displaySomeGoods = function(sqlresult) {
  let i;
  let goods = [];

  for (i=0;i<sqlresult.length;i++){
    let goodinfo = {};
    
    goodinfo.userid = sqlresult[i].sellerid;
    goodinfo.goodid = sqlresult[i].goodid;
    goodinfo.goodname = sqlresult[i].goodname;
    goodinfo.price = sqlresult[i].price;
    goodinfo.type = sqlresult[i].type;
    goodinfo.storage_amount = sqlresult[i].storage_amount;
    goodinfo.sales_volume = sqlresult[i].sales_volume;
    goodinfo.description = sqlresult[i].description;
    goodinfo.postage = sqlresult[i].postage;
    goodinfo.username = sqlresult[i].username;
    let res_photo = {};
    getPhoto(sqlresult[i].goodid,res_photo);
    goodinfo.picture = res_photo.photo;
    goods.push(goodinfo);
  }
  // console.log("in displaySomeGoods - goods: ",goods);
  return goods;
}

//子模块2-2-1：卖方归属商品展示
export const ShowUserGoodsRes = (req, res)=>{
  const sellerid = req.body.userid;
  let goods = [];
  let sql;
  let errmark = 0;

  //step1 -- 查询users, 判定userid是否存在
  sql = "SELECT username FROM users WHERE userid=?";
  conn.query(sql, [sellerid], function (err, result) {
    if(err) {
      jsonWrite(res, {msg: "Database error: " + err.sqlMessage});
    }
    else if (result && result.length === 0) {
      jsonWrite(res, {
        msg: "User not found",
        userGoods: undefined
      });
      errmark=1;
    }
    else{
      //step2 -- 查询goods, 判断当前seller是否在销售商品
      sql = "SELECT * FROM goods WHERE sellerid=?";
      conn.query(sql, [sellerid], function (err, result) {
        if(err) {
          jsonWrite(res, {msg: "Database error: " + err.sqlMessage});
        }
        else if (result && result.length === 0) {
          jsonWrite(res, {
            msg: "Seller has no goods"
          });
          errmark = 1;
        }
        else{
          //step3 -- 返回当前用户的全部商品
          sql = "SELECT goods.sellerid as sellerid, goods.goodid as goodid, goods.goodname as goodname,\
                goods.price as price, goods.type as type, goods.storage_amount as storage_amount,\
                goods.sales_volume as sales_volume, goods.description as description, goods.postage as postage,\
                users.username as username FROM goods INNER JOIN users ON users.userid = goods.sellerid WHERE sellerid=?";
          conn.query(sql, [sellerid], function (err, result) {
            if(err) {
              jsonWrite(res, {msg: "Database error: " + err.sqlMessage});
            }
            else{
              goods = displaySomeGoods(result);
              jsonWrite(res, {
                msg: "succeed",
                userGoods: goods
              });
            }
          });
        }
      });
    }
  })
};

//子模块2-2-2：按类商品展示
//notice: type === 0时，表示展示全部商品
export const ShowGoodsByTypeRes = (req, res)=>{
  const type = req.body.type;
  let goods = [];
  let sql;
  let errmark = 0;

  // console.log("type = ",type);

  //step1 -- 查询type, 判定当前type是否在goods中存在
  if (type !== 0){
    sql = "SELECT goodid FROM goods WHERE type=?";
    conn.query(sql, [type], function (err, result) {
      if(err) {
        jsonWrite(res, {msg: "Database error: " + err.sqlMessage});
      }
      else if (result && result.length === 0) {
        jsonWrite(res, {
          msg: "This type has no goods on sale",
          typeGoods: undefined
        });
        errmark=1;
      }
    })
  }

  if (type === 0){
    //showAllGoods
    // console.log("1 - type=0");

    sql = "SELECT goods.sellerid as sellerid, goods.goodid as goodid, goods.goodname as goodname,\
            goods.price as price, goods.type as type, goods.storage_amount as storage_amount,\
            goods.sales_volume as sales_volume, goods.description as description, goods.postage as postage,\
            users.username as username FROM goods INNER JOIN users ON users.userid = goods.sellerid";

    // console.log("2 - type=0");

    conn.query(sql, function (err, result) {
      // console.log("3 - type=0");
      if(err) {
        jsonWrite(res, {msg: "Database error: " + err.sqlMessage});
      }
      else{
        // console.log("4 - type=0");
        goods = displaySomeGoods(result);
        jsonWrite(res, {
          msg: "succeed",
          typeGoods: goods
        });
        // console.log("5 - type=0");
      }
    });
  }
  else{
    //showGoodsByType
    sql = "SELECT goods.sellerid as sellerid, goods.goodid as goodid, goods.goodname as goodname,\
            goods.price as price, goods.type as type, goods.storage_amount as storage_amount,\
            goods.sales_volume as sales_volume, goods.description as description, goods.postage as postage,\
            users.username as username FROM goods INNER JOIN users ON users.userid = goods.sellerid WHERE type=?";
    conn.query(sql, [type], function (err, result) {
      if(err) {
        jsonWrite(res, {msg: "Database error: " + err.sqlMessage});
      }
      else{
        goods = displaySomeGoods(result);
        jsonWrite(res, {
          msg: "succeed",
          typeGoods: goods
        });
      }
    });
  }  
};

//子模块2-2-3：查找商品展示
export const ShowGoodsByNameRes = (req, res)=>{
  const wantname = req.body.wantname;
  let goods = [];
  let sql;
  let errmark = 0;

  sql = "SELECT goods.sellerid as sellerid, goods.goodid as goodid, goods.goodname as goodname,\
          goods.price as price, goods.type as type, goods.storage_amount as storage_amount,\
          goods.sales_volume as sales_volume, goods.description as description, goods.postage as postage,\
          users.username as username FROM goods INNER JOIN users ON users.userid = goods.sellerid WHERE goodname LIKE '%" + wantname + "%'";
  //console.log("sql = ",sql);
  conn.query(sql, function (err, result) {
    if(err) {
      jsonWrite(res, {msg: "Database error: " + err.sqlMessage});
    }
    else if (result && result.length === 0) {
      jsonWrite(res, {
        msg: "No such goods on sale",
        searchGoods: undefined
      });
      errmark=1;
    }
    else{
      goods = displaySomeGoods(result);
      jsonWrite(res, {
        msg: "succeed",
        searchGoods: goods
      });
    }
  })
};

//子模块2-2-4：按ID检索商品
export const ShowGoodsByIdRes = (req, res)=>{
  const goodid = req.body.id;
  let goods = [];
  let sql;
  let errmark = 0;

  sql = "SELECT goods.sellerid as sellerid, goods.goodid as goodid, goods.goodname as goodname,\
          goods.price as price, goods.type as type, goods.storage_amount as storage_amount,\
          goods.sales_volume as sales_volume, goods.description as description, goods.postage as postage,\
          users.username as username FROM goods INNER JOIN users ON users.userid = goods.sellerid WHERE goodid = ?";
  //console.log("sql = ",sql);
  conn.query(sql, [goodid], function (err, result) {
    if(err) {
      jsonWrite(res, {msg: "Database error: " + err.sqlMessage});
    }
    else if (result && result.length === 0) {
      jsonWrite(res, {
        msg: "This id has no goods on sale",
        idGoods: undefined
      });
      errmark=1;
    }
    else{
      goods = displaySomeGoods(result);
      jsonWrite(res, {
        msg: "succeed",
        idGoods: goods
      });
    }
  })
};

//子模块2-3：收藏管理

//子模块2-3-1：添加收藏商品
export const UserAddLikeRes = (req, res)=>{
  const userid = req.body.userid;
  const goodid = req.body.goodid;
  let sql;
  let errmark=0;

  //step1 -- 查询users, 判定userid是否存在
  sql = "SELECT user_phone FROM users WHERE userid=?";
  conn.query(sql, [userid], function (err, result) {
    if(err) {
      jsonWrite(res, {msg: "Database error: " + err.sqlMessage});
      errmark = 1;
    }
    else if (result && result.length === 0) {
      jsonWrite(res, {
        msg: "User not found"
      });
      errmark=1;
    }
    else{
      //step2 -- 查询goods, 判断goodid是否存在
      sql = "SELECT sellerid FROM goods WHERE goodid=?";
      conn.query(sql, [goodid], function (err, result) {
        if(err) {
          jsonWrite(res, {msg: "Database error: " + err.sqlMessage});
          errmark = 1;
        }
        else if (result && result.length === 0) {
          jsonWrite(res, {
            msg: "Good not found"
          });
          errmark = 1;
        }
        else{
          sql = "INSERT INTO collections (userid,goodid) value (?,?) "
          conn.query(sql, [userid, goodid], function(err, result){
            if(err) {
              jsonWrite(res, {msg: "Database error: " + err.sqlMessage});
              errmark = 1;
            }
          })
        }
        if (errmark === 0){
          jsonWrite(res, {msg: "Succeed"});
        }
      });
    }
  })
};

//子模块2-3-2：展示收藏商品
export const UserShowLikeRes = (req, res)=>{
  const userid = req.body.userid;
  let goods = [];
  let sql;
  let errmark = 0;

  sql = "SELECT goods.sellerid as sellerid, goods.goodid as goodid, goods.goodname as goodname,\
          goods.price as price, goods.type as type, goods.storage_amount as storage_amount,\
          goods.sales_volume as sales_volume, goods.description as description, goods.postage as postage,\
          users.username as username FROM collections LEFT JOIN (goods INNER JOIN users) ON users.userid = goods.sellerid \
          AND collections.goodid = goods.goodid AND collections.userid = goods.sellerid WHERE collections.userid=?";
  conn.query(sql, [userid], function (err, result) {
    if(err) {
      jsonWrite(res, {msg: "Database error: " + err.sqlMessage});
    }
    else if (result && result.length === 0) {
      jsonWrite(res, {
        msg: "No goods in likes",
        likeGoods: undefined
      });
      errmark=1;
    }
    else{
      goods = displaySomeGoods(result);
      jsonWrite(res, {
        msg: "succeed",
        userGoods: goods
      });
    }
  })
};

//子模块2-3-3：删除收藏商品
export const UserDeleteLikeRes = (req, res)=>{
  const userid = req.body.userid;
  const goodid = req.body.goodid;
  let sql;
  let errmark=0;

  //step1 -- 查询users, 判定userid是否存在
  sql = "SELECT user_phone FROM users WHERE userid=?";
  conn.query(sql, [userid], function (err, result) {
    if(err) {
      jsonWrite(res, {msg: "Database error: " + err.sqlMessage});
      errmark = 1;
    }
    else if (result && result.length === 0) {
      jsonWrite(res, {
        msg: "User not found"
      });
      errmark=1;
    }
    else{
      //step2 -- 查询goods, 判断goodid是否存在
      sql = "SELECT sellerid FROM goods WHERE goodid=?";
      conn.query(sql, [goodid], function (err, result) {
        if(err) {
          jsonWrite(res, {msg: "Database error: " + err.sqlMessage});
          errmark = 1;
        }
        else if (result && result.length === 0) {
          jsonWrite(res, {
            msg: "Good not found"
          });
          errmark = 1;
        }
        else{
          sql = "DELETE FROM collections WHERE userid = ? and goodid = ? ";
          conn.query(sql, [userid, goodid], function(err, result){
            if(err) {
              jsonWrite(res, {msg: "Database error: " + err.sqlMessage});
              errmark = 1;
            }
          })
        }
        if (errmark === 0){
          jsonWrite(res, {msg: "Succeed"});
        }
      });
    }
  })
};

//子模块2-3-4：查看商品是否被收藏
export const InLikeRes = (req, res)=>{
  const userid = req.body.userid;
  const goodid = req.body.goodid;
  let sql;
  let errmark=0;

  //step1 -- 查询users, 判定userid是否存在
  sql = "SELECT user_phone FROM users WHERE userid=?";
  conn.query(sql, [userid], function (err, result) {
    if(err) {
      jsonWrite(res, {msg: "Database error: " + err.sqlMessage});
      errmark = 1;
    }
    else if (result && result.length === 0) {
      jsonWrite(res, {
        msg: "User not found"
      });
      errmark=1;
    }
    else{
      //step2 -- 查询goods, 判断goodid是否存在
      sql = "SELECT sellerid FROM goods WHERE goodid=?";
      conn.query(sql, [goodid], function (err, result) {
        if(err) {
          jsonWrite(res, {msg: "Database error: " + err.sqlMessage});
          errmark = 1;
        }
        else if (result && result.length === 0) {
          jsonWrite(res, {
            msg: "Good not found"
          });
          errmark = 1;
        }
        else{
          //step3 -- 判断商品是否被用户收藏
          sql = "SELECT goodid FROM collections WHERE userid = ?";
          conn.query(sql, [userid], function(err, result){
            if(err) {
              jsonWrite(res, {msg: "Database error: " + err.sqlMessage});
              errmark = 1;
            }
            else {
              let isIn = 0;
              let i;
              for (i=0;i<result.length;i++){
                if (result[0].goodid === goodid) {
                  isIn = 1;
                  break;
                }
              }
              if (isIn === 0){
                jsonWrite(res, {msg: "No"});
              }
              else {
                jsonWrite(res, {msg: "Yes"});
              }
            }
          })
        }
      });
    }
  })
};