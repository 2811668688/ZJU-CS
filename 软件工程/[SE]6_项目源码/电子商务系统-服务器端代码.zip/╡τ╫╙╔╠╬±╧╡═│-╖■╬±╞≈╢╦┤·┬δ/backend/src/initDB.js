// 1 引入
import mysql from "mysql";
// 2 创建链接配置
const conn = mysql.createConnection({
    host:'localhost',   // 主机名 （服务器地址）
    user:'root',    //用户名
    password:'1897Zd2020',    // 密码
    port: 3306,
})

console.log("conn:", conn);

const queryFeedback = (err, result) => {
    if(err){
        // console.log(err);
        return
    }
    // 显示处理结果
    // console.log("success!result:",result);
};

conn.query("create database online_shopping;", queryFeedback);

conn.query("use online_shopping;", queryFeedback);

// //table1 - 用户信息表( users )
conn.query("create table users(\
    userid varchar(15) primary key,\
    user_phone char(11) not null unique,\
    password varchar(32) not null,\
    username varchar(32),\
    mail varchar(32),\
    personid char(18),\
    gender int DEFAULT 0,\
    birthday char(10),\
    location varchar(48),\
    postcode char(6),\
    savings int\
);",queryFeedback);

// //table2 - 商品信息表( goods )
conn.query("create table goods(\
    goodid varchar(15) primary key,\
    goodname varchar(30),\
    price int,\
    type int,\
    storage_amount int DEFAULT 0,\
    sales_volume int DEFAULT 0,\
    description varchar(100),\
    sellerid varchar(15),\
    state int DEFAULT 0,\
    postage int,\
    foreign key (sellerid) references users(userid) on delete cascade on update cascade\
);",queryFeedback);

//table3 - 商品上架/下架表( loads_unloads )
conn.query("create table loads_unloads(\
    loadid varchar(15) primary key,\
    sellerid varchar(15),\
    goodid varchar(15),\
    optype int,\
    optime time,\
    goodsnum int,\
    state int,\
    foreign key (sellerid) references users(userid) on delete cascade on update cascade,\
    foreign key (goodid) references goods(goodid) on delete cascade on update cascade\
);",queryFeedback);

//table4 - 收藏&购物车表( collections )
conn.query("create table collections(\
    userid varchar(15),\
    num int DEFAULT 0,\
    goodid varchar(15),\
    type int DEFAULT 0,\
    foreign key (userid) references users(userid) on delete cascade on update cascade\
);",queryFeedback);

//table5 - 交易订单表( orders )
conn.query("create table orders(\
    orderid varchar(15) primary key,\
    sellerid varchar(15),\
    buyerid varchar(15),\
    goodid varchar(15),\
    ordertime varchar(50),\
    buynum int,\
    state int DEFAULT 0,\
    expressid varchar(15),\
    foreign key (sellerid) references users(userid) on delete cascade on update cascade,\
    foreign key (buyerid) references users(userid) on delete cascade on update cascade,\
    foreign key (goodid) references goods(goodid) on delete cascade on update cascade\
);",queryFeedback);

//table6 - 个人储值表( savings )
conn.query("create table savings(\
    investid varchar(15) primary key,\
    userid varchar(15),\
    optime time,\
    investnum int,\
    tradingplatform int,\
    state int DEFAULT 0,\
    foreign key (userid) references users(userid) on delete cascade on update cascade\
);",queryFeedback);
