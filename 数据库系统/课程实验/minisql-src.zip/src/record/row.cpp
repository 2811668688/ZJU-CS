#include "record/row.h"
#include <vector>

uint32_t Row::SerializeTo(char *buf, Schema *schema) const {
  // replace with your code here
  // char *p = buf;
  uint32_t FieldNums=this->GetFieldCount();
  MACH_WRITE_TO(uint32_t , buf, FieldNums);
  buf+=sizeof(uint32_t);
  uint32_t result=sizeof(uint32_t);
  for (uint32_t i = 0; i < this->GetFieldCount(); ++i) {
    MACH_WRITE_TO(bool, buf ,this->GetField(i)->IsNull());
    buf+=sizeof(bool);
    result+=sizeof(bool);
  }
  for (uint32_t i = 0; i < this->GetFieldCount(); ++i) {

    result+=(this->GetField(i))->SerializeTo(buf);
    buf+=this->GetField(i)->GetSerializedSize();
  }
  // return buf - p;
  return result;
}

uint32_t Row::DeserializeFrom(char *buf, Schema *schema) {
  // replace with your code here
  fields_.clear();
  if(schema==nullptr){
    return 0;
  }
  uint32_t FieldNums=MACH_READ_FROM(uint32_t , buf);//读出列数
  buf+=sizeof(uint32_t);
  uint32_t result=sizeof (uint32_t);
  bool isNull[FieldNums];
  for(uint32_t i=0;i<FieldNums;i++)//读出位图
  {
    isNull[i]= MACH_READ_FROM(bool ,buf);
    buf+=sizeof(bool );
    result+=sizeof(bool);
  }
  uint32_t i=0;
  for(auto &column : schema->GetColumns())//读fields
  {
    Field *F= ALLOC_P(heap_,Field(column->GetType()));
    Field **f=&F;
    result+=Field::DeserializeFrom(buf,column->GetType(),f,isNull[i++],heap_);
    buf+=F->GetSerializedSize();
    void*Buf=heap_->Allocate(sizeof(Field));
    fields_.push_back(new(Buf)Field(*F));
  }
  return result;
}

uint32_t Row::GetSerializedSize(Schema *schema) const {
  // replace with your code here
  if(schema==nullptr)
    return 0;
  int n=schema->GetColumnCount();
  uint32_t result=sizeof(uint32_t);
  for(int i=0;i<n;i++)
  {
    result+=sizeof(bool);
    result+=this->fields_[i]->GetSerializedSize();
  }
  return result;
}
