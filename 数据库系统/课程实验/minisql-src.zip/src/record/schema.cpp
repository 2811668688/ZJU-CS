#include "record/schema.h"

uint32_t Schema::SerializeTo(char *buf) const {
  // replace with your code here
  char* p = buf;
  uint32_t n=columns_.size();
  MACH_WRITE_TO(uint32_t,buf,n);
  buf+=4;
  uint32_t i;
  for(i=0;i<n;i++)
  {
    buf += columns_[i]->SerializeTo(buf);
  }
  return buf-p;
}

uint32_t Schema::GetSerializedSize() const {
  // replace with your code here
  uint32_t result=4;
  for(auto column:this->GetColumns())
  {
    result+=column->GetSerializedSize();
  }
  return result;
}

uint32_t Schema::DeserializeFrom(char *buf, Schema *&schema, MemHeap *heap) {
  // replace with your code here
  //传入的schema的colum是空的
  char*p=buf;
  uint32_t col_num=MACH_READ_FROM(uint32_t,buf);
  buf+=4;
  std::vector<Column*> column;
  for(uint32_t i=0;i<col_num;i++)
  {
    Column* col= nullptr;
    buf+=Column::DeserializeFrom(buf,col,heap);
    column.push_back(col);
  }
//  void*Buf=heap->Allocate(sizeof(std::vector<Column*>));
  //  schema->columns_.push_back(new(Buf)std::vector<Column*>(column));
  schema=ALLOC_P(heap,Schema)(column);
  //传入的schema其实是空的，序列化出各个列然后生成这个schema
  return buf-p;
}