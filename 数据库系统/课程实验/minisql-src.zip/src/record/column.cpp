#include "record/column.h"
Column::Column(std::string column_name, TypeId type, uint32_t index, bool nullable, bool unique)
    : name_(std::move(column_name)), type_(type), table_ind_(index),
      nullable_(nullable), unique_(unique) {
  ASSERT(type != TypeId::kTypeChar, "Wrong constructor for CHAR type.");
  switch (type) {
    case TypeId::kTypeInt :
      len_ = sizeof(int32_t);
      break;
    case TypeId::kTypeFloat :
      len_ = sizeof(float_t);
      break;
    default:
      ASSERT(false, "Unsupported column type.");
  }
}

Column::Column(std::string column_name, TypeId type, uint32_t length, uint32_t index, bool nullable, bool unique)
    : name_(std::move(column_name)), type_(type), len_(length),
      table_ind_(index), nullable_(nullable), unique_(unique) {
  ASSERT(type == TypeId::kTypeChar, "Wrong constructor for non-VARCHAR type.");
}

Column::Column(const Column *other) : name_(other->name_), type_(other->type_), len_(other->len_),
                                      table_ind_(other->table_ind_), nullable_(other->nullable_),
                                      unique_(other->unique_) {}

uint32_t Column::SerializeTo(char *buf) const
{
  char*p=buf;
  MACH_WRITE_TO(uint32_t , buf, this->GetName().size());
  buf+=sizeof(uint32_t);
  MACH_WRITE_STRING(buf, this->GetName());
  buf+=this->GetName().size();
  MACH_WRITE_TO(TypeId, buf, this->GetType());
  buf+=sizeof(TypeId);
  MACH_WRITE_TO(uint32_t , buf, this->GetLength());
  buf+=sizeof(uint32_t);
  MACH_WRITE_TO(uint32_t , buf, this->GetTableInd());
  buf+=sizeof(uint32_t);
  MACH_WRITE_TO(bool , buf, nullable_);
  buf+=sizeof(bool);
  MACH_WRITE_TO(bool , buf, unique_);
  buf+=sizeof(bool);
  return buf-p;
}

uint32_t Column::GetSerializedSize() const {
  // replace with your code here
  uint32_t result=0;
  result+=sizeof(TypeId)+3*sizeof(uint32_t)+2*sizeof(bool);
  result+=this->GetName().size();
  return result;
}

uint32_t Column::DeserializeFrom(char *buf, Column *&column, MemHeap *heap) {
  char* p=buf;
  uint32_t NameLength=MACH_READ_FROM(uint32_t ,buf);
  buf+=sizeof(uint32_t);
//  std::string column_name=MACH_READ_FROM(std::string, buf);
  std::string column_name;
  char column_name_unit;
  for(uint32_t i=0;i<NameLength;i++)
  {
    column_name_unit=MACH_READ_FROM(char, buf);
    buf+=1;
    column_name+=column_name_unit;
  }
  TypeId type_=MACH_READ_FROM(TypeId, buf);
  buf+=sizeof(TypeId);
  uint32_t len=MACH_READ_FROM(uint32_t , buf);
  buf+=sizeof(uint32_t);
  uint32_t col_ind=MACH_READ_FROM(uint32_t , buf);
  buf+=sizeof(uint32_t);
  bool nullable=MACH_READ_FROM(bool , buf);
  buf+=sizeof(bool);
  bool unique=MACH_READ_FROM(bool , buf);
  buf+=sizeof(bool);
  if(type_==kTypeInt||type_==kTypeFloat)
  column = ALLOC_P(heap, Column)(column_name, type_, col_ind, nullable, unique);
  else if(type_==kTypeChar)
  {
    column = ALLOC_P(heap, Column)(column_name, type_, len, col_ind, nullable, unique);
  }
  return buf-p;
}
