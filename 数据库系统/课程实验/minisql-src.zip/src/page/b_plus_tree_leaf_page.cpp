#include "page/b_plus_tree_leaf_page.h"
#include <algorithm>
#include "index/basic_comparator.h"
#include "index/generic_key.h"
#include <iostream>

/*****************************************************************************
 * HELPER METHODS AND UTILITIES
 *****************************************************************************/

/**
 * Init method after creating a new leaf page
 * Including set page type, set current size to zero, set page id/parent id, set
 * next page id and set max size
 */
INDEX_TEMPLATE_ARGUMENTS
void B_PLUS_TREE_LEAF_PAGE_TYPE::Init(page_id_t page_id, page_id_t parent_id, int max_size)
{
  this->SetPageType(IndexPageType::LEAF_PAGE);
  this->SetSize(0);
  this->SetPageId(page_id);
  this->SetParentPageId(parent_id);
  this->SetNextPageId(INVALID_PAGE_ID);
  this->SetMaxSize(max_size);
}

/**
 * Helper methods to set/get next page id
 */
INDEX_TEMPLATE_ARGUMENTS
page_id_t B_PLUS_TREE_LEAF_PAGE_TYPE::GetNextPageId() const { return next_page_id_; }

INDEX_TEMPLATE_ARGUMENTS
void B_PLUS_TREE_LEAF_PAGE_TYPE::SetNextPageId(page_id_t next_page_id) { next_page_id_ = next_page_id; }

/**
 * Helper method to find the first index i so that array_[i].first >= key
 * NOTE: This method is only used when generating index iterator
 */
INDEX_TEMPLATE_ARGUMENTS
int B_PLUS_TREE_LEAF_PAGE_TYPE::KeyIndex(const KeyType &key, const KeyComparator &comparator) const
{
    for (int i = 0; i < GetSize(); i++)
    {
        if (comparator(array_[i].first, key) >= 0)
        {
            // 找到第一个比要插入值大的值的位置，作为新值的插入位置
            // 或者是当前值的位置，用于删除
            return i;
        }
    }
    // 此时，新值应该插入到末尾
    return GetSize();
}

/*
 * Helper method to find and return the key associated with input "index"(a.k.a array offset)
 */
INDEX_TEMPLATE_ARGUMENTS
KeyType B_PLUS_TREE_LEAF_PAGE_TYPE::KeyAt(int index) const
{
    return array_[index].first;
}

/*
 * Helper method to find and return the key & value pair associated with input
 * "index"(a.k.a array offset)
 */
INDEX_TEMPLATE_ARGUMENTS
const MappingType &B_PLUS_TREE_LEAF_PAGE_TYPE::GetItem(int index)
{
    return array_[index];
}

/*****************************************************************************
 * INSERTION
 *****************************************************************************/
/*
 * Insert key & value pair into leaf page ordered by key
 * @return page size after insertion
 */
INDEX_TEMPLATE_ARGUMENTS
int B_PLUS_TREE_LEAF_PAGE_TYPE::Insert(const KeyType &key, const ValueType &value, const KeyComparator &comparator)
{
    // 新值要插入的位置
    int target = KeyIndex(key, comparator);

    for (int i = GetSize() - 1; i >= target; i--)
    {
        // 把所有的值向后挪一位
        array_[i + 1]= array_[i];
    }
    // 插入目标内容
    array_[target] = MappingType{key, value};
    // 修改页面大小
    IncreaseSize(1);
    // 返回插入后的页面大小
    return GetSize();
}

/*****************************************************************************
* SPLIT
*****************************************************************************/

/*
* Remove half of key & value pairs from this page to "recipient" page
*/
INDEX_TEMPLATE_ARGUMENTS
void B_PLUS_TREE_LEAF_PAGE_TYPE::MoveHalfTo(BPlusTreeLeafPage * recipient)
{
    // 默认右边的页面多一个
    int NumToMove = GetSize() - GetSize() / 2;
    // 确定复制的起始下标
    int start = GetSize() - NumToMove;
    // 数据复制
    recipient->CopyNFrom(array_ + start, NumToMove);
    // 修改两个页面的大小
    IncreaseSize(-1 * NumToMove);
    recipient->IncreaseSize(NumToMove);

    // 注意，在该函数内部只是进行数据复制，不处理链表关系
}


/*
* Copy starting from items, and copy {size} number of elements into me.
*/
INDEX_TEMPLATE_ARGUMENTS
void B_PLUS_TREE_LEAF_PAGE_TYPE::CopyNFrom(MappingType* items, int size)
{
    for(int i = 0; i < size; i++)
    {
        array_[i] = items[i];
    }
}

/*****************************************************************************
* LOOKUP
*****************************************************************************/
/*
* For the given key, check to see whether it exists in the leaf page. If it
* does, then store its corresponding value in input "value" and return true.
* If the key does not exist, then return false
*/
INDEX_TEMPLATE_ARGUMENTS
bool B_PLUS_TREE_LEAF_PAGE_TYPE::Lookup(const KeyType &key, ValueType &value, const KeyComparator &comparator) const
{
    // 线性查找
    for(int i = 0; i < GetSize(); i++)
    {
        if (comparator(key, array_[i].first) == 0)
        {
            // 找到目标 key
            value = array_[i].second;
            return true;
        }
    }
    value = array_[GetSize() - 1].second;
    return false;
}

/*****************************************************************************
* REMOVE
*****************************************************************************/
/*
* First look through leaf page to see whether delete key exist or not. If
* exist, perform deletion, otherwise return immediately.
* NOTE: store key&value pair continuously after deletion
* @return  page size after deletion
*/
INDEX_TEMPLATE_ARGUMENTS
int B_PLUS_TREE_LEAF_PAGE_TYPE::RemoveAndDeleteRecord(const KeyType &key, const KeyComparator &comparator)
{
    // 获取目标键值所在的位置
    int index = KeyIndex(key, comparator);

    if( index < GetSize() && comparator(key, array_[index].first) == 0)
    {
        // 当前位置下标有效且对应位置的 key 确实为需要删除的 key
        for(int i = index + 1; i < GetSize(); i++)
        {
            // 数据平移
            array_[i - 1] = array_[i];
        }

        IncreaseSize(-1);
    }
    return GetSize();
}


/*****************************************************************************
* MERGE
*****************************************************************************/
/*
* Remove all of key & value pairs from this page to "recipient" page. Don't forget
* to update the next_page id in the sibling page
*/
INDEX_TEMPLATE_ARGUMENTS
void B_PLUS_TREE_LEAF_PAGE_TYPE::MoveAllTo(BPlusTreeLeafPage* recipient)
{
    for(int i = 0; i < GetSize(); i++)
    {
        // 拷贝数据
        recipient->CopyLastFrom(array_[i]);
    }
    // 将当前页的数组大小置 0
    SetSize(0);
    // 注意，函数的实现仅考虑数据的复制，链表的修改交给调用者处理
}
/*
* Copy the item into the end of my item list. (Append item to my array)
*/
INDEX_TEMPLATE_ARGUMENTS
void B_PLUS_TREE_LEAF_PAGE_TYPE::CopyLastFrom(const MappingType &item)
{
    array_[GetSize()] = item;
    // 同时修改数组的大小
    IncreaseSize(1);
}

/*****************************************************************************
* REDISTRIBUTE
*****************************************************************************/
/*
* Remove the first key & value pair from this page to "recipient" page.
*
*/
INDEX_TEMPLATE_ARGUMENTS
void B_PLUS_TREE_LEAF_PAGE_TYPE::MoveFirstToEndOf(BPlusTreeLeafPage * recipient)
{
    MappingType item = array_[0];
    for(int i = 0; i < GetSize() - 1; i++)
    {
        array_[i] = array_[i + 1];
    }
    IncreaseSize(-1);
    recipient->CopyLastFrom(item);
}

/*
* Remove the last key & value pair from this page to "recipient" page.
*/
INDEX_TEMPLATE_ARGUMENTS
void B_PLUS_TREE_LEAF_PAGE_TYPE::MoveLastToFrontOf(BPlusTreeLeafPage * recipient)
{
    MappingType item = array_[GetSize() - 1];
    IncreaseSize(-1);
    recipient->CopyFirstFrom(item);
}

/*
* Insert item at the front of my items. Move items accordingly.
*
*/
INDEX_TEMPLATE_ARGUMENTS
void B_PLUS_TREE_LEAF_PAGE_TYPE::CopyFirstFrom(const MappingType &item)
{
    for(int i = GetSize() - 1; i >= 0; i--)
    {
        array_[i + 1] = array_[i];
    }
    array_[0] = item;
    IncreaseSize(1);
}

INDEX_TEMPLATE_ARGUMENTS
void B_PLUS_TREE_LEAF_PAGE_TYPE::MoveFirstToEndOf(BPlusTreeLeafPage<KeyType, ValueType, KeyComparator> *recipient,
                                                const KeyType &middle_key, BufferPoolManager *buffer_pool_manager)
{
    MoveFirstToEndOf(recipient);
}

INDEX_TEMPLATE_ARGUMENTS
void B_PLUS_TREE_LEAF_PAGE_TYPE::MoveLastToFrontOf(BPlusTreeLeafPage<KeyType, ValueType, KeyComparator> *recipient,
                                                  const KeyType &middle_key, BufferPoolManager *buffer_pool_manager)
{
    MoveLastToFrontOf(recipient);
}

  template class BPlusTreeLeafPage<int, int, BasicComparator<int>>;

  template class BPlusTreeLeafPage<GenericKey<4>, RowId, GenericComparator<4>>;

  template class BPlusTreeLeafPage<GenericKey<8>, RowId, GenericComparator<8>>;

  template class BPlusTreeLeafPage<GenericKey<16>, RowId, GenericComparator<16>>;

  template class BPlusTreeLeafPage<GenericKey<32>, RowId, GenericComparator<32>>;

  template class BPlusTreeLeafPage<GenericKey<64>, RowId, GenericComparator<64>>;