#include <stdexcept>
#include <sys/stat.h>
#include <chrono>
#include <thread>

#include "glog/logging.h"
#include "page/bitmap_page.h"
#include "storage/disk_manager.h"

DiskManager::DiskManager(const std::string &db_file) : file_name_(db_file)
{
    std::scoped_lock<std::recursive_mutex> lock(db_io_latch_);
    db_io_.open(db_file, std::ios::binary | std::ios::in | std::ios::out);
    // directory or file does not exist
    if (!db_io_.is_open())
    {
        db_io_.clear();
        // create a new file
        db_io_.open(db_file, std::ios::binary | std::ios::trunc | std::ios::out);
        db_io_.close();
        // reopen with original mode
        db_io_.open(db_file, std::ios::binary | std::ios::in | std::ios::out);

        if (!db_io_.is_open())
        {
            throw std::exception();
        }
    }

    // 读取磁盘元数据，里面存储了分区的相关信息
    ReadPhysicalPage(META_PAGE_ID, meta_data_);

    // 利用位运算获取相应的信息，解析元信息
    diskFileMetaPage.num_allocated_pages_ = getNumber(0, meta_data_);
    diskFileMetaPage.num_extents_ = getNumber(4, meta_data_);

    // 读出每个分区所分配的页的数量
    for (unsigned i = 0; i < diskFileMetaPage.num_extents_; i++)
    {
        diskFileMetaPage.extent_used_page_[i] = getNumber(i * 4 + 8, meta_data_);
    }

    // 寻找首个具有空页的已经分配的分区
    findNextFreeExtent();
}

void DiskManager::Close()
{
    std::scoped_lock<std::recursive_mutex> lock(db_io_latch_);

    // 在 diskManager 关闭之前要将元信息页写回
    WritePhysicalPage(0, meta_data_);
    // 将当前的位图页信息写回
    writeBitmapPage(currentFreeExtent, currentBitmapPage);

    if (!closed)
    {
        db_io_.close();
        closed = true;
    }
}

void DiskManager::ReadPage(page_id_t logical_page_id, char *page_data)
{
    ASSERT(logical_page_id >= 0, "Invalid page id.");
    ReadPhysicalPage(MapPageId(logical_page_id), page_data);
}

void DiskManager::WritePage(page_id_t logical_page_id, const char *page_data)
{
    ASSERT(logical_page_id >= 0, "Invalid page id.");
    WritePhysicalPage(MapPageId(logical_page_id), page_data);
}

bool DiskManager::isFull() const
{
    return diskFileMetaPage.num_allocated_pages_ == MAX_VALID_PAGE_ID;
}

page_id_t DiskManager::AllocatePage()
{
    unsigned pageId;

    if (isFull())
    {
        // 表明此时已经不存在空分区
        currentFreeExtent = -1;
        return INVALID_PAGE_ID;
    }

    if (currentFreeExtent == -1)
    {
        // 此时已有的分区的页已经全部分配完了，但是可以申请新的分区
        // 注意，此时原位图页数据已经写回

        // 增加分配的分区数
        diskFileMetaPage.num_extents_ ++;

        // 将修改后的信息写回数组
        writerNumber(4, diskFileMetaPage.num_extents_, meta_data_);

        // 申请具有空页的新分区，新分区的编号为 当前总分区数减 1
        currentFreeExtent = (int)(diskFileMetaPage.num_extents_ - 1);
        // 重置 currentBitMap 对象
        currentBitmapPage.page_allocated_ = currentBitmapPage.next_free_page_ = 0;
        memset(currentBitmapPage.bytes, 0, BitmapPage<PAGE_SIZE>::MAX_CHARS);

        // 将该分区分配的页数置 0
        diskFileMetaPage.extent_used_page_[currentFreeExtent] = 0;

        // 将修改后的信息写回
        writerNumber(currentFreeExtent * 4 + 8, diskFileMetaPage.extent_used_page_[currentFreeExtent], meta_data_);
    }

    // 从有空页的分区中分配一个空页
    bool result = currentBitmapPage.AllocatePage(pageId);

    if (!result)
    {
        // 表明分配操作失败
        return INVALID_PAGE_ID;
    }

    /*
     * 之前得到的页号是关于当前位图页的偏移量，需要把他转化为相对于元信息页的偏移量（逻辑页号）
     */

    pageId += currentFreeExtent * BITMAP_SIZE;

    // 分区对应的记录加 1
    diskFileMetaPage.extent_used_page_[currentFreeExtent] ++;
    // 总的分配页的数量加 1
    diskFileMetaPage.num_allocated_pages_ ++;

    // 将修改后的信息写回数组
    writerNumber(0, diskFileMetaPage.num_allocated_pages_, meta_data_);
    writerNumber(currentFreeExtent * 4 + 8, diskFileMetaPage.extent_used_page_[currentFreeExtent], meta_data_);

    if (currentBitmapPage.isFull())
    {

        // 表明当前分区已经不存在可以分配的空数据页
        // 需要在已经开辟的分区中寻找具有下一个可以分配的分区

        // 在寻找新分区之前，需要将原分区位图页的数据写回
        writeBitmapPage(currentFreeExtent, currentBitmapPage);

        if (isFull())
        {
            // 表明此时已经不存在空分区
            currentFreeExtent = -1;
        } else {
            findNextFreeExtent();
        }
    }

    // 返回申请到的数据页的逻辑页号
    return (int)pageId;
}

bool DiskManager::AllocatePage(page_id_t logical_page_id)
{
    // 首先需要把逻辑页号转化为相对于对应位图页的偏移量
    unsigned bitmapPageId = logical_page_id / BITMAP_SIZE;
    unsigned pageId = logical_page_id % BITMAP_SIZE;

    if (bitmapPageId >= diskFileMetaPage.num_extents_ || pageId >= BITMAP_SIZE)
    {
        // 数组越界
        std::cout << "DiskManager::AllocatePage(page_id_t logical_page_id): disk_manager index overflow" << std::endl;
        return false;
    }

    // 判断要处理的分区是否是当前分区
    if (bitmapPageId == (unsigned) currentFreeExtent)
    {
        // 要处理的分区是当前分区
        if (currentBitmapPage.IsPageFree(pageId))
        {
            // 申请的页没有被分配
            currentBitmapPage.AllocateDefinitePage(pageId);
        } else {
            // 申请的页已经分配，直接返回
            return true;
        }

        // 下面处理当前分区满的情况

        if (currentBitmapPage.isFull())
        {
            // 表明当前分区已经不存在可以分配的空数据页
            // 需要寻找具有下一个可以分配的分区

            // 在寻找新分区之前，需要将原分区位图页的数据写回
            writeBitmapPage(currentFreeExtent, currentBitmapPage);

            if (isFull())
            {
                // 表明此时已经不存在空页
                currentFreeExtent = -1;
            } else {
                findNextFreeExtent();
            }
        }

    } else {
        // 读入相应的位图页
        BitmapPage<PAGE_SIZE> temp;
        readBitmapPage(bitmapPageId, temp);

        if (temp.IsPageFree(pageId))
        {
            // 申请的页没有被分配
            temp.AllocateDefinitePage(pageId);
            // 将更改后的位图页信息写回
            writeBitmapPage(bitmapPageId, temp);
        } else {
            // 申请的页已经分配，直接返回
            return true;
        }
    }

    // 修改元信息
    diskFileMetaPage.num_allocated_pages_ ++;
    diskFileMetaPage.extent_used_page_[bitmapPageId] ++;

    // 将修改后的信息写回数组
    writerNumber(0, diskFileMetaPage.num_allocated_pages_, meta_data_);
    writerNumber(bitmapPageId * 4 + 8, diskFileMetaPage.extent_used_page_[bitmapPageId], meta_data_);

    return true;
}

void DiskManager::DeAllocatePage(page_id_t logical_page_id)
{
    // 首先需要把逻辑页号转化为相对于对应位图页的偏移量
    unsigned bitmapPageId = logical_page_id / BITMAP_SIZE;
    unsigned pageId = logical_page_id % BITMAP_SIZE;

    if (bitmapPageId >= diskFileMetaPage.num_extents_ || pageId >= BITMAP_SIZE)
    {
        // 数组越界
        std::cout << "disk_manager index overflow" << std::endl;
        return;
    }

    // 判断要处理的分区是否是当前分区
    if (bitmapPageId == (unsigned) currentFreeExtent)
    {
        // 要处理的分区是当前分区
        if (currentBitmapPage.IsPageFree(pageId))
        {
            // 该页已经被释放，直接返回
            return;
        } else {
            currentBitmapPage.DeAllocatePage(pageId);
        }
    } else {
        // 读入相应的位图页
        BitmapPage<PAGE_SIZE> temp;
        readBitmapPage(bitmapPageId, temp);

        if (temp.IsPageFree(pageId))
        {
            // 该页已经被释放，直接返回
            return;
        }

        // 标记删除该页之前是否存在非满分区
        bool flag = isFull();

        // 释放页空间
        temp.DeAllocatePage(pageId);

        // 如果删除该页之前不存在非满分区，更新非满分区标记
        if (flag)
        {
            currentFreeExtent = (int)bitmapPageId;
            currentBitmapPage = temp;
        }

        // 将更改后的位图页信息写回
        writeBitmapPage(bitmapPageId, temp);
    }

    // 修改元信息
    diskFileMetaPage.num_allocated_pages_ --;
    diskFileMetaPage.extent_used_page_[bitmapPageId] --;

    // 将修改后的信息写回数组
    writerNumber(0, diskFileMetaPage.num_allocated_pages_, meta_data_);
    writerNumber(bitmapPageId * 4 + 8, diskFileMetaPage.extent_used_page_[bitmapPageId], meta_data_);
}

bool DiskManager::IsPageFree(page_id_t logical_page_id)
{
    // 首先需要把逻辑页号转化为相对于对应位图页的偏移量
    unsigned bitmapPageId = logical_page_id / BITMAP_SIZE;
    unsigned pageId = logical_page_id % BITMAP_SIZE;

    if (bitmapPageId == (unsigned) currentFreeExtent)
    {
        return currentBitmapPage.IsPageFree(pageId);
    } else {
        // 读入相应的位图页
        BitmapPage<PAGE_SIZE> temp;
        readBitmapPage(bitmapPageId, temp);
        return temp.IsPageFree(pageId);
    }
}

page_id_t DiskManager::MapPageId(page_id_t logical_page_id)
{
    return logical_page_id + logical_page_id / BITMAP_SIZE + 2;
}


void DiskManager::findNextFreeExtent()
{
    // 标记是否找到已分配的未满分区
    bool flag = false;

    for (unsigned i = 0; i < diskFileMetaPage.num_extents_; i++)
    {
        if (diskFileMetaPage.extent_used_page_[i] < BITMAP_SIZE)
        {
            // 当前分区具有空页，读入该分区位图页的数据
            readBitmapPage((int)i, currentBitmapPage);
            // 标记该位图页所在的分区
            currentFreeExtent = (int)i;
            flag = true;
            break;
        }
    }

    if (!flag)
    {
        // 不存在已分配的未满分区
        currentFreeExtent = -1;
    }
}


int DiskManager::GetFileSize(const std::string &file_name)
{
    struct stat stat_buf;
    int rc = stat(file_name.c_str(), &stat_buf);
    return rc == 0 ? stat_buf.st_size : -1;
}

void DiskManager::ReadPhysicalPage(page_id_t physical_page_id, char *page_data)
{
    // 本次读取的起始位置
    int offset = physical_page_id * PAGE_SIZE;

    // check if read beyond file length
    if (offset >= GetFileSize(file_name_))
    {
        // 当前文件已经完全读取完毕，不存在可读取内容
        #ifdef ENABLE_BPM_DEBUG
            LOG(INFO) << "Read less than a page" << std::endl;
        #endif
        memset(page_data, 0, PAGE_SIZE);
    } else {
        // 将文件数据读入 page_data，本质上是一个字符数组

        // set read cursor to offset
        db_io_.seekp(offset);
        // 读入 PAGE_SIZE 大小的字符
        db_io_.read(page_data, PAGE_SIZE);

        // if file ends before reading PAGE_SIZE
        int read_count = db_io_.gcount();
        if (read_count < PAGE_SIZE)
        {
            #ifdef ENABLE_BPM_DEBUG
                  LOG(INFO) << "Read less than a page" << std::endl;
            #endif
            memset(page_data + read_count, 0, PAGE_SIZE - read_count);
        }
    }
}

void DiskManager::WritePhysicalPage(page_id_t physical_page_id, const char *page_data)
{
  size_t offset = static_cast<size_t>(physical_page_id) * PAGE_SIZE;
  // set write cursor to offset
  db_io_.seekp(offset);
  db_io_.write(page_data, PAGE_SIZE);
  // check for I/O error
  if (db_io_.bad()) {
    LOG(ERROR) << "I/O error while writing";
    return;
  }
  // needs to flush to keep disk file in sync
  db_io_.flush();
}

/**
 * 将从 offset 开始的 4 个 char 合并为 1 个 int，采用小端存储
 * @param offset
 * @return
 */
unsigned DiskManager::getNumber(unsigned offset, const char arr[])
{
    return (arr[offset + 3] << 24) | (arr[offset + 2] << 16) | (arr[offset + 1] << 8) | arr[offset];
}

void DiskManager::writerNumber(unsigned int offset, unsigned int result, char arr[])
{
    arr[offset] = (char) (result);
    arr[offset + 1] = (char) (result >> 8);
    arr[offset + 2] = (char) (result >> 16);
    arr[offset + 3] = (char) (result >> 24);
}

void DiskManager::readBitmapPage(int offset, BitmapPage<PAGE_SIZE>& temp)
{
    char* result = new char[PAGE_SIZE];
    ReadPhysicalPage((int)(offset * BITMAP_SIZE) + 1, result);
    temp.page_allocated_ = getNumber(0, result);
    temp.next_free_page_ = getNumber(4, result);
    memcpy(temp.bytes, result + 8, BitmapPage<PAGE_SIZE>::MAX_CHARS);
}

void DiskManager::writeBitmapPage(int offset, BitmapPage<PAGE_SIZE>& temp)
{
    char* result = new char[PAGE_SIZE];
    writerNumber(0, temp.page_allocated_, result);
    writerNumber(4, temp.next_free_page_, result);
    memcpy(result + 8, temp.bytes, BitmapPage<PAGE_SIZE>::MAX_CHARS);
    WritePhysicalPage((int)(offset * BITMAP_SIZE) + 1, result);
}