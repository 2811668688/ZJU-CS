#include "storage/table_heap.h"
#include "page/page.h"
#include "page/table_page.h"

//bool TableHeap::InsertTuple(Row &row, Transaction *txn) {
//  if(row.GetSerializedSize(schema_)+32>PAGE_SIZE)//别超了
//    return false;
//  auto page = reinterpret_cast <TablePage *>(buffer_pool_manager_->FetchPage(first_page_id_));
//  if(page->GetData()[16]==0&&page->GetData()[17]==0&&page->GetData()[18]==0&&page->GetData()[19]==0)
//  {
//    page->SetPrevPageId(INVALID_PAGE_ID);
//    page->SetNextPageId(INVALID_PAGE_ID);
//    page->SetFreeSpacePointer(PAGE_SIZE);
//    page->SetTupleCount(0);
//  }
//  if(page==nullptr)
//    return false;
//  page->WLatch();//能写就开始写
//  while(!page->InsertTuple(row,schema_ , txn, lock_manager_, log_manager_)) {
//    page_id_t page_Id = page->GetNextPageId();
//    if (page_Id != INVALID_PAGE_ID)  // 还有能用的
//    {
//      page->WUnlatch();
//      buffer_pool_manager_->UnpinPage(page->GetTablePageId(), false);
//      page = reinterpret_cast<TablePage *>(buffer_pool_manager_->FetchPage(page_Id));
//      if(page->GetData()[16]==0&&page->GetData()[17]==0&&page->GetData()[18]==0&&page->GetData()[19]==0)
//      {
//        page->SetPrevPageId(page->GetPageId());
//        page->SetNextPageId(INVALID_PAGE_ID);
//        page->SetFreeSpacePointer(PAGE_SIZE);
//        page->SetTupleCount(0);
//      }
//      if (page == nullptr) return false;
//      page->WLatch();
//    } else  // 都用完了得重新开一个
//    {
//      auto new_page = reinterpret_cast<TablePage *>(buffer_pool_manager_->NewPage(page_Id));
//      if (new_page == nullptr) {//开不了
//        page->WUnlatch();
//        buffer_pool_manager_->UnpinPage(page->GetTablePageId(), false);
//        return false;
//      }
//      new_page->SetPrevPageId(INVALID_PAGE_ID);
//      new_page->SetNextPageId(INVALID_PAGE_ID);
//      new_page->SetFreeSpacePointer(PAGE_SIZE);
//      new_page->SetTupleCount(0);
//      new_page->WLatch();
//      page->SetNextPageId(page_Id);
//      page->WUnlatch();
//      new_page->Init(page_Id, page->GetTablePageId(), log_manager_, txn);
//      buffer_pool_manager_->UnpinPage(page->GetTablePageId(), true);
//      page = new_page;
//    }
//  }
//  page->WUnlatch();
//  buffer_pool_manager_->UnpinPage(page->GetTablePageId(), true);
//  return true;
//}

bool TableHeap::InsertTuple(Row &row, Transaction *txn) {

  //LOG(INFO) << first_page_id_;
  TablePage *cur_page=reinterpret_cast< TablePage * >( buffer_pool_manager_->FetchPage(first_page_id_) );
  //Page * testpage = nullptr;
  //LOG(INFO) << cur_page << " + " << first_page_id_;
  //LOG(INFO) << testpage << " + " << first_page_id_;
  //LOG(INFO) << nullptr;

  //no page returned
  if(cur_page==nullptr){
    ASSERT( false , " no page ");
    return false;
  }

  //LOG(INFO) << cur_page->GetData() ;
  //fisrt page returned
  cur_page->WLatch();

  //insert the row into the first page which has enough space for the row
  //if it doesn't exist, create a new page

  /*
    testpage.Init(0, INVALID_PAGE_ID, nullptr, nullptr);
    testpage.InsertTuple( row , schema_ , txn , lock_manager_ , log_manager_ );
  */

  //ASSERT(false," test ");
  while(!cur_page->InsertTuple( row , schema_ , txn , lock_manager_ , log_manager_ )){
    //current page doesn't have enough space --> move to next page
    //ASSERT(false," test ");
    page_id_t next_page_id=cur_page->GetNextPageId();
    if(next_page_id!=INVALID_PAGE_ID){
      //unlatch & unpin current page
      cur_page->WUnlatch();
      buffer_pool_manager_->UnpinPage(cur_page->GetPageId(),false);
      //change cur_page into next_page
      cur_page=static_cast<TablePage*>(buffer_pool_manager_->FetchPage(next_page_id));
      cur_page->WLatch();
    }
    //no table_page available in table_heap, create a new page
    else{
      page_id_t new_page_id;
      TablePage* new_page=static_cast<TablePage*>(buffer_pool_manager_->NewPage(new_page_id));
      if(new_page==nullptr){
        //can not allocate new page,unlatch & unpin cur_page and return false
        cur_page->WUnlatch();
        buffer_pool_manager_->UnpinPage(cur_page->GetPageId(),false);
        return false;
      }
      else{
        //new page created, initialize it(insert is implemented in while())
        new_page->WLatch();
        cur_page->SetNextPageId(new_page_id);
        new_page->Init(new_page_id,cur_page->GetPageId(),log_manager_,txn);
        //(similar to next_page):unlatch & unpin current page
        cur_page->WUnlatch();
        buffer_pool_manager_->UnpinPage(cur_page->GetPageId(),true);  //next_page_id changed
        //change cur_page into new_page(already latch)
        cur_page=new_page;
      }
    }
  }
  //ASSERT(false , " 2 ");
  //insert finished,unlatch & unpin current page
  cur_page->WUnlatch();
  buffer_pool_manager_->UnpinPage(cur_page->GetPageId(),true);
  return true;
}

bool TableHeap::MarkDelete(const RowId &rid, Transaction *txn) {
  // Find the page which contains the tuple.
  auto page = reinterpret_cast<TablePage *>(buffer_pool_manager_->FetchPage(rid.GetPageId()));
  // If the page could not be found, then abort the transaction.
  if (page == nullptr) {
    return false;
  }
  // Otherwise, mark the tuple as deleted.
  page->WLatch();
  page->MarkDelete(rid, txn, lock_manager_, log_manager_);
  page->WUnlatch();
  buffer_pool_manager_->UnpinPage(page->GetTablePageId(), true);
  return true;
}

bool TableHeap::UpdateTuple(const Row &row, const RowId &rid, Transaction *txn)
{
  //判断大小是否合适,如果太大放不进去，return false

  Row r(rid);
  auto page = reinterpret_cast<TablePage *>(buffer_pool_manager_->FetchPage(rid.GetPageId()));
  if(page== nullptr)
    return false;
  uint32_t slot_num = rid.GetSlotNum();
  uint32_t UpdatedTupleSize=row.GetSerializedSize(schema_);
  uint32_t OldTupleSize=page->GetTupleSize(slot_num);
  uint32_t remain1=page->GetFreeSpaceRemaining();
  if(remain1+OldTupleSize<UpdatedTupleSize)//放不下
  {
    Row row1=row;
    MarkDelete(rid,txn);
    ApplyDelete(rid,txn);
    InsertTuple(row1,txn);
  } else {
      //能放下
    page->WLatch();
    bool result=page->UpdateTuple( row, &r, schema_, txn, lock_manager_, log_manager_);//第二个接口为oldRow的地址
    page->WUnlatch();
    buffer_pool_manager_->UnpinPage(page->GetTablePageId(), result);
    return result;
  }
    return false;
}

void TableHeap::ApplyDelete(const RowId &rid, Transaction *txn) {
  // Step1: Find the page which contains the tuple.
  // Step2: Delete the tuple from the page.
  auto page = reinterpret_cast<TablePage *>(buffer_pool_manager_->FetchPage(rid.GetPageId()));
  ASSERT(page!=nullptr,"page is null");
  page->WLatch();
  page->ApplyDelete(rid,txn,log_manager_);
  page->WUnlatch();
  buffer_pool_manager_->UnpinPage(page->GetTablePageId(),true);
}

void TableHeap::RollbackDelete(const RowId &rid, Transaction *txn) {
  // Find the page which contains the tuple.
  auto page = reinterpret_cast<TablePage *>(buffer_pool_manager_->FetchPage(rid.GetPageId()));
  assert(page != nullptr);
  // Rollback the delete.
  page->WLatch();
  page->RollbackDelete(rid, txn, log_manager_);
  page->WUnlatch();
  buffer_pool_manager_->UnpinPage(page->GetTablePageId(), true);
}

void TableHeap::FreeHeap() {
  if(first_page_id_==INVALID_PAGE_ID)
    return ;
  auto page = reinterpret_cast<TablePage *>(buffer_pool_manager_->FetchPage(first_page_id_));
  int next_pageID=page->GetNextPageId();
  buffer_pool_manager_->DeletePage(first_page_id_);
  while(next_pageID!=INVALID_PAGE_ID)
  {
    int temp=next_pageID;
    auto nextpage = reinterpret_cast<TablePage *>(buffer_pool_manager_->FetchPage(next_pageID));
    next_pageID=nextpage->GetNextPageId();
    buffer_pool_manager_->DeletePage(temp);
  }
}

bool TableHeap::GetTuple(Row *row, Transaction *txn) {
  auto page = reinterpret_cast<TablePage *>(buffer_pool_manager_->FetchPage(row->GetRowId().GetPageId()));
  if(page== nullptr)
    return false;
  page->RLatch();//开启读权限
  bool result=page->GetTuple(row,schema_,txn,lock_manager_);
  page->RUnlatch();
  buffer_pool_manager_->UnpinPage(row->GetRowId().GetPageId(),false);
  return result;
}

TableIterator TableHeap::Begin(Transaction *txn) {
  auto page=reinterpret_cast<TablePage *>(buffer_pool_manager_->FetchPage(first_page_id_));
  page->RLatch();
  //  Row* r=new Row(RowId());
  RowId rid;
  page->GetFirstTupleRid(&rid);
  page->RUnlatch();
  buffer_pool_manager_->UnpinPage(first_page_id_,false);
  return TableIterator(this, rid, txn);
}

TableIterator TableHeap::End() {
  RowId rid;
  rid.Set(INVALID_PAGE_ID,0);
  return TableIterator(this, rid ,nullptr);
  //End是不能进的那个
}

// 递归删除数据表
void TableHeap::deleteTable(page_id_t page_id)
{
    if (page_id != INVALID_PAGE_ID)
    {
        auto temp_table_page = reinterpret_cast<TablePage *>(buffer_pool_manager_->FetchPage(page_id));  // 删除table_heap
        if(temp_table_page->GetNextPageId() != INVALID_PAGE_ID)
        {
            deleteTable(temp_table_page->GetNextPageId());
        }
        buffer_pool_manager_->UnpinPage(page_id, false);
        buffer_pool_manager_->DeletePage(page_id);
    } else {
        deleteTable(first_page_id_);
    }
}

