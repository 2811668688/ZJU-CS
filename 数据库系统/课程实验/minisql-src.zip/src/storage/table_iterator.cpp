#include "common/macros.h"
#include "storage/table_iterator.h"
#include "storage/table_heap.h"

TableIterator::TableIterator(TableHeap* tableheap,RowId rid,Transaction *txn_):tableheap_(tableheap),row(new Row(rid)),txn(txn_){
  if(rid.GetPageId()!=INVALID_PAGE_ID)
  {
    tableheap_->GetTuple(row,txn);
  }
}

TableIterator::TableIterator(const TableIterator &other):tableheap_(other.tableheap_),row(other.row),txn(other.txn) {}

const Row &TableIterator::operator*() {
  //  ASSERT(false, "Not implemented yet.");
  return *row;
}

Row *TableIterator::operator->() {
  return this->row;
}

Row *TableIterator::GetRow(){
  return this->row;
}

TableIterator &TableIterator::operator++() {  // 前置++
  BufferPoolManager *buffer_pool_manager_ = tableheap_->buffer_pool_manager_;
  auto page = reinterpret_cast<TablePage *>(buffer_pool_manager_->FetchPage(row->GetRowId().GetPageId()));
  page->RLatch();
  ASSERT(page != nullptr, "page is null");
  RowId new_rid;
  if(!page->GetNextTupleRid(row->GetRowId(),&new_rid))//没有返回下一个说明不在这页了
  {
    while(page->GetNextPageId()!=INVALID_PAGE_ID)
    {
      page->RUnlatch();
      buffer_pool_manager_->UnpinPage(page->GetPageId(),false);
      page=reinterpret_cast<TablePage *>(buffer_pool_manager_->FetchPage(page->GetNextPageId()));
      page->RLatch();
      if(page->GetFirstTupleRid(&new_rid))
        break;
    }
  }
  row->SetRowId(new_rid);
  if(tableheap_->End()!=*this)
    tableheap_->GetTuple( row, txn);
  page->RUnlatch();
  buffer_pool_manager_->UnpinPage(row->GetRowId().GetPageId(),false);
  return *this;
}
TableIterator TableIterator::operator++(int) {
  TableIterator T(*this);
  ++(*this);
  return T;
}

