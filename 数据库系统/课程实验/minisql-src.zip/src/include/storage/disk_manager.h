#ifndef DISK_MGR_H
#define DISK_MGR_H

#include <atomic>
#include <fstream>
#include <iostream>
#include <mutex>
#include <string>
#include "common/config.h"
#include "common/macros.h"
#include "page/bitmap_page.h"
#include "page/disk_file_meta_page.h"

/**
 * DiskManager takes care of the allocation and de allocation of pages within a database.
 * It performs the reading and writing of pages to and from disk,
 * providing a logical file layer within the context of a database management system.
 *
 * Disk page storage format: (Free Page BitMap Size = PAGE_SIZE * 8, we note it as N)
 * | Meta Page | Free Page BitMap 1 | Page 1 | Page 2 | ....
 *      | Page N | Free Page BitMap 2 | Page N+1 | ... | Page 2N | ... |
 */
class DiskManager {
    friend class BufferPoolManager;

public:
  explicit DiskManager(const std::string &db_file);

  ~DiskManager()
  {
    if (!closed)
    {
      Close();
    }
  }

  /**
   * Read page from specific page_id
   * Note: page_id = 0 is reserved for disk meta page
   */
  void ReadPage(page_id_t logical_page_id, char *page_data);

  /**
   * Write data to specific page
   * Note: page_id = 0 is reserved for disk meta page
   */
  void WritePage(page_id_t logical_page_id, const char *page_data);

  /**
   * Get next free page from disk
   * @return logical page id of allocated page
   */
  page_id_t AllocatePage();

  /**
   * 分配指定的数据页
   * @param logical_page_id 待分配的数据页
   */
  bool AllocatePage(page_id_t logical_page_id);

  /**
   * Free this page and reset bit map
   */
  void DeAllocatePage(page_id_t logical_page_id);

  /**
   * Return whether specific logical_page_id is free
   */
  bool IsPageFree(page_id_t logical_page_id);

  /**
   * Shut down the disk manager and close all the file resources.
   */
  void Close();

  /**
   * Get Meta Page
   * Note: Used only for debug
   */
  char *GetMetaData()
  {
      return meta_data_;
  }

    /**
    * 将从 offset 开始的 4 个 char 合并为 1 个 int
    * @param offset
    * @return
    */
    static unsigned getNumber(unsigned offset, const char arr[]);

    /**
     * 将一个整数写入从 offset 开始的 4 个 char 中，采用小端存储
     * @param offset
     * @param result 待写入的整数
     */
    static void writerNumber(unsigned offset, unsigned result, char arr[]);

    /**
     * 读取一个标号为 offset 的位图页
     * @param offset
     */
    void readBitmapPage(int offset, BitmapPage<PAGE_SIZE>& temp);

    /**
     * 将一个标号为 offset 的位图页写入磁盘
     * @param offset
     */
    void writeBitmapPage(int offset, BitmapPage<PAGE_SIZE>& temp);

    /**
     * 寻找下一个已分配的未满的分区
     */
    void findNextFreeExtent();

    static constexpr size_t BITMAP_SIZE = BitmapPage<PAGE_SIZE>::GetMaxSupportedSize();

private:
  /**
   * Helper function to get disk file size
   */
  int GetFileSize(const std::string &file_name);

  /**
   * Read physical page from disk
   */
  void ReadPhysicalPage(page_id_t physical_page_id, char *page_data);

  /**
   * Write data to physical page in disk
   */
  void WritePhysicalPage(page_id_t physical_page_id, const char *page_data);

  /**
   * Map logical page id to physical page id
   */
  page_id_t MapPageId(page_id_t logical_page_id);

  bool isFull() const;

private:
    // stream to write db file
    std::fstream db_io_;
    std::string file_name_;
    // with multiple buffer pool instances, need to protect file access
    std::recursive_mutex db_io_latch_{};
    bool closed{false};

    // 元信息数组，存储磁盘元数据
    char meta_data_[PAGE_SIZE];

    // 当前具有可分配空页的位图页数据
    BitmapPage<PAGE_SIZE> currentBitmapPage = BitmapPage<PAGE_SIZE>();

    // 当前位图页所在的分区编号
    int currentFreeExtent{-1};

    // 解析元信息数组
    DiskFileMetaPage diskFileMetaPage;
};

#endif