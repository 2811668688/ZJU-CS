#ifndef MINISQL_TABLE_ITERATOR_H
#define MINISQL_TABLE_ITERATOR_H

#include "common/rowid.h"
#include "record/row.h"
#include "transaction/transaction.h"


class TableHeap;

class TableIterator {

 public:
  // you may define your own constructor based on your member variables
  explicit TableIterator(TableHeap* tableheap,RowId rid,Transaction *txn_);

  //  explicit TableIterator(Row r);
  //
  TableIterator(const TableIterator &other);

  ~TableIterator() {
    delete row;
  }

  //  explicit TableIterator (Row* r);

  inline bool operator==(const TableIterator &itr) const{
    bool flag = (row->GetRowId() == itr.row->GetRowId() );
    return flag;
  };

  inline bool operator!=(const TableIterator &itr) const{
    return ( !( *this == itr ) );
  };


  const Row &operator*();

  Row *operator->();

  Row *GetRow();

  TableIterator &operator++();

  TableIterator operator++(int);

 private:
  // add your own private member variables here
  TableHeap *tableheap_;
  Row* row;
  Transaction *txn;
};

#endif //MINISQL_TABLE_ITERATOR_H
