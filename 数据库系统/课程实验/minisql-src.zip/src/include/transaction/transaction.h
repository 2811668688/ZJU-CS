#ifndef MINISQL_TRANSACTION_H
#define MINISQL_TRANSACTION_H

/**
 * Transaction tracks information related to a transaction.
 *
 * Implemented by student self
*/
class Transaction {

};

#endif  // MINISQL_TRANSACTION_H
