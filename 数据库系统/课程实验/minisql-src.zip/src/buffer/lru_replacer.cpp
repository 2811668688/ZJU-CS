#include "buffer/lru_replacer.h"
#include<iostream>
#include <sys/timeb.h>
#include <chrono>
#include <thread>

LRUReplacer::LRUReplacer(size_t num_pages)
{
    this->capacity = num_pages;
}

LRUReplacer::~LRUReplacer() = default;

bool LRUReplacer::Victim(frame_id_t *frame_id)
{
    if (lruMap.empty())
    {
        // 表明所有的页都被锁定
        return false;
    }

    // 选择列表尾部 也就是最少使用的 frameId
    frame_id_t lru_frame = lruList.back();

    // 删除对应的映射关系
    lruMap.erase(lru_frame);
    // 列表删除
    lruList.pop_back();
    *frame_id = lru_frame;

    // 返回操作成功信息
    return true;
}

void LRUReplacer::Pin(frame_id_t frame_id)
{
    if (lruMap.count(frame_id) != 0)
    {
        lruList.erase(lruMap[frame_id]);
        lruMap.erase(frame_id);
    }
}

void LRUReplacer::Unpin(frame_id_t frame_id)
{
    // 加入 lru list 中
    if (lruMap.count(frame_id) != 0)
    {
        // 表明当前页面已经解锁了，直接返回
        return;
    }

    // 当前释放的页超出了管理范围，需要移除最近使用的页
    while (Size() >= capacity)
    {
        frame_id_t need_del = lruList.front();
        lruList.pop_front();
        lruMap.erase(need_del);
    }
    // insert
    lruList.push_front(frame_id);
    lruMap[frame_id] = lruList.begin();
}

size_t LRUReplacer::Size()
{
    return lruMap.size();
}