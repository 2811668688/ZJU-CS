#include <cstring>
#include "buffer/buffer_pool_manager.h"
#include "glog/logging.h"
#include "page/bitmap_page.h"

BufferPoolManager::BufferPoolManager(size_t pool_size, DiskManager *disk_manager)
        : pool_size_(pool_size), disk_manager_(disk_manager)
{
    pages_ = new Page[pool_size_];
    replacer_ = new LRUReplacer(pool_size_);
    for (size_t i = 0; i < pool_size_; i++)
    {
        // 在初始情况下，所有的页都没有写入数据，都属于空闲页
        free_list_.emplace_back(i);
    }
}

BufferPoolManager::~BufferPoolManager()
{
      for (auto page: page_table_)
      {
        FlushPage(page.first);
      }
      delete[] pages_;
      delete replacer_;
      page_table_.clear();
      free_list_.clear();
}


Page *BufferPoolManager::FetchPage(page_id_t page_id)
{
    // 1.     Search the page table for the requested page (P).
    // 1.1    If P exists, pin it and return it immediately.
    // 1.2    If P does not exist, find a replacement page (R) from either the free list or the replacer.
    //        Note that pages are always found from the free list first.
    // 2.     If R is dirty, write it back to the disk.
    // 3.     Delete R from the page table and insert P.
    // 4.     Update P's metadata, read in the page content from disk, and then return a pointer to P.

    /*
     * 首先根据逻辑页号，寻找缓存池中所对应的页帧
     */

    int frameID = -1;   // 逻辑页号在缓存池中所对应的页帧 （Pages 数组中该页的下标）

    auto iter = page_table_.begin();
    while (iter != page_table_.end())
    {
        if (iter->first == page_id)
        {
            // 当前缓存池中存在对应的页
            frameID = iter->second;
            break;
        }
        iter ++;
    }

    if (frameID != -1)
    {
        // 当前缓存池中存在对应的页

        // 将当前页锁住，replacer_ 内部会自动修改该页的调用时间
        replacer_->Pin(frameID);
        // 请求该页的线程加 1
        pages_[frameID].pin_count_ ++;

        // 返回所请求的页
        return &pages_[frameID];
    }

    /*
     * 当前缓存池中不存在对应的页，
     * 首先要为需要读入的页提供一个容器 ( pages_ 数组的一个下标 frameID)
     */

    if (!free_list_.empty())
    {
        // 当前缓存池中存在未分配的空页
        // 获取缓存池中的空页
        frameID = free_list_.front();
        free_list_.pop_front();
    } else {
        // 当前缓存池中所有的页都已经分配完成，需要利用 LRU 原则腾出一个空页

        if (!replacer_->Victim(&frameID))
        {
            // 表明不存在可替换的页，因此无法获取新页，返回空指针
            return nullptr;
        }

        // 接下来需要处理被替换的页，如果该页是脏页，将其写回磁盘
        if (pages_[frameID].is_dirty_)
        {
            FlushPage(pages_[frameID].page_id_, frameID);
        }

        // 同时，删除对应的逻辑页号在 page_table_ 中的绑定关系
        page_table_.erase(pages_[frameID].page_id_);
    }

    /*
     * 此时已经为新数据页找到了容器 (frameID)
     * 接下来需要 DiskManager 响应 BufferPoolManager 的页请求，提供新数据
     */

    // 向 disk_manager 请求该页
    disk_manager_->AllocatePage(page_id);

    /*
     * 此时，逻辑页中的数据已经存在，把数据放到容器中
     */

    // 首先绑定对应的逻辑号
    page_table_[page_id] = frameID;

    // 修改 page 页中的相关属性
    pages_[frameID].ResetMemory();
    pages_[frameID].page_id_ = page_id;
    pages_[frameID].is_dirty_ = false;

    // 从磁盘中读入数据
    disk_manager_->ReadPage(page_id, pages_[frameID].data_);

    // 调用 UnPin 方法，将新生成的页面放入 LRU 管理
    replacer_->Unpin(frameID);

    // 将该页钉住，同时将该页的占有线程加 1
    replacer_->Pin(frameID);
    pages_[frameID].pin_count_ += 1;

    // 处理完毕，返回对应的指针
    return &pages_[frameID];
}

Page *BufferPoolManager::NewPage(page_id_t &page_id)
{
    // 0.   Make sure you call AllocatePage!
    // 1.   If all the pages in the buffer pool are pinned, return nullptr.
    // 2.   Pick a victim page P from either the free list or the replacer.
    //      Always pick from the free list first.
    // 3.   Update P's metadata, zero out memory and add P to the page table.
    // 4.   Set the page ID output parameter. Return a pointer to P.

    // 保存副本
    int page_id_copy = page_id;
    unsigned next_free_page_copy = disk_manager_->currentBitmapPage.next_free_page_;

    // 首先获取新申请页的逻辑页号
    page_id = AllocatePage();

    if (page_id == INVALID_PAGE_ID)
    {
        // 表明当前已经不存在空页了
        std::cout << "no free page" << std::endl;
        return nullptr;
    }

    // 为申请到的新页号准备容器

    int frameID = -1;   // 逻辑页号在缓存池中所对应的页帧 （Pages 数组中该页的下标）

    if (!free_list_.empty())
    {
        // 当前缓存池中存在未分配的空页
        // 获取缓存池中的空页
        frameID = free_list_.front();
        free_list_.pop_front();
    } else {
        // 当前缓存池中所有的页都已经分配完成，需要利用 LRU 原则腾出一个空页

        if (!replacer_->Victim(&frameID))
        {
            // 表明不存在可替换的页，因此无法获取新页，返回空指针
            // 首先要将已经申请的空页注销
            DeallocatePage(page_id);
            page_id = page_id_copy; // 保证 page_id 的值不变
            // 恢复位图页的下一个分配的页数
            disk_manager_->currentBitmapPage.next_free_page_ = next_free_page_copy;
            return nullptr;
        }

        // 接下来需要处理被替换的页，如果该页是脏页，将其写回磁盘
        if (pages_[frameID].is_dirty_)
        {
            FlushPage(pages_[frameID].page_id_, frameID);
        }

        // 同时，删除对应的逻辑页号在 page_table_ 中的绑定关系
        page_table_.erase(pages_[frameID].page_id_);

    }

    // 首先绑定对应的逻辑号
    page_table_[page_id] = frameID;

    // 修改 page 页中的相关属性
    pages_[frameID].ResetMemory();
    pages_[frameID].page_id_ = page_id;
    pages_[frameID].is_dirty_ = false;

    // 从磁盘中读入数据
    disk_manager_->ReadPage(page_id, pages_[frameID].data_);

    // 调用 UnPin 方法，将新生成的页面放入 LRU 管理
    replacer_->Unpin(frameID);
    // 将该页钉住，同时将该页的占有线程加 1
    replacer_->Pin(frameID);
    pages_[frameID].pin_count_ += 1;

    // 处理完毕，返回对应的指针
    return &pages_[frameID];
}

bool BufferPoolManager::DeletePage(page_id_t page_id)
{
    // 0.   Make sure you call DeallocatePage!
    // 1.   Search the page table for the requested page (P).
    // 1.   If P does not exist, return true.
    // 2.   If P exists, but has a non-zero pin-count, return false. Someone is using the page.
    // 3.   Otherwise, P can be deleted. Remove P from the page table, reset its metadata and return it to the free list.

    int frameID = -1;   // 逻辑页号在缓存池中所对应的页帧 （Pages 数组中该页的下标）

    auto iter = page_table_.begin();
    while (iter != page_table_.end())
    {
        if (iter->first == page_id)
        {
            // 当前缓存池中存在对应的页
            frameID = iter->second;
            break;
        }
        iter ++;
    }

    if (frameID != -1)
    {
        // 当前缓存池中存在对应的页

        if (pages_[frameID].pin_count_ != 0)
        {
            // 表明当前仍有线程访问该页，不能删除
            return false;
        } else {
            // 当前页可以删除

            // 1. 删除其映射关系
            page_table_.erase(page_id);

            /*
             * 在删除数据域之前判断其是否是脏页，脏页需要写回磁盘
             */

            if (pages_[frameID].is_dirty_)
            {
                FlushPage(page_id, frameID);
            }

            // 2. 重置其数据域
            pages_[frameID].ResetMemory();

            // 3. 将对应页的下标加入空闲列表
            free_list_.push_back(frameID);

            // 4. 从磁盘中删除该页
            DeallocatePage(page_id);

            // 删除完毕

            return true;
        }
    }

    // 表明当前页在缓存池中不存在
    return true;
}

bool BufferPoolManager::UnpinPage(page_id_t page_id, bool is_dirty)
{
    int frameID = -1;   // 逻辑页号在缓存池中所对应的页帧 （Pages 数组中该页的下标）

    auto iter = page_table_.begin();
    while (iter != page_table_.end())
    {
        if (iter->first == page_id)
        {
            // 当前缓存池中存在对应的页
            frameID = iter->second;
            break;
        }
        iter ++;
    }

    if (frameID == -1)
    {
        return true;
    }

    replacer_->Unpin(frameID);

    if (is_dirty)
    {
        // 将脏页写回
        FlushPage(page_id, frameID);
    }

    return true;
}

bool BufferPoolManager::FlushPage(page_id_t page_id)
{
    // 获取逻辑页在缓存池中对应的页帧
    int frameID = -1;
    auto iter = page_table_.begin();
    while (iter != page_table_.end())
    {
        if (iter->first == page_id)
        {
            // 当前缓存池中存在对应的页
            frameID = iter->second;
            break;
        }
        iter ++;
    }

    if (frameID == -1)
    {
        // 表明缓存池中不存在当前逻辑页
        return false;
    }

    return FlushPage(page_id, frameID);
}

bool BufferPoolManager::FlushPage(page_id_t page_id, frame_id_t frameID)
{
    // 这里直接将缓存区的页的数据存入磁盘
    disk_manager_->WritePage(page_id, pages_[frameID].data_);
    return true;
}

bool BufferPoolManager::FlushAllPages()
{
    auto iter = page_table_.begin();
    while (iter != page_table_.end())
    {
        FlushPage(iter->first, iter->second);
        iter ++;
    }
    return true;
}


page_id_t BufferPoolManager::AllocatePage()
{
    int next_page_id = disk_manager_->AllocatePage();
    return next_page_id;
}

void BufferPoolManager::DeallocatePage(page_id_t page_id)
{
    disk_manager_->DeAllocatePage(page_id);
}

bool BufferPoolManager::IsPageFree(page_id_t page_id) {
  return disk_manager_->IsPageFree(page_id);
}

// Only used for debug
bool BufferPoolManager::CheckAllUnpinned()
{
  bool res = true;
  for (size_t i = 0; i < pool_size_; i++)
  {
    if (pages_[i].pin_count_ != 0)
    {
      res = false;
      LOG(ERROR) << "page " << pages_[i].page_id_ << " pin count:" << pages_[i].pin_count_ << endl;
    }
  }
  return res;
}

void BufferPoolManager::printBufferPool()
{
    for (unsigned i = 0; i < pool_size_; i++)
    {
        std::cout << pages_[i].page_id_ << std::endl;
    }
}