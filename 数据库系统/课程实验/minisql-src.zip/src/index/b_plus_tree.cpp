#include <string>
#include "glog/logging.h"
#include "index/b_plus_tree.h"
#include "index/basic_comparator.h"
#include "index/generic_key.h"
#include "page/index_roots_page.h"
#include <iostream>

INDEX_TEMPLATE_ARGUMENTS
BPLUSTREE_TYPE::BPlusTree(index_id_t index_id, BufferPoolManager *buffer_pool_manager, const KeyComparator &comparator,
                          int leaf_max_size, int internal_max_size)
          : index_id_(index_id),
          buffer_pool_manager_(buffer_pool_manager),
          comparator_(comparator),
          leaf_max_size_(leaf_max_size),
          internal_max_size_(internal_max_size)
{
    this->root_page_id_ = INVALID_PAGE_ID;
}

INDEX_TEMPLATE_ARGUMENTS
void BPLUSTREE_TYPE::Destroy()
{

}

/*
 * Helper function to decide whether current b+tree is empty
 */
INDEX_TEMPLATE_ARGUMENTS
bool BPLUSTREE_TYPE::IsEmpty() const
{
    return root_page_id_ == INVALID_PAGE_ID;
}

/*****************************************************************************
 * SEARCH
 *****************************************************************************/

/*
 * Return the only value that associated with input key
 * This method is used for point query
 * @return : true means key exists
 */
INDEX_TEMPLATE_ARGUMENTS
bool BPLUSTREE_TYPE::GetValue(const KeyType &key, std::vector<ValueType> &result, Transaction *transaction)
{
    auto* page= FindLeafPage(key, false);
    bool flag = false;

    if (page != nullptr)
    {
        auto* leaf = reinterpret_cast<LeafPage *>(page->GetData());
        ValueType value;
        if (leaf->Lookup(key, value, comparator_))
        {
            result.push_back(value);
            flag = true;
        }

        buffer_pool_manager_->UnpinPage(leaf->GetPageId(), false);
    }

    return flag;
}

/*****************************************************************************
 * INSERTION
 *****************************************************************************/
/*
 * Insert constant key & value pair into b+ tree
 * if current tree is empty, start new tree, update root page id and insert
 * entry, otherwise insert into leaf page.
 * @return: since we only support unique key, if user try to insert duplicate
 * keys return false, otherwise return true.
 */
INDEX_TEMPLATE_ARGUMENTS
bool BPLUSTREE_TYPE::Insert(const KeyType &key, const ValueType &value, Transaction *transaction)
{
    return InsertIntoLeaf(key, value, transaction);
}
/*
 * Insert constant key & value pair into an empty tree
 * User needs to first ask for new page from buffer pool manager(NOTICE: throw
 * an "out of memory" exception if returned value is nullptr), then update b+
 * tree's root page id and insert entry directly into leaf page.
 */
INDEX_TEMPLATE_ARGUMENTS
void BPLUSTREE_TYPE::StartNewTree(const KeyType &key, const ValueType &value)
{
    // 首先通过 BufferPoolManager 分配一个空页
    Page* newPage = buffer_pool_manager_->NewPage(root_page_id_);
    if (newPage == nullptr)
    {
        // 报一个内存超限异常
        throw runtime_error("OUT OF MEMORY");
    }

    auto* leafPage = reinterpret_cast<LeafPage *>(newPage->GetData());
    // 更新叶节点的逻辑页号
    UpdateRootPageId(1);
    // 初始化
    leafPage->Init(root_page_id_, INVALID_PAGE_ID, leaf_max_size_);

    // 插入数据
    leafPage->Insert(key, value, comparator_);
    buffer_pool_manager_->UnpinPage(root_page_id_, true);
}

/*
 * Insert constant key & value pair into leaf page
 * User needs to first find the right leaf page as insertion target, then look
 * through leaf page to see whether insert key exist or not. If exist, return
 * immediately, otherwise insert entry. Remember to deal with split if necessary.
 * @return: since we only support unique key, if user try to insert duplicate
 * keys return false, otherwise return true.
 */
INDEX_TEMPLATE_ARGUMENTS
bool BPLUSTREE_TYPE::InsertIntoLeaf(const KeyType &key, const ValueType &value, Transaction *transaction)
{
    if (IsEmpty())
    {
        StartNewTree(key, value);
        return true;
    }

    // 找到对应的页
    Page* rightLeaf = FindLeafPage(key, false);
    // 强制类型转换
    auto* leafPage = reinterpret_cast<LeafPage *>(rightLeaf->GetData());

    // 消除 const 的影响
    ValueType tempValue = value;

    if (leafPage->Lookup(key, tempValue, comparator_))
    {
        // 当前要插入的值已经存在
        buffer_pool_manager_->UnpinPage(leafPage->GetPageId(), false);
        return false;
    }

    // 插入条目
    leafPage->Insert(key, value, comparator_);

    // 下面处理叶节点的分裂
    if (leafPage->GetSize() == leafPage->GetMaxSize() + 1)
    {
        // 获取分裂后的新节点
        auto* newLeaf = Split(leafPage);
        // 把新节点插入父节点
        InsertIntoParent(leafPage, newLeaf->KeyAt(0), newLeaf, transaction);
    }

    buffer_pool_manager_->UnpinPage(rightLeaf->GetPageId(), true);
    return true;
}

/*
 * Split input page and return newly created page.
 * Using template N to represent either internal page or leaf page.
 * User needs to first ask for new page from buffer pool manager(NOTICE: throw
 * an "out of memory" exception if returned value is nullptr), then move half
 * of key & value pairs from input page to newly created page
 */
INDEX_TEMPLATE_ARGUMENTS
template<typename N>
N *BPLUSTREE_TYPE::Split(N *node)
{
    // 要进行节点分裂首先需要生成一个新的节点
    page_id_t  newPageId;
    Page* newPage = buffer_pool_manager_->NewPage(newPageId);

    if (newPage == nullptr)
    {
        throw runtime_error("OUT OF MEMORY");
    }

    N* newNode; // 存储返回值

    if (node->IsLeafPage())
    {
        // 原节点是叶子节点，生成两个叶子节点
        auto* leafNode = reinterpret_cast<LeafPage *>(node);
        auto* newLeafNode = reinterpret_cast<LeafPage *>(newPage->GetData());
        // 填充新叶子节点的数据，这一步同时设置了父节点
        newLeafNode->Init(newPageId, leafNode->GetParentPageId(), leaf_max_size_);
        leafNode->MoveHalfTo(newLeafNode);

        // MoveHalfTo 内部不处理链表，此处更新链表
        newLeafNode->SetNextPageId(leafNode->GetNextPageId());
        leafNode->SetNextPageId(newLeafNode->GetPageId());
        newNode = reinterpret_cast<N*>(newLeafNode);
    } else {
        // 原节点是内节点，生成两个内节点
        auto* internalNode = reinterpret_cast<InternalPage *>(node);
        auto* newInternalNode = reinterpret_cast<InternalPage *>(newPage->GetData());
        // 填充新叶子节点的数据，这一步同时设置了父节点
        newInternalNode->Init(newPageId, internalNode->GetParentPageId(), internal_max_size_);
        internalNode->MoveHalfTo(newInternalNode, buffer_pool_manager_);

        newNode = reinterpret_cast<N*>(newInternalNode);
    }
    return newNode;
}

/*
 * Insert key & value pair into internal page after split
 * @param   old_node      input page from split() method
 * @param   key
 * @param   new_node      returned page from split() method
 * User needs to first find the parent page of old_node, parent node must be
 * adjusted to take info of new_node into account. Remember to deal with split
 * recursively if necessary.
 */
INDEX_TEMPLATE_ARGUMENTS
void BPLUSTREE_TYPE::InsertIntoParent(BPlusTreePage *old_node, const KeyType &key, BPlusTreePage *new_node,
                                      Transaction *transaction)
{
    if (old_node->IsRootPage())
    {
        // 传入节点是根节点，需要生成一个新的根节点
        page_id_t  newRootID;
        Page* page = buffer_pool_manager_->NewPage(newRootID);
        auto* newRootPage = reinterpret_cast<InternalPage *>(page->GetData());

        // 数据初始化，更新根节点
        newRootPage->Init(newRootID, INVALID_PAGE_ID, internal_max_size_);
        UpdateRootPageId(0);
        root_page_id_ = newRootID;

        // 更新父节点关系
        newRootPage->PopulateNewRoot(old_node->GetPageId(), key, new_node->GetPageId());
        old_node->SetParentPageId(newRootID);
        new_node->SetParentPageId(newRootID);
        buffer_pool_manager_->UnpinPage(newRootID, true);
    } else {
        page_id_t parentID = old_node->GetParentPageId();
        Page* parentPage = buffer_pool_manager_->FetchPage(parentID);
        auto* parentNode = reinterpret_cast<InternalPage*>(parentPage->GetData());

        parentNode->InsertNodeAfter(old_node->GetPageId(), key, new_node->GetPageId());

        if (parentNode->GetSize() == parentNode->GetMaxSize() + 1)
        {
            // 当前节点需要分裂，递归调用
            auto* newParentNode = Split(parentNode);
            InsertIntoParent(parentNode, newParentNode->KeyAt(0), newParentNode);
            buffer_pool_manager_->UnpinPage(newParentNode->GetPageId(), true);
        }

        buffer_pool_manager_->UnpinPage(parentNode->GetPageId(), true);
    }
}

/*****************************************************************************
* REMOVE
*****************************************************************************/
/*
* Delete key & value pair associated with input key
* If current tree is empty, return immediately.
* If not, User needs to first find the right leaf page as deletion target, then
* delete entry from leaf page. Remember to deal with redistribute or merge if
* necessary.
*/
INDEX_TEMPLATE_ARGUMENTS
void BPLUSTREE_TYPE::Remove(const KeyType &key, Transaction *transaction)
{
    if (IsEmpty())
    {
        return;
    }

    // 找到条目所在的叶节点
    auto* leafPage = FindLeafPage(key, false);

    if (leafPage != nullptr)
    {
        // 删除相关条目并维护 B+ 树的性质
        auto* leaf = reinterpret_cast<LeafPage *>(leafPage->GetData());
        int sizeBeforeDelete = leaf->GetSize();

        if (leaf->RemoveAndDeleteRecord(key, comparator_) != sizeBeforeDelete)
        {
            // 确实发生了节点的删除，需要进行合并或再分配操作来维护 B+ 树的性质
            CoalesceOrRedistribute(leaf, transaction);
        }
    }

    // 释放对应的页面
    buffer_pool_manager_->UnpinPage(leafPage->GetPageId(), true);
}

/*
* User needs to first find the sibling of input page. If sibling's size + input
* page's size > page's max size, then redistribute. Otherwise, merge.
* Using template N to represent either internal page or leaf page.
* @return: true means target leaf page should be deleted, false means no deletion happens
*/
INDEX_TEMPLATE_ARGUMENTS
template<typename N>
bool BPLUSTREE_TYPE::CoalesceOrRedistribute(N *node, Transaction *transaction)
{
    // 如果当前节点是根节点，直接调整根节点
    if (node->IsRootPage())
    {
        return AdjustRoot(node);
    }

    // 首先判断是否需要合并或再分配，以下情况表明删除并没有影响 B+ 树的结构性质，不需要修改
    if (node->IsLeafPage())
    {
        if (node->GetSize() >= node->GetMinSize())
        {
            return false;
        }
    } else {
        if (node->GetSize() > node->GetMinSize())
        {
            return false;
        }
    }

    // 首先获取父节点
    auto *page = buffer_pool_manager_->FetchPage(node->GetParentPageId());
    if (page == nullptr)
    {
        throw runtime_error("all page are pinned during CoalesceOrRedistribute");
    }
    auto* parent = reinterpret_cast<InternalPage *>(page->GetData());

    // 获取当前节点在父节点中的下标位置
    int nodeIndex = parent->ValueIndex(node->GetPageId());

    // 表明一定会找到对应的位置
    assert(nodeIndex != parent->GetSize());

    // 获取该节点的兄弟节点的逻辑页号
    int siblingPageId;
    if (nodeIndex == 0)
    {
        // 当前节点是最左边的节点，只能寻找他右边的兄弟节点
        siblingPageId = parent->ValueAt(nodeIndex + 1);
    } else {
        // 获取当前节点左边的兄弟节点
        siblingPageId = parent->ValueAt(nodeIndex - 1);
    }

    // 获取兄弟节点所对应的页面
    page = buffer_pool_manager_->FetchPage(siblingPageId);
    if (page == nullptr)
    {
        throw runtime_error("all page are pinned while CoalesceOrRedistribute");
    }
    auto sibling = reinterpret_cast<N *>(page->GetData());


    bool redistribute = false;
    // 判断是进行合并还是重分配
    if (sibling->GetSize() + node->GetSize() > node->GetMaxSize())
    {
        // 此时表明合并后会超出页面的管理数量，进行重分配
        redistribute = true;
        // 此时不会修改父节点，可以释放对应页面
        buffer_pool_manager_->UnpinPage(parent->GetPageId(), true);
    }

    // 进行重分配
    if (redistribute)
    {
        if (nodeIndex == 0)
        {
            // 当前节点是最左边的节点
            Redistribute<N>(sibling, node, 0);   // sibling is successor of node
        } else {
            Redistribute<N>(sibling, node, 1);   // sibling is predecessor of node
        }
        return false;
    }

    // merge nodes: if node is the first child of its parent, swap node and
    // its sibling when call Coalesce for the assumption

    /* 注意：
     * Coalesce 函数把第二个节点合并到第一个节点，调用时考虑当前节点的顺序
     */

    bool ret;
    if (nodeIndex == 0)
    {
        Coalesce(&node, &sibling, &parent, 1, transaction);
        // 此时 node 是合并后的节点，不应该被删除
        ret = false;
    } else {
        Coalesce(&sibling, &node, &parent, nodeIndex, transaction);
        // 此时 node 应该被删除，事实上在 Coalesce 中已经删除
        ret = true;
    }

    // 释放父节点
    buffer_pool_manager_->UnpinPage(parent->GetPageId(), true);
    return ret;
}

/*
* Move all the key & value pairs from one page to its sibling page, and notify
* buffer pool manager to delete this page. Parent page must be adjusted to
* take info of deletion into account. Remember to deal with coalesce or
* redistribute recursively if necessary.
* Using template N to represent either internal page or leaf page.
* @param   neighbor_node      sibling page of input "node"
* @param   node               input from method coalesceOrRedistribute()
* @param   parent             parent page of input "node"
* @return  true means parent node should be deleted, false means no deletion happened
*/
INDEX_TEMPLATE_ARGUMENTS
template<typename N>
bool BPLUSTREE_TYPE::Coalesce(N **neighbor_node, N **node,
                            BPlusTreeInternalPage<KeyType, page_id_t, KeyComparator> **parent, int index,
                            Transaction *transaction)
{
    // 将条目从节点移动到邻居节点
    if ((*node)->IsLeafPage())
    {
        auto *leafNode = reinterpret_cast<LeafPage *>(*node);
        auto *leaf_neighbor = reinterpret_cast<LeafPage *>(*neighbor_node);
        // 移动数据
        leafNode->MoveAllTo(leaf_neighbor);
        // 叶子节点需要修改链表的连接关系
        leaf_neighbor->SetNextPageId(leafNode->GetNextPageId());
    } else {
        auto *internal_node = reinterpret_cast<InternalPage *>(*node);
        auto *internal_neighbor = reinterpret_cast<InternalPage *>(*neighbor_node);
        internal_node->MoveAllTo(internal_neighbor, (*parent)->KeyAt(index), buffer_pool_manager_);
    }

    // 父节点删除对应的子节点
    (*parent)->Remove(index);

    // 删除原页面
    buffer_pool_manager_->UnpinPage((*node)->GetPageId(), true);
    buffer_pool_manager_->DeletePage((*node)->GetPageId());

    if ((*parent)->GetSize() < (*parent)->GetMinSize())
    {
        // 递归处理合并情况
        return CoalesceOrRedistribute(*parent, transaction);
    }

    return false;
}

/*
* Redistribute key & value pairs from one page to its sibling page. If index ==
* 0, move sibling page's first key & value pair into end of input "node",
* otherwise move sibling page's last key & value pair into head of input
* "node".
* Using template N to represent either internal page or leaf page.
* @param   neighbor_node      sibling page of input "node"
* @param   node               input from method coalesceOrRedistribute()
*/
INDEX_TEMPLATE_ARGUMENTS
template<typename N>
void BPLUSTREE_TYPE::Redistribute(N *neighbor_node, N *node, int index)
{
    if (index == 0)
    {
        // 当前节点是最左边的节点，将右兄弟的第一个节点给当前节点
        neighbor_node->MoveFirstToEndOf(node, neighbor_node->KeyAt(0), buffer_pool_manager_);

        // 接下来处理父节点中兄弟节点的索引值

        // 首先获取父节点
        auto *page = buffer_pool_manager_->FetchPage(neighbor_node->GetParentPageId());
        if (page == nullptr)
        {
            throw runtime_error("all page are pinned during CoalesceOrRedistribute");
        }
        auto* parent = reinterpret_cast<InternalPage *>(page->GetData());

        // 获取当前节点在父节点中的下标位置
        int neighborNodeIndex = parent->ValueIndex(neighbor_node->GetPageId());
        // 修改对应的键值
        parent->SetKeyAt(neighborNodeIndex, neighbor_node->KeyAt(0));
        // 释放页面
        buffer_pool_manager_->UnpinPage(parent->GetPageId(), true);
    } else {
        // 将左兄弟的最后一个节点给当前节点
        neighbor_node->MoveLastToFrontOf(node, neighbor_node->KeyAt(neighbor_node->GetSize() - 1), buffer_pool_manager_);

        // 接下来处理父结点中当前节点的键值

        // 首先获取父节点
        auto *page = buffer_pool_manager_->FetchPage(node->GetParentPageId());
        if (page == nullptr)
        {
            throw runtime_error("all page are pinned while Redistribute");
        }
        auto* parent = reinterpret_cast<InternalPage *>(page->GetData());

        // 获取当前节点在父节点中的下标
        int nodeIndex = parent->ValueIndex(node->GetPageId());
        // 修改对应的键值
        parent->SetKeyAt(nodeIndex, node->KeyAt(0));
        // 释放页面
        buffer_pool_manager_->UnpinPage(parent->GetPageId(), true);
    }
}

/*
* Update root page if necessary
* NOTE: size of root page can be less than min size and this method is only
* called within coalesceOrRedistribute() method
* case 1: when you delete the last element in root page, but root page still
* has one last child
* case 2: when you delete the last element in whole b+ tree
* @return : true means root page should be deleted, false means no deletion
* happened
*/
INDEX_TEMPLATE_ARGUMENTS
bool BPLUSTREE_TYPE::AdjustRoot(BPlusTreePage *old_root_node)
{
    if (old_root_node->IsLeafPage())
    {
        // 当前节点是叶节点，case 2
        if (old_root_node->GetSize() == 0)
        {
            root_page_id_ = INVALID_PAGE_ID;
            UpdateRootPageId(0);
            return true;
        }
        return false;
    }

    // 当前节点为非叶节点，case 1
    if (old_root_node->GetSize() == 1)
    {
        auto* root = reinterpret_cast<InternalPage *>(old_root_node);
        root_page_id_ = root->ValueAt(0);
        UpdateRootPageId(0);

        auto* page = buffer_pool_manager_->FetchPage(root_page_id_);
        if (page == nullptr)
        {
            throw runtime_error("all pages are pinned while AdjustRoot");
        }
        
        auto* newRoot = reinterpret_cast<InternalPage*>(page->GetData());
        newRoot->SetParentPageId(INVALID_PAGE_ID);
        buffer_pool_manager_->UnpinPage(root_page_id_, true);

        return true;
    }

    return false;
}

/*****************************************************************************
* INDEX ITERATOR
*****************************************************************************/
/*
* Input parameter is void, find the left most leaf page first, then construct
* index iterator
* @return : index iterator
*/
INDEX_TEMPLATE_ARGUMENTS
INDEXITERATOR_TYPE BPLUSTREE_TYPE::Begin()
{
    Page *page = FindLeafPage(KeyType{}, true);  // leftmost_leaf pinned
    auto *leftmostLeaf = reinterpret_cast<LeafPage *>(page->GetData());
    buffer_pool_manager_->UnpinPage(leftmostLeaf->GetPageId(), false);
    return INDEXITERATOR_TYPE(leftmostLeaf, 0, buffer_pool_manager_);
}

/*
* Input parameter is low key, find the leaf page that contains the input key
* first, then construct index iterator
* @return : index iterator
*/
INDEX_TEMPLATE_ARGUMENTS
INDEXITERATOR_TYPE BPLUSTREE_TYPE::Begin(const KeyType &key)
{
    Page *page = FindLeafPage(key, false);
    auto *leaf = reinterpret_cast<LeafPage *>(page->GetData());
    buffer_pool_manager_->UnpinPage(leaf->GetPageId(), false);
    return INDEXITERATOR_TYPE(leaf, 0, buffer_pool_manager_);
}

/*
* Input parameter is void, construct an index iterator representing the end
* of the key/value pair in the leaf node
* @return : index iterator
*/
INDEX_TEMPLATE_ARGUMENTS
INDEXITERATOR_TYPE BPLUSTREE_TYPE::End()
{
    Page *page = FindLeafPage(KeyType{}, true);  // page pinned
    auto *leaf = reinterpret_cast<LeafPage *>(page->GetData());

    while (leaf->GetNextPageId() != INVALID_PAGE_ID)
    {
        page_id_t nextPageId = leaf->GetNextPageId();
        buffer_pool_manager_->UnpinPage(leaf->GetPageId(), false);  // page unpinned

        Page *nextPage = buffer_pool_manager_->FetchPage(nextPageId);  // next_page pinned
        leaf = reinterpret_cast<LeafPage *>(nextPage->GetData());
    }

    return INDEXITERATOR_TYPE(leaf, leaf->GetSize(), buffer_pool_manager_);
}

/*****************************************************************************
* UTILITIES AND DEBUG
*****************************************************************************/
/*
* Find leaf page containing particular key, if leftMost flag == true, find
* the left most leaf page
* Note: the leaf page is pinned, you need to unpin it after use.
*/
INDEX_TEMPLATE_ARGUMENTS
Page* BPLUSTREE_TYPE::FindLeafPage(const KeyType &key, bool leftMost)
{
    if (root_page_id_ == INVALID_PAGE_ID)
    {
        // 当前是空树
        throw std::runtime_error("BPLUSTREE_TYPE::FindLeafPage : root_page_id is invalid");
    }

    // 获取根节点所对应的页面
    Page* page = buffer_pool_manager_->FetchPage(root_page_id_);
    if (page == nullptr)
    {
        throw runtime_error("all page are pinned while FindLeafPage");
    }

    // 强制类型转换
    auto* node = reinterpret_cast<BPlusTreePage*>(page->GetData());

    // 寻找叶子节点
    while(!node->IsLeafPage())
    {
      auto* internalNode = reinterpret_cast<InternalPage*>(node);

      // 获取下一个节点的逻辑页号
      page_id_t nextPageId = leftMost ? internalNode->ValueAt(0) : internalNode->Lookup(key, comparator_);
      // 获取下一页
      Page* nextPage = buffer_pool_manager_->FetchPage(nextPageId);

      if (nextPage == nullptr)
      {
          throw runtime_error("all page are pinned while FindLeafPage");
      }

      // 强制类型转换
      auto* nextNode = reinterpret_cast<BPlusTreePage*>(nextPage->GetData());

      // 当前页面解锁
      buffer_pool_manager_->UnpinPage(node->GetPageId(), false);
      // 更新相关变量
      page = nextPage;
      node = nextNode;
    }
    // 返回找到的页面，该页面要么存在对应的值，要么是该值需要插入的位置
    return page;
}

/*
* Update/Insert root page id in header page(where page_id = 0, index_root_page is
* defined under include/page/index_root_page.h)
* Call this method everytime root page id is changed.
* @parameter: insert_record      default value is false. When set to true,
* insert a record <index_name, root_page_id> into header page instead of
* updating it.
*/
INDEX_TEMPLATE_ARGUMENTS
void BPLUSTREE_TYPE::UpdateRootPageId(int insert_record)
{
    auto *page = buffer_pool_manager_->FetchPage(0);
    if (page == nullptr)
    {
        throw runtime_error("all page are pinned while UpdateRootPageId");
    }
    auto *index_root_page = reinterpret_cast<IndexRootsPage *>(page->GetData());

    if (insert_record == 1)
    {
        // create a new record<index_name + root_page_id> in index_root_page
        index_root_page->Insert(index_id_, root_page_id_);
    } else {
        // update root_page_id in index_root_page
        index_root_page->Update(index_id_, root_page_id_);
    }
    buffer_pool_manager_->UnpinPage(META_PAGE_ID, true);
}

/**
* This method is used for debug only, You don't need to modify
*/
INDEX_TEMPLATE_ARGUMENTS
void BPLUSTREE_TYPE::ToGraph(BPlusTreePage *page, BufferPoolManager *bpm, std::ofstream &out) const
{
  std::string leaf_prefix("LEAF_");
  std::string internal_prefix("INT_");
  if (page->IsLeafPage()) {
      auto *leaf = reinterpret_cast<LeafPage *>(page);
      // Print node name
      out << leaf_prefix << leaf->GetPageId();
      // Print node properties
      out << "[shape=plain color=green ";
      // Print data of the node
      out << "label=<<TABLE BORDER=\"0\" CELLBORDER=\"1\" CELLSPACING=\"0\" CELLPADDING=\"4\">\n";
      // Print data
      out << "<TR><TD COLSPAN=\"" << leaf->GetSize() << "\">P=" << leaf->GetPageId()
      << ",Parent=" << leaf->GetParentPageId() << "</TD></TR>\n";
      out << "<TR><TD COLSPAN=\"" << leaf->GetSize() << "\">"
      << "max_size=" << leaf->GetMaxSize() << ",min_size=" << leaf->GetMinSize() << ",size=" << leaf->GetSize()
      << "</TD></TR>\n";
      out << "<TR>";
      for (int i = 0; i < leaf->GetSize(); i++) {
          out << "<TD>" << leaf->KeyAt(i) << "</TD>\n";
      }
      out << "</TR>";
      // Print table end
      out << "</TABLE>>];\n";
      // Print Leaf node link if there is a next page
      if (leaf->GetNextPageId() != INVALID_PAGE_ID) {
          out << leaf_prefix << leaf->GetPageId() << " -> " << leaf_prefix << leaf->GetNextPageId() << ";\n";
          out << "{rank=same " << leaf_prefix << leaf->GetPageId() << " " << leaf_prefix << leaf->GetNextPageId()
          << "};\n";
      }

      // Print parent links if there is a parent
      if (leaf->GetParentPageId() != INVALID_PAGE_ID) {
          out << internal_prefix << leaf->GetParentPageId() << ":p" << leaf->GetPageId() << " -> " << leaf_prefix
          << leaf->GetPageId() << ";\n";
      }
  } else {
      auto *inner = reinterpret_cast<InternalPage *>(page);
      // Print node name
      out << internal_prefix << inner->GetPageId();
      // Print node properties
      out << "[shape=plain color=pink ";  // why not?
      // Print data of the node
      out << "label=<<TABLE BORDER=\"0\" CELLBORDER=\"1\" CELLSPACING=\"0\" CELLPADDING=\"4\">\n";
      // Print data
      out << "<TR><TD COLSPAN=\"" << inner->GetSize() << "\">P=" << inner->GetPageId()
      << ",Parent=" << inner->GetParentPageId() << "</TD></TR>\n";
      out << "<TR><TD COLSPAN=\"" << inner->GetSize() << "\">"
      << "max_size=" << inner->GetMaxSize() << ",min_size=" << inner->GetMinSize() << ",size=" << inner->GetSize()
      << "</TD></TR>\n";
      out << "<TR>";
      for (int i = 0; i < inner->GetSize(); i++) {
          out << "<TD PORT=\"p" << inner->ValueAt(i) << "\">";
          if (i > 0) {
              out << inner->KeyAt(i);
          } else {
              out << " ";
          }
          out << "</TD>\n";
      }
      out << "</TR>";
      // Print table end
      out << "</TABLE>>];\n";
      // Print Parent link
      if (inner->GetParentPageId() != INVALID_PAGE_ID) {
          out << internal_prefix << inner->GetParentPageId() << ":p" << inner->GetPageId() << " -> "
          << internal_prefix
          << inner->GetPageId() << ";\n";
      }
      // Print leaves
      for (int i = 0; i < inner->GetSize(); i++) {
          auto child_page = reinterpret_cast<BPlusTreePage *>(bpm->FetchPage(inner->ValueAt(i))->GetData());
          ToGraph(child_page, bpm, out);
          if (i > 0) {
              auto sibling_page = reinterpret_cast<BPlusTreePage *>(bpm->FetchPage(inner->ValueAt(i - 1))->GetData());
              if (!sibling_page->IsLeafPage() && !child_page->IsLeafPage()) {
                  out << "{rank=same " << internal_prefix << sibling_page->GetPageId() << " " << internal_prefix
                  << child_page->GetPageId() << "};\n";
              }
              bpm->UnpinPage(sibling_page->GetPageId(), false);
          }
      }
  }
  bpm->UnpinPage(page->GetPageId(), false);
}

/**
* This function is for debug only, you don't need to modify
*/
INDEX_TEMPLATE_ARGUMENTS
void BPLUSTREE_TYPE::ToString(BPlusTreePage *page, BufferPoolManager *bpm) const {
  if (page->IsLeafPage()) {
      auto *leaf = reinterpret_cast<LeafPage *>(page);
      std::cout << "Leaf Page: " << leaf->GetPageId() << " parent: " << leaf->GetParentPageId()
      << " next: " << leaf->GetNextPageId() << std::endl;
      for (int i = 0; i < leaf->GetSize(); i++) {
          std::cout << leaf->KeyAt(i) << ",";
      }
      std::cout << std::endl;
      std::cout << std::endl;
  } else {
      auto *internal = reinterpret_cast<InternalPage *>(page);
      std::cout << "Internal Page: " << internal->GetPageId() << " parent: " << internal->GetParentPageId()
      << std::endl;
      for (int i = 0; i < internal->GetSize(); i++) {
          std::cout << internal->KeyAt(i) << ": " << internal->ValueAt(i) << ",";
      }
      std::cout << std::endl;
      std::cout << std::endl;
      for (int i = 0; i < internal->GetSize(); i++) {
          ToString(reinterpret_cast<BPlusTreePage *>(bpm->FetchPage(internal->ValueAt(i))->GetData()), bpm);
          bpm->UnpinPage(internal->ValueAt(i), false);
      }
  }
}

INDEX_TEMPLATE_ARGUMENTS
bool BPLUSTREE_TYPE::Check() {
  bool all_unpinned = buffer_pool_manager_->CheckAllUnpinned();
  if (!all_unpinned) {
      LOG(ERROR) << "problem in page unpin" << endl;
  }
  return all_unpinned;
}

template
      class BPlusTree<int, int, BasicComparator<int>>;

template
      class BPlusTree<GenericKey<4>, RowId, GenericComparator<4>>;

template
      class BPlusTree<GenericKey<8>, RowId, GenericComparator<8>>;

template
      class BPlusTree<GenericKey<16>, RowId, GenericComparator<16>>;

template
      class BPlusTree<GenericKey<32>, RowId, GenericComparator<32>>;

template
      class BPlusTree<GenericKey<64>, RowId, GenericComparator<64>>;