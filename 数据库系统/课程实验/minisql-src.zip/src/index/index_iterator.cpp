#include "index/basic_comparator.h"
#include "index/generic_key.h"
#include "index/index_iterator.h"

INDEX_TEMPLATE_ARGUMENTS
INDEXITERATOR_TYPE::IndexIterator(BPlusTreeLeafPage<KeyType, ValueType, KeyComparator> *currentPage,
              int index, BufferPoolManager *buffer_pool_manager)
{
    this->currentPage = currentPage;
    this->currentIndex = index;
    this->buffer_pool_manager = buffer_pool_manager;
}

INDEX_TEMPLATE_ARGUMENTS INDEXITERATOR_TYPE::~IndexIterator()
{
//    buffer_pool_manager->FetchPage(currentPage->GetPageId())->RUnlatch();
    buffer_pool_manager->UnpinPage(currentPage->GetPageId(), false);
}

INDEX_TEMPLATE_ARGUMENTS bool INDEXITERATOR_TYPE::isEnd()
{
    return (currentPage == nullptr || (currentIndex == currentPage->GetSize() && currentPage->GetNextPageId() == INVALID_PAGE_ID));
}

INDEX_TEMPLATE_ARGUMENTS const MappingType &INDEXITERATOR_TYPE::operator*()
{
    if (isEnd())
    {
        throw std::out_of_range("IndexIterator: out of range");
    }
    return currentPage->GetItem(currentIndex);
}

INDEX_TEMPLATE_ARGUMENTS INDEXITERATOR_TYPE &INDEXITERATOR_TYPE::operator++()
{
    currentIndex++;
    if (currentIndex == currentPage->GetSize() && currentPage->GetNextPageId() != INVALID_PAGE_ID)
    {
        page_id_t nextPid = currentPage->GetNextPageId();
        Page *nextPage = buffer_pool_manager->FetchPage(nextPid);  // pined page

        auto* nextNode = reinterpret_cast<BPlusTreeLeafPage<KeyType, ValueType, KeyComparator>*>(nextPage->GetData());
        currentPage = nextNode;
        buffer_pool_manager->UnpinPage(nextPage->GetPageId(), false);
        currentIndex = 0;
    }
    return *this;
}

INDEX_TEMPLATE_ARGUMENTS
bool INDEXITERATOR_TYPE::operator==(const IndexIterator &itr) const
{
    return itr.currentPage == currentPage && itr.currentIndex == currentIndex;
}

INDEX_TEMPLATE_ARGUMENTS
bool INDEXITERATOR_TYPE::operator!=(const IndexIterator &itr) const
{
    return !(itr == *this);
}

template
class IndexIterator<int, int, BasicComparator<int>>;

template
class IndexIterator<GenericKey<4>, RowId, GenericComparator<4>>;

template
class IndexIterator<GenericKey<8>, RowId, GenericComparator<8>>;

template
class IndexIterator<GenericKey<16>, RowId, GenericComparator<16>>;

template
class IndexIterator<GenericKey<32>, RowId, GenericComparator<32>>;

template
class IndexIterator<GenericKey<64>, RowId, GenericComparator<64>>;
