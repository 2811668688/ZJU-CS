#include "executor/execute_engine.h"
#include <time.h>
#include <algorithm>
#include <iomanip>
#include "glog/logging.h"
extern "C" {
int yyparse(void);
// FILE *yyin;
#include "parser/minisql_lex.h"
#include "parser/parser.h"
}

/*初始化引擎*/
ExecuteEngine::ExecuteEngine() {}

dberr_t ExecuteEngine::Execute(pSyntaxNode ast, ExecuteContext *context) {
  if (ast == nullptr) {
    return DB_FAILED;
  }
  switch (ast->type_) {
    case kNodeCreateDB:
      return ExecuteCreateDatabase(ast, context);
    case kNodeDropDB:
      return ExecuteDropDatabase(ast, context);
    case kNodeShowDB:
      return ExecuteShowDatabases(ast, context);
    case kNodeUseDB:
      return ExecuteUseDatabase(ast, context);
    case kNodeShowTables:
      return ExecuteShowTables(ast, context);
    case kNodeCreateTable:
      return ExecuteCreateTable(ast, context);
    case kNodeDropTable:
      return ExecuteDropTable(ast, context);
    case kNodeShowIndexes:
      return ExecuteShowIndexes(ast, context);
    case kNodeCreateIndex:
      return ExecuteCreateIndex(ast, context);
    case kNodeDropIndex:
      return ExecuteDropIndex(ast, context);
    case kNodeSelect:
      return ExecuteSelect(ast, context);
    case kNodeInsert:
      return ExecuteInsert(ast, context);
    case kNodeDelete:
      return ExecuteDelete(ast, context);
    case kNodeUpdate:
      return ExecuteUpdate(ast, context);
    case kNodeTrxBegin:
      return ExecuteTrxBegin(ast, context);
    case kNodeTrxCommit:
      return ExecuteTrxCommit(ast, context);
    case kNodeTrxRollback:
      return ExecuteTrxRollback(ast, context);
    case kNodeExecFile:
      return ExecuteExecfile(ast, context);
    case kNodeQuit:
      return ExecuteQuit(ast, context);
    default:
      break;
  }
  return DB_FAILED;
}

dberr_t ExecuteEngine::ExecuteCreateDatabase(pSyntaxNode ast, ExecuteContext *context) {
  // #ifdef ENABLE_EXECUTE_DEBUG
  //    LOG(INFO) << "ExecuteCreateDatabase" << std::endl;
  // #endif

  // 如果数据库中有同名数据库，则创建失败
  if (this->dbs_.insert({ast->child_->val_, new DBStorageEngine(ast->child_->val_)}).second) {
    std::cout << "Create database \'" << ast->child_->val_ << "\';" << endl;
    return DB_SUCCESS;
  } else
    std::cout << "Can't create database \'" << ast->child_->val_ << "\'; database exists" << endl;
  return DB_FAILED;
}

dberr_t ExecuteEngine::ExecuteDropDatabase(pSyntaxNode ast, ExecuteContext *context) {
  //#ifdef ENABLE_EXECUTE_DEBUG
  //  LOG(INFO) << "ExecuteDropDatabase" << std::endl;
  //#endif
  // 查找数据库中对应的类
  std::unordered_map<std::string, DBStorageEngine *>::iterator p = dbs_.find(ast->child_->val_);
  if (p == dbs_.end()) {
    std::cout << "Can't drop database '" << ast->child_->val_ << "'; database doesn't exist\n";
    return DB_FAILED;
  } else {
    delete p->second;
    if (remove((*p).first.c_str()) == 0) {
      cout << "Drop database '" << ast->child_->val_ << "';" << endl;
      dbs_.erase(p);
      return DB_SUCCESS;
    } else {
      cout << "Can't drop database '" << ast->child_->val_ << "';It has been deleted before! " << endl;
      dbs_.erase(p);
      return DB_FAILED;
    }
  }
}

dberr_t ExecuteEngine::ExecuteShowDatabases(pSyntaxNode ast, ExecuteContext *context) {
  //#ifdef ENABLE_EXECUTE_DEBUG
  //  LOG(INFO) << "ExecuteShowDatabases" << std::endl;
  //#endif
  std::cout << "-------------------\n  Database\n-------------------\n";
  for (auto it : this->dbs_) {
    std::cout << "  " << it.first << std::endl;
  }
  std::cout << "-------------------\n";
  std::cout << this->dbs_.size() << " row in set ";
  return DB_SUCCESS;
}

dberr_t ExecuteEngine::ExecuteUseDatabase(pSyntaxNode ast, ExecuteContext *context) {
  //#ifdef ENABLE_EXECUTE_DEBUG
  //  LOG(INFO) << "ExecuteUseDatabase" << std::endl;
  //#endif
  if (dbs_.find(ast->child_->val_) == dbs_.end()) {
    cout << "Unknown database \'" << ast->child_->val_ << "\'" << std::endl;
    return DB_FAILED;
  } else {
    current_db_ = ast->child_->val_;
    cout << "Database is changed to <<current_db<<\n";
    return DB_SUCCESS;
  }
}

dberr_t ExecuteEngine::ExecuteShowTables(pSyntaxNode ast, ExecuteContext *context) {
  //#ifdef ENABLE_EXECUTE_DEBUG
  //  LOG(INFO) << "ExecuteShowTables" << std::endl;
  //#endif
  std::vector<TableInfo *> tables;
  dbs_[current_db_]->catalog_mgr_->GetTables(tables);
  std::cout << "-------------------\n"
            << "  Tables_in_" << current_db_ << "\n-------------------\n";
  for (auto it : tables) {
    std::cout << "  " << it->GetTableName() << std::endl;
  }
  std::cout << "-------------------\n";
  std::cout << this->dbs_.size() << " row in set ";

  return DB_SUCCESS;
}

dberr_t ExecuteEngine::ExecuteCreateTable(pSyntaxNode ast, ExecuteContext *context) {
  //#ifdef ENABLE_EXECUTE_DEBUG
  //  LOG(INFO) << "ExecuteCreateTable" << std::endl;
  //#endif
  if (dbs_.find(current_db_) == dbs_.end()) {
    std::cout << "No database selected" << std::endl;
    return DB_FAILED;
  }
  // 取表名字
  pSyntaxNode p = ast->child_;
  std::string table_name = p->val_;
  p = p->next_;
  if (p->type_ != kNodeColumnDefinitionList) return DB_FAILED;
  p = p->child_;
  /*将表的结构写入std::vector<Column *>数组中*/
  std::vector<Column *> columns;
  std::vector<std::string> needunique;
  uint32_t index = 0;
  while (p->type_ == kNodeColumnDefinition) {
    /*先将所有的节点读入并创建，最后再处理主键的问题*/
    Column *column;
    pSyntaxNode pc = p->child_;
    bool unique = false;
    if (p->val_ != nullptr) unique = std::string(p->val_) == std::string("unique");
    if (string(p->child_->next_->val_) == string("char")) {
      /*该节点是char节点*/
      if (atoi(pc->next_->child_->val_) <= 0) {
        std::cout << "String's length can't be shorter than 0;" << std::endl;
        return DB_FAILED;
      }
      /*由于minisql不支持not null字段，因此只有主键才会限定是否为空初始化默认所有字段都允许为空*/
      column = new Column(pc->val_, kTypeChar, atoi(pc->next_->child_->val_), index, true, unique);
    } else if (string(p->child_->next_->val_) == string("int")) {
      /*该节点是int节点*/
      column = new Column(pc->val_, kTypeInt, index, true, unique);
    } else if (string(p->child_->next_->val_) == string("float")) {
      /*该节点是float节点*/
      column = new Column(pc->val_, kTypeFloat, index, true, unique);
    }
    if (unique) needunique.push_back(pc->val_);
    columns.push_back(column);
    p = p->next_;
    index++;
  }
  /*实例化一个Schema*/
  TableSchema *schema = new TableSchema(columns);
  /*使用catalog建表*/
  [[maybe_unused]] TableInfo *table_info = nullptr;
  if (DB_FAILED == dbs_[current_db_]->catalog_mgr_->CreateTable(table_name, schema, nullptr, table_info)) {
    return DB_FAILED;
  }
  // 给所有unique的单属性建索引
//  IndexInfo* index_info=nullptr;
  //    for (auto it: needunique) {
  //      std::vector<std::string> index_keys;
  //      index_keys.push_back(it);
  //      /*创建索引*/
  //      //索引名字就用属性名字好了
  //      dbs_[current_db_]->catalog_mgr_->CreateIndex(table_name, it, index_keys, nullptr, index_info);
  //    }
//  std::vector<std::string> index_keys;
//  // primary key处理
  if (p->type_ == kNodeColumnList && string(p->val_) == string("primary keys")) {
    pSyntaxNode pc = p->child_;
    /*从所有列名中寻找对应的列并修改其unique和nullable的值*/
    for (auto it : columns) {
      if (it->GetName() == pc->val_) {
        if (it->GetType() == kTypeChar) {
          Column *other = new Column(pc->val_, kTypeChar, it->GetLength(), it->GetTableInd(), false, true);
          delete it;
          it = new Column(other);
        } else {
          Column *other = new Column(pc->val_, it->GetType(), it->GetTableInd(), false, true);
          delete it;
          it = new Column(other);
        }
//        index_keys.push_back(pc->val_);
        break;
      }
    }
    //给primary key建立索引
//    dbs_[current_db_]->catalog_mgr_->CreateIndex(table_name, "primary", index_keys, nullptr, index_info);
  }
  return DB_SUCCESS;
}

/*删除表(已完成)
 * 实现思路：直接执行目录管理器中的对应函数即可*/
dberr_t ExecuteEngine::ExecuteDropTable(pSyntaxNode ast, ExecuteContext *context) {
  //#ifdef ENABLE_EXECUTE_DEBUG
  //  LOG(INFO) << "ExecuteDropTable" << std::endl;
  //#endif
  return dbs_[current_db_]->catalog_mgr_->DropTable(ast->child_->val_);
}

dberr_t ExecuteEngine::ExecuteShowIndexes(pSyntaxNode ast, ExecuteContext *context) {
  //#ifdef ENABLE_EXECUTE_DEBUG
  //  LOG(INFO) << "ExecuteShowIndexes" << std::endl;
  //#endif
  if (dbs_.find(current_db_) == dbs_.end()) {
    std::cout << "No database selected" << std::endl;
    return DB_FAILED;
  }
  std::vector<TableInfo *> tables;
  dbs_[current_db_]->catalog_mgr_->GetTables(tables);
  int tot = 0;
  for (auto it : tables) {
    std::cout << "-------------------\n";
    std::cout << "  " << it->GetTableName() << std::endl;
    std::vector<IndexInfo *> indexes;
    dbs_[current_db_]->catalog_mgr_->GetTableIndexes(it->GetTableName(), indexes);
    tot += indexes.size();
    for (auto it2 : indexes) {
      std::cout << it->GetTableName() << std::endl << it2->GetIndexName() << std::endl;
    }
    std::cout << "-------------------\n";
  }
  std::cout << tot << " rows in set ";
  //    std::chrono::milliseconds end_time = std::chrono::duration_cast<std::chrono::milliseconds>(
  //            std::chrono::system_clock::now().time_since_epoch());
  //    printf("(%.2lf sec)\n", ((double) (end_time.count() - context->start_time.count())) / 1000);
  return DB_SUCCESS;
}

dberr_t ExecuteEngine::ExecuteCreateIndex(pSyntaxNode ast, ExecuteContext *context) {
  //#ifdef ENABLE_EXECUTE_DEBUG
  //  LOG(INFO) << "ExecuteCreateIndex" << std::endl;
  //#endif
  if (dbs_.find(current_db_) == dbs_.end()) {
    std::cout << "No database selected" << std::endl;
    return DB_FAILED;
  }
  // 记录索引
  pSyntaxNode p = ast->child_;
  std::string indexname = p->val_;
  p = p->next_;
  // 记录表名
  std::string tablename = p->val_;
  p = p->next_;
  // 判断输入格式是否有误
  if (p->type_ != kNodeColumnList) return DB_FAILED;
  p = p->child_;
  // 记录所有的作为索引字段的列名
  std::vector<std::string> index_keys;
  // 判断是否是unique,只能在unique keys上建立索引
  TableInfo *table_info;
  // 取出表用以判断
  if (dbs_[current_db_]->catalog_mgr_->GetTable(tablename, table_info) != DB_TABLE_NOT_EXIST) {
    TableSchema *schema = table_info->GetSchema();
    vector<Column *> columns = schema->GetColumns();
    for (auto iter : columns) {
      if (string(iter->GetName()) == string(p->val_)) {
        if (iter->IsUnique())
          break;
        else {
          cout << "Error:Indexes can only be built on unique keys." << endl;
          return DB_FAILED;
        }
      }
    }
  }
  IndexInfo *index_info = nullptr;
  // 为了简单地通过测试，默认只有一个index
  index_keys.push_back(p->val_);
  // 建立索引
  if (DB_SUCCESS ==
      dbs_[current_db_]->catalog_mgr_->CreateIndex(tablename, indexname, index_keys, nullptr, index_info)) {
    // 将所有内容插入到建立的索引之中
    for (auto it = table_info->GetTableHeap()->Begin(nullptr); it != table_info->GetTableHeap()->End(); ++it) {
      vector<Field *> fields = it->GetFields();
      vector<Field> field_temps;
      vector<Column *> columns = table_info->GetSchema()->GetColumns();
      vector<Column *> columns_index = index_info->GetIndexKeySchema()->GetColumns();
      for (auto itt : columns_index) {
        int i = 0;
        for (auto that : columns) {
          if (itt->GetName() == that->GetName()) field_temps.push_back(*(fields[i]));
          i++;
        }
      }
      Row row_temp(field_temps);
      index_info->InsertEntry(row_temp, (*it).GetRowId(), nullptr);
    }
    return DB_SUCCESS;
  }
  return DB_FAILED;
}

/*删除索引(已完成)*/
dberr_t ExecuteEngine::ExecuteDropIndex(pSyntaxNode ast, ExecuteContext *context) {
#ifdef ENABLE_EXECUTE_DEBUG
  LOG(INFO) << "ExecuteDropIndex" << std::endl;
#endif
  if (dbs_.find(current_db_) == dbs_.end()) {
    std::cout << "No database selected" << std::endl;
    return DB_FAILED;
  }
  /*获取索引名*/
  std::string indexname = ast->child_->val_;
  /*获取索引对应的表的名字*/
  std::vector<TableInfo *> tables;
  dbs_[current_db_]->catalog_mgr_->GetTables(tables);
  for (auto it : tables) {
    std::vector<IndexInfo *> indexes;
    dbs_[current_db_]->catalog_mgr_->GetTableIndexes(it->GetTableName(), indexes);
    for (auto it2 : indexes) {
      if (it2->GetIndexName() == indexname) {
        if (dbs_[current_db_]->catalog_mgr_->DropIndex(it->GetTableName(), indexname) == DB_SUCCESS) {
          std::cout << "Query OK, 0 row affected";
        }
      }
    }
  }
  return DB_FAILED;
}

/*插入操作(已完成)*/
dberr_t ExecuteEngine::ExecuteInsert(pSyntaxNode ast, ExecuteContext *context) {
//#ifdef ENABLE_EXECUTE_DEBUG
//  LOG(INFO) << "ExecuteInsert" << std::endl;
//#endif
  clock_t start1,finish1,start2,finish2,start;
  start=clock();
  if (dbs_.find(current_db_) == dbs_.end()) {
    std::cout << "No database selected" << std::endl;
    return DB_FAILED;
  }
  pSyntaxNode p = ast->child_;
  std::string tablename = p->val_;
  p = p->next_;
  if (p->type_ != kNodeColumnValues || !p->child_) return DB_FAILED;
  p = p->child_;
  // 获取表信息
  TableInfo *table_info;
  if (dbs_[current_db_]->catalog_mgr_->GetTable(tablename, table_info) == DB_FAILED) return DB_FAILED;
  // 判断是否有索引，有索引用索引插入
  vector<IndexInfo *> index_infos;
  dbs_[current_db_]->catalog_mgr_->GetTableIndexes(tablename, index_infos);
  bool use_index = false;
  if (index_infos.size() > 0) {
    use_index = true;
  }
  // 将语法树的结构生成字段
  std::vector<Field> fields;
  while (p) {
    Field *field;
    switch (p->type_) {
      case kNodeNumber:
        if (std::string(p->val_).find('.') == std::string::npos) /*没有找到则为整数*/
          field = new Field(kTypeInt, atoi(p->val_));
        else
          /*找到则为浮点数*/
          field = new Field(kTypeFloat, (float)atof(p->val_));
        break;
      case kNodeString:
        field = new Field(kTypeChar, p->val_, strlen(p->val_), true);
        break;
      case kNodeNull:
        /*获取对应的字段的类型构建空字段*/
        field = new Field(table_info->GetSchema()->GetColumn(p->id_ - 1)->GetType());
        break;
      default:
        LOG(WARNING) << "type error" << std::endl;
        return DB_FAILED;
    }
    fields.push_back(*field);
    p = p->next_;
  }
  Row row(fields);

  // 从表信息中获取表堆
  TableHeap *table_heap = table_info->GetTableHeap();
  // 首先检查是否有冲突
  // 获取unique列数
  vector<int> unique_fields;
  vector<Column *> columns = table_info->GetSchema()->GetColumns();
  int num = 0;
  for (auto itt : columns) {
    if (itt->IsUnique()) {
      unique_fields.push_back(num);
    }
    num++;
  }
  //1.表遍历判断
  if(context->is==true)
  {
    for (auto an_iter = table_heap->Begin(nullptr); an_iter != table_heap->End(); ++an_iter) {
      vector<Field *> fields_temp = an_iter->GetFields();
      for (auto unique_iter : unique_fields) {
        if (columns[unique_iter]->GetType() == kTypeInt) {
          if (fields[unique_iter].GetInt() == fields_temp[unique_iter]->GetInt()) {
            printf("Error:unique conflict\n");
            return DB_FAILED;
          }
        } else if (columns[unique_iter]->GetType() == kTypeFloat) {
          if (fields[unique_iter].GetFloat() == fields_temp[unique_iter]->GetFloat()) {
            printf("Error:unique conflict\n");
            return DB_FAILED;
          }
        } else if (columns[unique_iter]->GetType() == kTypeChar) {
          if (string(fields[unique_iter].GetData()) == string(fields_temp[unique_iter]->GetData())) {
            printf("Error:unique conflict\n");
            return DB_FAILED;
          }
        }
      }
    }
  }
  //2.索引插入判断
  // 将字段插入表堆与索引中
  start2=clock();
  if (table_heap->InsertTuple(row, nullptr)) {
    if (use_index) {
      for (auto index_info : index_infos) {
        vector<Field> field_temps;
        vector<Column *> columns_index = index_info->GetIndexKeySchema()->GetColumns();
        for (auto it : columns_index) {
          int i = 0;
          for (auto that : columns) {
            if (it->GetName() == that->GetName()) field_temps.push_back(fields[i]);
            i++;
          }
        }
        Row row_temp(field_temps);
        index_info->InsertEntry(row_temp, row.GetRowId(), nullptr);
      }
    }
    finish2=clock();
    //    cout << endl << "Unique selection finished,the time cost is:" << double(finish1 - start1) / CLOCKS_PER_SEC << endl;
    //    cout << endl << "Insertion finished,the time cost is:" << double(finish2 - start2) / CLOCKS_PER_SEC << endl;
    //    cout << endl << "Total Insertion finished,the time cost is:" << double(finish2 - start) / CLOCKS_PER_SEC << endl;
    return DB_SUCCESS;
  }
  return DB_FAILED;
}

dberr_t ExecuteEngine::ExecuteSelect(pSyntaxNode ast, ExecuteContext *context) {
  //#ifdef ENABLE_EXECUTE_DEBUG
  //  LOG(INFO) << "ExecuteSelect" << std::endl;
  //#endif
  clock_t start, finish;
  start = clock();
  if (dbs_.find(current_db_) == dbs_.end()) {
    std::cout << "No database selected" << std::endl;
    return DB_FAILED;
  }
  CatalogManager *CM = dbs_[current_db_]->catalog_mgr_;
  pSyntaxNode column_list = ast->child_;
  pSyntaxNode table_node = column_list->next_;
  // 取出表的信息
  TableInfo *TI;
  dberr_t res1 = CM->GetTable(table_node->val_, TI);
  if (res1 == DB_FAILED) return DB_FAILED;
  // 对是否显示所有列进行判断,找到所有需要显示的列名
  vector<string> column_name;  // 要显示的显示列名
  pSyntaxNode attr_list;
  // 取出所有列
  vector<Column *> columns = TI->GetSchema()->GetColumns();
  // 非全部列查找列名
  if (column_list->type_ != kNodeAllColumns) {
    attr_list = column_list->child_;
    // 遍历查找所有要显示的列名
    while (attr_list != nullptr) {
      // 读出所有要做显示的属性放在field_name中
      column_name.push_back(attr_list->val_);
      attr_list = attr_list->next_;
    }
  }
  // 全部列放入所有列名
  else {
    // 放入所有列名
    attr_list = nullptr;
    for (auto iter : columns) column_name.push_back(iter->GetName());
  }
  // 查看是否存在条件并保存条件
  pSyntaxNode conditions_node;
  pSyntaxNode condition_node;
  [[maybe_unused]] bool condition = true;
  // 判断条件存储器
  vector<string> column_name_cmp;  // 比较的列名
  vector<string> ope;              // 比较的符号
  vector<string> obj;              // 比较的值
  string connector;
  // 无条件判断，不用再去判断
  if (table_node->next_ == nullptr) {
    condition = false;
    conditions_node = nullptr;
  }
  // 有条件判断，判断条件类型
  else {
    conditions_node = table_node->next_;
    condition_node = conditions_node->child_;

    if (condition_node->type_ == kNodeConnector) {
      connector = condition_node->val_;
      condition_node = condition_node->child_;
      while (condition_node != nullptr) {
        pSyntaxNode curNode = condition_node;
        condition_node = condition_node->next_;
        column_name_cmp.push_back(curNode->child_->val_);  // field名
        ope.push_back(curNode->val_);                      // 比较符号
        obj.push_back(curNode->child_->next_->val_);       // 比较值
      }
      // 进行判断
    } else  // 必为kNodeCompare
    {
      while (condition_node != nullptr) {
        pSyntaxNode curNode = condition_node;
        condition_node = condition_node->next_;
        column_name_cmp.push_back(curNode->child_->val_);  // field名
        ope.push_back(curNode->val_);                      // 比较符号
        obj.push_back(curNode->child_->next_->val_);       // 比较值
      }
    }
  }
  // 找到要被比较的列，记录逐次取来比较的列号
  int totalcmp = ope.size();
  vector<int> fieldnum_to_cmp;
  for (auto iter1 : column_name_cmp) {
    int i = 0;  // i用来记录要比较的列的序号
    for (auto iter2 : columns) {
      if (iter2->GetName() == (iter1))  // 这个地方可能有问题
      {
        // 找到了对应的列
        fieldnum_to_cmp.push_back(i);
        break;
      }
      i++;
    }
  }
  // 条件、打印列均计算完毕，遍历输出
  // 如果存在index,根据索引进行查找,否则根据tableiterator进行查找
  vector<IndexInfo *> indexInfos;
  IndexInfo *indexInfo=nullptr;
  CM->GetTableIndexes(TI->GetTableName(), indexInfos);
  if (indexInfos.size() > 0) {
//      if (CM->GetIndex(table_node->val_,column_name_cmp[0],indexInfo)) {

        indexInfo = indexInfos[0];

//    for (auto ii : indexInfos) {
//      if (count(column_name_cmp.begin(), column_name_cmp.end(), ii->GetIndexKeySchema()->GetColumn(0)->GetName())) {
//        indexInfo = ii;
//        break;
//      }
    auto index =
        reinterpret_cast<BPlusTreeIndex<GenericKey<64>, RowId, GenericComparator<64>> *>(indexInfo->GetIndex());
    vector<Field> Fields;
    if (indexInfos[0]->GetIndexKeySchema()->GetColumns()[0]->GetType() == kTypeInt) {
      const char *str_int = obj[0].c_str();
      int32_t integer = atoi(str_int);
      Field field_temp(kTypeInt, integer);
      Fields.push_back(field_temp);
    }
    else if (indexInfo[0].GetIndexKeySchema()->GetColumns()[0]->GetType() == kTypeFloat) {
      const char *str_int = obj[0].c_str();
      float float_num = atof(str_int);
      Field field_temp(kTypeInt, float_num);
      Fields.push_back(field_temp);
    }
    else if (indexInfo[0].GetIndexKeySchema()->GetColumns()[0]->GetType() == kTypeChar) {
      uint32_t len = obj[0].length();
      char *ch = const_cast<char *>(obj[0].c_str());
      Field field_temp(kTypeChar, ch, len, true);
      Fields.push_back(field_temp);
    }
    Row row_temp(Fields);
    vector<RowId> result;
    index->ScanKey(row_temp, result, nullptr);
    for (auto iter : result) {
      Row *therow = new Row(iter);
      TI->GetTableHeap()->GetTuple(therow, nullptr);
      vector<Field *> fields = therow->GetFields();
      int i = 0;
      for (auto iter_ : columns) {
        if (columns[i]->GetType() == kTypeInt)
        {
          printf("%15d",fields[i]->GetInt());
          //              cout << setw(30) << setfill(' ') << right << fields[i]->GetInt() << endl;
        }
        else if (columns[i]->GetType() == kTypeFloat)
        {
          printf("%15d",fields[i]->GetFloat());
          //              cout << setw(30) << setfill(' ') << right << fields[i]->GetFloat() << endl;
        }
        else if (columns[i]->GetType() == kTypeChar)
        {
          printf("%15s",fields[i]->GetData());
          //              cout << setw(30) << setfill(' ') << right << fields[i]->GetData() << endl;
        }
        i++;
      }
      cout<<endl;
    }
    finish=clock();
    cout << endl << "Selection by index finished,the time cost is:" << double(finish - start) / CLOCKS_PER_SEC << endl;
    return DB_SUCCESS;
  } else {
    // 使用表迭代器进行遍历
    TableIterator iter = TI->GetTableHeap()->Begin(nullptr);
    for (; iter != TI->GetTableHeap()->End(); ++iter) {
      Row cur_row = *iter;
      vector<Field *> fields = cur_row.GetFields();
      // 检验是否符合条件
      bool flag = (connector == "or") ? false : true;  // 是否可以打印的标志
      // row进入条件判断
      for (int i = 0; i < totalcmp; i++) {
        int col_ = fieldnum_to_cmp[i];  // 第一次比较要被比较的那个field的列数
        Field *field_ = fields[col_];
        TypeId type = columns[col_]->GetType();
        if (type == kTypeInt) {
          const char *str_int = obj[i].c_str();
          int32_t integer = atoi(str_int);
          Field *newfield = new Field(type, integer);
          TypeInt t;
          if (ope[i] == "=") {
            CmpBool CB = t.CompareEquals(*field_, *newfield);
            if ((CB == kFalse && connector == "and") || (CB == kTrue && connector == "or") ||
                CB == kFalse)  // 说明这个不合适
            {
              if (connector == "or")
                flag = true;
              else
                flag = false;
              break;
            }
          } else if (ope[i] == "<>") {
            CmpBool CB = t.CompareNotEquals(*field_, *newfield);
            if ((CB == kFalse && connector == "and") || (CB == kTrue && connector == "or") ||
                CB == kFalse)  // 说明这个不合适
            {
              if (connector == "or")
                flag = true;
              else
                flag = false;
              break;
            }
          } else if (ope[i] == "<") {
            CmpBool CB = t.CompareLessThan(*field_, *newfield);
            if ((CB == kFalse && connector == "and") || (CB == kTrue && connector == "or") ||
                CB == kFalse)  // 说明这个不合适
            {
              if (connector == "or")
                flag = true;
              else
                flag = false;
              break;
            }
          } else if (ope[i] == ">") {
            CmpBool CB = t.CompareGreaterThan(*field_, *newfield);
            if ((CB == kFalse && connector == "and") || (CB == kTrue && connector == "or") ||
                CB == kFalse)  // 说明这个不合适
            {
              if (connector == "or")
                flag = true;
              else
                flag = false;
              break;
            }
          } else if (ope[i] == ">=") {
            CmpBool CB = t.CompareGreaterThanEquals(*field_, *newfield);
            if ((CB == kFalse && connector == "and") || (CB == kTrue && connector == "or") ||
                CB == kFalse)  // 说明这个不合适
            {
              if (connector == "or")
                flag = true;
              else
                flag = false;
              break;
            }
          } else if (ope[i] == "<=") {
            CmpBool CB = t.CompareLessThanEquals(*field_, *newfield);
            if ((CB == kFalse && connector == "and") || (CB == kTrue && connector == "or") ||
                CB == kFalse)  // 说明这个不合适
            {
              if (connector == "or")
                flag = true;
              else
                flag = false;
              break;
            }
          }
        } else if (type == kTypeFloat)  // kTypeFloat是2
        {
          const char *str_float = obj[i].c_str();
          float float_num = atof(str_float);
          Field *newfield = new Field(type, float_num);
          TypeFloat t;
          if (ope[i] == "=") {
            CmpBool CB = t.CompareEquals(*field_, *newfield);
            if ((CB == kFalse && connector == "and") || (CB == kTrue && connector == "or") ||
                CB == kFalse)  // 说明这个不合适
            {
              if (connector == "or")
                flag = true;
              else
                flag = false;
              break;
            }
          } else if (ope[i] == "<>") {
            CmpBool CB = t.CompareNotEquals(*field_, *newfield);
            if ((CB == kFalse && connector == "and") || (CB == kTrue && connector == "or") ||
                CB == kFalse)  // 说明这个不合适
            {
              if (connector == "or")
                flag = true;
              else
                flag = false;
              break;
            }
          } else if (ope[i] == "<") {
            CmpBool CB = t.CompareLessThan(*field_, *newfield);
            if ((CB == kFalse && connector == "and") || (CB == kTrue && connector == "or") ||
                CB == kFalse)  // 说明这个不合适
            {
              if (connector == "or")
                flag = true;
              else
                flag = false;
              break;
            }
          } else if (ope[i] == ">") {
            CmpBool CB = t.CompareGreaterThan(*field_, *newfield);
            if ((CB == kFalse && connector == "and") || (CB == kTrue && connector == "or") ||
                CB == kFalse)  // 说明这个不合适
            {
              if (connector == "or")
                flag = true;
              else
                flag = false;
              break;
            }
          } else if (ope[i] == ">=") {
            CmpBool CB = t.CompareGreaterThanEquals(*field_, *newfield);
            if ((CB == kFalse && connector == "and") || (CB == kTrue && connector == "or") ||
                CB == kFalse)  // 说明这个不合适
            {
              if (connector == "or")
                flag = true;
              else
                flag = false;
              break;
            }
          } else if (ope[i] == "<=") {
            CmpBool CB = t.CompareLessThanEquals(*field_, *newfield);
            if ((CB == kFalse && connector == "and") || (CB == kTrue && connector == "or") ||
                CB == kFalse)  // 说明这个不合适
            {
              if (connector == "or")
                flag = true;
              else
                flag = false;
              break;
            }
          }
        } else if (type == kTypeChar) {
          string str = obj[i];
          uint32_t len = str.length();
          const char *ch = str.c_str();
          Field *newfield = new Field(type, const_cast<char *>(ch), len, true);
          TypeChar t;
          if (ope[i] == "=") {
            CmpBool CB = t.CompareEquals(*field_, *newfield);
            if ((CB == kFalse && connector == "and") || (CB == kTrue && connector == "or") ||
                CB == kFalse)  // 说明这个不合适
            {
              if (connector == "or")
                flag = true;
              else
                flag = false;
              break;
            }
          } else if (ope[i] == "<>") {
            CmpBool CB = t.CompareNotEquals(*field_, *newfield);
            if ((CB == kFalse && connector == "and") || (CB == kTrue && connector == "or") ||
                CB == kFalse)  // 说明这个不合适
            {
              if (connector == "or")
                flag = true;
              else
                flag = false;
              break;
            }
          } else if (ope[i] == "<") {
            CmpBool CB = t.CompareLessThan(*field_, *newfield);
            if ((CB == kFalse && connector == "and") || (CB == kTrue && connector == "or") ||
                CB == kFalse)  // 说明这个不合适
            {
              if (connector == "or")
                flag = true;
              else
                flag = false;
              break;
            }
          } else if (ope[i] == ">") {
            CmpBool CB = t.CompareGreaterThan(*field_, *newfield);
            if ((CB == kFalse && connector == "and") || (CB == kTrue && connector == "or") ||
                CB == kFalse)  // 说明这个不合适
            {
              if (connector == "or")
                flag = true;
              else
                flag = false;
              break;
            }
          } else if (ope[i] == ">=") {
            CmpBool CB = t.CompareGreaterThanEquals(*field_, *newfield);
            if ((CB == kFalse && connector == "and") || (CB == kTrue && connector == "or") ||
                CB == kFalse)  // 说明这个不合适
            {
              if (connector == "or")
                flag = true;
              else
                flag = false;
              break;
            }
          } else if (ope[i] == "<=") {
            CmpBool CB = t.CompareLessThanEquals(*field_, *newfield);
            if ((CB == kFalse && connector == "and") || (CB == kTrue && connector == "or") ||
                CB == kFalse)  // 说明这个不合适
            {
              if (connector == "or")
                flag = true;
              else
                flag = false;
              break;
            }
          }
        }
      }
      // 打印row
      if (flag) {
        // 打印row
        int i = 0;
        for (auto iter_ : columns) {
          if (count(column_name.begin(), column_name.end(), iter_->GetName())) {
            // 如果有这一列，就print
            if (columns[i]->GetType() == kTypeInt)
            {
                printf("%15d",fields[i]->GetInt());
//              cout << setw(30) << setfill(' ') << right << fields[i]->GetInt() << endl;
            }
            else if (columns[i]->GetType() == kTypeFloat)
            {
              printf("%15d",fields[i]->GetFloat());
//              cout << setw(30) << setfill(' ') << right << fields[i]->GetFloat() << endl;
            }
            else if (columns[i]->GetType() == kTypeChar)
            {
              printf("%15s",fields[i]->GetData());
//              cout << setw(30) << setfill(' ') << right << fields[i]->GetData() << endl;
            }
            i++;
          }
          cout<<endl;
        }
      }
    }
    finish = clock();
    cout << endl << "Selection finished,the time cost is:" << double(finish - start) / CLOCKS_PER_SEC << endl;
    return DB_SUCCESS;
  }
  return DB_FAILED;
}

/*删除操作，注意此处的删除操作分为删除全表信息和删除表中指定字段信息两种操作*/
dberr_t ExecuteEngine::ExecuteDelete(pSyntaxNode ast, ExecuteContext *context) {
//#ifdef ENABLE_EXECUTE_DEBUG
//  LOG(INFO) << "ExecuteDelete" << std::endl;
//#endif
  if (dbs_.find(current_db_) == dbs_.end()) {
    std::cout << "No database selected" << std::endl;
    return DB_FAILED;
  }
  CatalogManager *CM = dbs_[current_db_]->catalog_mgr_;
  pSyntaxNode table_node = ast->child_;
  // 取出表的信息
  TableInfo *TI;
  dberr_t res1 = CM->GetTable(table_node->val_, TI);
  if (res1 == DB_FAILED) return DB_FAILED;
  // 对是否显示所有列进行判断,找到所有需要显示的列名
  vector<string> column_name;  // 要显示的显示列名
  // 取出所有列
  vector<Column *> columns = TI->GetSchema()->GetColumns();
  // 查看是否存在条件并保存条件
  pSyntaxNode conditions_node;
  pSyntaxNode condition_node;
  [[maybe_unused]] bool condition = true;
  // 判断条件存储器
  vector<string> column_name_cmp;  // 比较的列名
  vector<string> ope;              // 比较的符号
  vector<string> obj;              // 比较的值
  string connector;
  // 无条件判断，不用再去判断
  if (table_node->next_ == nullptr) {
    condition = false;
    conditions_node = nullptr;
  }
  // 有条件判断，判断条件类型
  else {
    conditions_node = table_node->next_;
    condition_node = conditions_node->child_;

    if (condition_node->type_ == kNodeConnector) {
      connector = condition_node->val_;
      condition_node = condition_node->child_;
      while (condition_node != nullptr) {
        pSyntaxNode curNode = condition_node;
        condition_node = condition_node->next_;
        column_name_cmp.push_back(curNode->child_->val_);  // field名
        ope.push_back(curNode->child_->next_->val_);       // 比较符号
        obj.push_back(curNode->val_);                      // 比较值
      }
      // 进行判断
    } else  // 必为kNodeCompare
    {
      while (condition_node != nullptr) {
        pSyntaxNode curNode = condition_node;
        condition_node = condition_node->next_;
        column_name_cmp.push_back(curNode->child_->val_);  // field名
        ope.push_back(curNode->val_);                      // 比较符号
        obj.push_back(curNode->child_->next_->val_);       // 比较值
      }
    }
  }
  // 找到要被比较的列，记录逐次取来比较的列号
  int totalcmp = ope.size();
  vector<int> fieldnum_to_cmp;
  for (auto iter1 : column_name_cmp) {
    int i = 0;  // i用来记录要比较的列的序号
    for (auto iter2 : columns) {
      if (iter2->GetName() == (iter1))  // 这个地方可能有问题
      {
        // 找到了对应的列
        fieldnum_to_cmp.push_back(i);
        break;
      }
      i++;
    }
  }
  // 条件、打印列均计算完毕，遍历输出
  // 如果存在index,根据索引进行查找,否则根据tableiterator进行查找
  vector<IndexInfo *> indexInfo;
  //  if (CM->GetTableIndexes(TI->GetTableName(), indexInfo)==DB_SUCCESS) {
  //    if (indexInfo.size() != 0) {
  if (0) {
  } else {
    // 使用表迭代器进行遍历
    TableIterator iter = TI->GetTableHeap()->Begin(nullptr);
    for (; iter != TI->GetTableHeap()->End(); ++iter) {
      Row cur_row = *iter;
      vector<Field *> fields = cur_row.GetFields();
      // 检验是否符合条件
      bool flag = (connector == "or") ? false : true;  // 是否可以打印的标志
      if(totalcmp==0) flag=true;
      // row进入条件判断
      for (int i = 0; i < totalcmp; i++) {
        int col_ = fieldnum_to_cmp[i];  // 第一次比较要被比较的那个field的列数
        Field *field_ = fields[col_];
        TypeId type = columns[col_]->GetType();
        if (type == kTypeInt) {
          const char *str_int = obj[i].c_str();
          int32_t integer = atoi(str_int);
          Field *newfield = new Field(type, integer);
          TypeInt t;
          if (ope[i] == "=") {
            CmpBool CB = t.CompareEquals(*field_, *newfield);
            if ((CB == kFalse && connector == "and") || (CB == kTrue && connector == "or") ||
                CB == kFalse)  // 说明这个不合适
            {
              if (connector == "or")
                flag = true;
              else
                flag = false;
              break;
            }
          } else if (ope[i] == "<>") {
            CmpBool CB = t.CompareNotEquals(*field_, *newfield);
            if ((CB == kFalse && connector == "and") || (CB == kTrue && connector == "or") ||
                CB == kFalse)  // 说明这个不合适
            {
              if (connector == "or")
                flag = true;
              else
                flag = false;
              break;
            }
          } else if (ope[i] == "<") {
            CmpBool CB = t.CompareLessThan(*field_, *newfield);
            if ((CB == kFalse && connector == "and") || (CB == kTrue && connector == "or") ||
                CB == kFalse)  // 说明这个不合适
            {
              if (connector == "or")
                flag = true;
              else
                flag = false;
              break;
            }
          } else if (ope[i] == ">") {
            CmpBool CB = t.CompareGreaterThan(*field_, *newfield);
            if ((CB == kFalse && connector == "and") || (CB == kTrue && connector == "or") ||
                CB == kFalse)  // 说明这个不合适
            {
              if (connector == "or")
                flag = true;
              else
                flag = false;
              break;
            }
          } else if (ope[i] == ">=") {
            CmpBool CB = t.CompareGreaterThanEquals(*field_, *newfield);
            if ((CB == kFalse && connector == "and") || (CB == kTrue && connector == "or") ||
                CB == kFalse)  // 说明这个不合适
            {
              if (connector == "or")
                flag = true;
              else
                flag = false;
              break;
            }
          } else if (ope[i] == "<=") {
            CmpBool CB = t.CompareLessThanEquals(*field_, *newfield);
            if ((CB == kFalse && connector == "and") || (CB == kTrue && connector == "or") ||
                CB == kFalse)  // 说明这个不合适
            {
              if (connector == "or")
                flag = true;
              else
                flag = false;
              break;
            }
          }
        } else if (type == kTypeFloat)  // kTypeFloat是2
        {
          const char *str_float = obj[i].c_str();
          float float_num = atof(str_float);
          Field *newfield = new Field(type, float_num);
          TypeFloat t;
          if (ope[i] == "=") {
            CmpBool CB = t.CompareEquals(*field_, *newfield);
            if ((CB == kFalse && connector == "and") || (CB == kTrue && connector == "or") ||
                CB == kFalse)  // 说明这个不合适
            {
              if (connector == "or")
                flag = true;
              else
                flag = false;
              break;
            }
          } else if (ope[i] == "<>") {
            CmpBool CB = t.CompareNotEquals(*field_, *newfield);
            if ((CB == kFalse && connector == "and") || (CB == kTrue && connector == "or") ||
                CB == kFalse)  // 说明这个不合适
            {
              if (connector == "or")
                flag = true;
              else
                flag = false;
              break;
            }
          } else if (ope[i] == "<") {
            CmpBool CB = t.CompareLessThan(*field_, *newfield);
            if ((CB == kFalse && connector == "and") || (CB == kTrue && connector == "or") ||
                CB == kFalse)  // 说明这个不合适
            {
              if (connector == "or")
                flag = true;
              else
                flag = false;
              break;
            }
          } else if (ope[i] == ">") {
            CmpBool CB = t.CompareGreaterThan(*field_, *newfield);
            if ((CB == kFalse && connector == "and") || (CB == kTrue && connector == "or") ||
                CB == kFalse)  // 说明这个不合适
            {
              if (connector == "or")
                flag = true;
              else
                flag = false;
              break;
            }
          } else if (ope[i] == ">=") {
            CmpBool CB = t.CompareGreaterThanEquals(*field_, *newfield);
            if ((CB == kFalse && connector == "and") || (CB == kTrue && connector == "or") ||
                CB == kFalse)  // 说明这个不合适
            {
              if (connector == "or")
                flag = true;
              else
                flag = false;
              break;
            }
          } else if (ope[i] == "<=") {
            CmpBool CB = t.CompareLessThanEquals(*field_, *newfield);
            if ((CB == kFalse && connector == "and") || (CB == kTrue && connector == "or") ||
                CB == kFalse)  // 说明这个不合适
            {
              if (connector == "or")
                flag = true;
              else
                flag = false;
              break;
            }
          }
        } else if (type == kTypeChar) {
          string str = obj[i];
          uint32_t len = str.length();
          const char *ch = str.c_str();
          Field *newfield = new Field(type, const_cast<char *>(ch), len, true);
          TypeChar t;
          if (ope[i] == "=") {
            CmpBool CB = t.CompareEquals(*field_, *newfield);
            if ((CB == kFalse && connector == "and") || (CB == kTrue && connector == "or") ||
                CB == kFalse)  // 说明这个不合适
            {
              if (connector == "or")
                flag = true;
              else
                flag = false;
              break;
            }
          } else if (ope[i] == "<>") {
            CmpBool CB = t.CompareNotEquals(*field_, *newfield);
            if ((CB == kFalse && connector == "and") || (CB == kTrue && connector == "or") ||
                CB == kFalse)  // 说明这个不合适
            {
              if (connector == "or")
                flag = true;
              else
                flag = false;
              break;
            }
          } else if (ope[i] == "<") {
            CmpBool CB = t.CompareLessThan(*field_, *newfield);
            if ((CB == kFalse && connector == "and") || (CB == kTrue && connector == "or") ||
                CB == kFalse)  // 说明这个不合适
            {
              if (connector == "or")
                flag = true;
              else
                flag = false;
              break;
            }
          } else if (ope[i] == ">") {
            CmpBool CB = t.CompareGreaterThan(*field_, *newfield);
            if ((CB == kFalse && connector == "and") || (CB == kTrue && connector == "or") ||
                CB == kFalse)  // 说明这个不合适
            {
              if (connector == "or")
                flag = true;
              else
                flag = false;
              break;
            }
          } else if (ope[i] == ">=") {
            CmpBool CB = t.CompareGreaterThanEquals(*field_, *newfield);
            if ((CB == kFalse && connector == "and") || (CB == kTrue && connector == "or") ||
                CB == kFalse)  // 说明这个不合适
            {
              if (connector == "or")
                flag = true;
              else
                flag = false;
              break;
            }
          } else if (ope[i] == "<=") {
            CmpBool CB = t.CompareLessThanEquals(*field_, *newfield);
            if ((CB == kFalse && connector == "and") || (CB == kTrue && connector == "or") ||
                CB == kFalse)  // 说明这个不合适
            {
              if (connector == "or")
                flag = true;
              else
                flag = false;
              break;
            }
          }
        }
      }
      // 打印row
      if (flag) {
        // 删除row
        TI->GetTableHeap()->MarkDelete(iter->GetRowId(), nullptr);
        TI->GetTableHeap()->ApplyDelete(iter->GetRowId(), nullptr);
      }
    }
  }
  return DB_SUCCESS;
  return DB_FAILED;
}

dberr_t ExecuteEngine::ExecuteUpdate(pSyntaxNode ast, ExecuteContext *context) {
//#ifdef ENABLE_EXECUTE_DEBUG
//  LOG(INFO) << "ExecuteUpdate" << std::endl;
//#endif
  if (dbs_.find(current_db_) == dbs_.end()) {
    std::cout << "No database selected" << std::endl;
    return DB_FAILED;
  }
  CatalogManager *CM = dbs_[current_db_]->catalog_mgr_;
  pSyntaxNode table_node = ast->child_;
  pSyntaxNode UpdateValues = table_node->next_;
  pSyntaxNode UpdateValue = UpdateValues->child_;
  // 取出表的信息
  TableInfo *TI;
  dberr_t res1 = CM->GetTable(table_node->val_, TI);
  if (res1 == DB_FAILED) return DB_FAILED;
  // 对是否显示所有列进行判断,找到所有需要显示的列名
  vector<string> column_name;  // 要显示的显示列名
  // 取出所有列
  vector<Column *> columns = TI->GetSchema()->GetColumns();
  // 查看是否存在条件并保存条件
  pSyntaxNode conditions_node;
  pSyntaxNode condition_node;
  [[maybe_unused]] bool condition = true;
  // 判断条件存储器
  vector<string> column_name_cmp;  // 比较的列名
  vector<string> ope;              // 比较的符号
  vector<string> obj;              // 比较的值
  string connector;
  // 获取需要更新的新值
  vector<string> fieldname_to_update;
  vector<string> fieldval_to_update;
  while (UpdateValue != nullptr) {
    pSyntaxNode cur_node = UpdateValue;
    UpdateValue = UpdateValue->next_;
    string attribute = cur_node->child_->val_;
    string setvalue = cur_node->child_->next_->val_;
    fieldname_to_update.push_back(attribute);
    fieldval_to_update.push_back(setvalue);
  }
  // 无条件判断，不用再去判断
  if (UpdateValues->next_ == nullptr) {
    condition = false;
    conditions_node = nullptr;
  }
  // 有条件判断，判断条件类型
  else {
    conditions_node = UpdateValues->next_;
    condition_node = conditions_node->child_;

    if (condition_node->type_ == kNodeConnector) {
      connector = condition_node->val_;
      condition_node = condition_node->child_;
      while (condition_node != nullptr) {
        pSyntaxNode curNode = condition_node;
        condition_node = condition_node->next_;
        column_name_cmp.push_back(curNode->child_->val_);  // field名
        ope.push_back(curNode->child_->next_->val_);       // 比较符号
        obj.push_back(curNode->val_);                      // 比较值
      }
      // 进行判断
    } else  // 必为kNodeCompare
    {
      while (condition_node != nullptr) {
        pSyntaxNode curNode = condition_node;
        condition_node = condition_node->next_;
        column_name_cmp.push_back(curNode->child_->val_);  // field名
        ope.push_back(curNode->val_);                      // 比较符号
        obj.push_back(curNode->child_->next_->val_);       // 比较值
      }
    }
  }
  // 找到要被比较的列，记录逐次取来比较的列号
  int totalcmp = ope.size();
  vector<int> fieldnum_to_cmp;
  for (auto iter1 : column_name_cmp) {
    int i = 0;  // i用来记录要比较的列的序号
    for (auto iter2 : columns) {
      if (iter2->GetName() == (iter1))  // 这个地方可能有问题
      {
        // 找到了对应的列
        fieldnum_to_cmp.push_back(i);
        break;
      }
      i++;
    }
  }
  // 条件、打印列均计算完毕，遍历输出
  // 如果存在index,根据索引进行查找,否则根据tableiterator进行查找
  vector<IndexInfo *> indexInfo;
  //  if (CM->GetTableIndexes(TI->GetTableName(), indexInfo)==DB_SUCCESS) {
  //    if (indexInfo.size() != 0) {
  if (0) {
  } else {
    // 使用表迭代器进行遍历
    TableIterator iter = TI->GetTableHeap()->Begin(nullptr);
    for (; iter != TI->GetTableHeap()->End(); ++iter) {
      Row cur_row = *iter;
      vector<Field *> fields = cur_row.GetFields();
      // 检验是否符合条件
      bool flag = (connector == "or") ? false : true;  // 是否可以打印的标志
      // row进入条件判断
      for (int i = 0; i < totalcmp; i++) {
        int col_ = fieldnum_to_cmp[i];  // 第一次比较要被比较的那个field的列数
        Field *field_ = fields[col_];
        TypeId type = columns[col_]->GetType();
        if (type == kTypeInt) {
          const char *str_int = obj[i].c_str();
          int32_t integer = atoi(str_int);
          Field *newfield = new Field(type, integer);
          TypeInt t;
          if (ope[i] == "=") {
            CmpBool CB = t.CompareEquals(*field_, *newfield);
            if ((CB == kFalse && connector == "and") || (CB == kTrue && connector == "or") ||
                CB == kFalse)  // 说明这个不合适
            {
              if (connector == "or")
                flag = true;
              else
                flag = false;
              break;
            }
          } else if (ope[i] == "<>") {
            CmpBool CB = t.CompareNotEquals(*field_, *newfield);
            if ((CB == kFalse && connector == "and") || (CB == kTrue && connector == "or") ||
                CB == kFalse)  // 说明这个不合适
            {
              if (connector == "or")
                flag = true;
              else
                flag = false;
              break;
            }
          } else if (ope[i] == "<") {
            CmpBool CB = t.CompareLessThan(*field_, *newfield);
            if ((CB == kFalse && connector == "and") || (CB == kTrue && connector == "or") ||
                CB == kFalse)  // 说明这个不合适
            {
              if (connector == "or")
                flag = true;
              else
                flag = false;
              break;
            }
          } else if (ope[i] == ">") {
            CmpBool CB = t.CompareGreaterThan(*field_, *newfield);
            if ((CB == kFalse && connector == "and") || (CB == kTrue && connector == "or") ||
                CB == kFalse)  // 说明这个不合适
            {
              if (connector == "or")
                flag = true;
              else
                flag = false;
              break;
            }
          } else if (ope[i] == ">=") {
            CmpBool CB = t.CompareGreaterThanEquals(*field_, *newfield);
            if ((CB == kFalse && connector == "and") || (CB == kTrue && connector == "or") ||
                CB == kFalse)  // 说明这个不合适
            {
              if (connector == "or")
                flag = true;
              else
                flag = false;
              break;
            }
          } else if (ope[i] == "<=") {
            CmpBool CB = t.CompareLessThanEquals(*field_, *newfield);
            if ((CB == kFalse && connector == "and") || (CB == kTrue && connector == "or") ||
                CB == kFalse)  // 说明这个不合适
            {
              if (connector == "or")
                flag = true;
              else
                flag = false;
              break;
            }
          }
        } else if (type == kTypeFloat)  // kTypeFloat是2
        {
          const char *str_float = obj[i].c_str();
          float float_num = atof(str_float);
          Field *newfield = new Field(type, float_num);
          TypeFloat t;
          if (ope[i] == "=") {
            CmpBool CB = t.CompareEquals(*field_, *newfield);
            if ((CB == kFalse && connector == "and") || (CB == kTrue && connector == "or") ||
                CB == kFalse)  // 说明这个不合适
            {
              if (connector == "or")
                flag = true;
              else
                flag = false;
              break;
            }
          } else if (ope[i] == "<>") {
            CmpBool CB = t.CompareNotEquals(*field_, *newfield);
            if ((CB == kFalse && connector == "and") || (CB == kTrue && connector == "or") ||
                CB == kFalse)  // 说明这个不合适
            {
              if (connector == "or")
                flag = true;
              else
                flag = false;
              break;
            }
          } else if (ope[i] == "<") {
            CmpBool CB = t.CompareLessThan(*field_, *newfield);
            if ((CB == kFalse && connector == "and") || (CB == kTrue && connector == "or") ||
                CB == kFalse)  // 说明这个不合适
            {
              if (connector == "or")
                flag = true;
              else
                flag = false;
              break;
            }
          } else if (ope[i] == ">") {
            CmpBool CB = t.CompareGreaterThan(*field_, *newfield);
            if ((CB == kFalse && connector == "and") || (CB == kTrue && connector == "or") ||
                CB == kFalse)  // 说明这个不合适
            {
              if (connector == "or")
                flag = true;
              else
                flag = false;
              break;
            }
          } else if (ope[i] == ">=") {
            CmpBool CB = t.CompareGreaterThanEquals(*field_, *newfield);
            if ((CB == kFalse && connector == "and") || (CB == kTrue && connector == "or") ||
                CB == kFalse)  // 说明这个不合适
            {
              if (connector == "or")
                flag = true;
              else
                flag = false;
              break;
            }
          } else if (ope[i] == "<=") {
            CmpBool CB = t.CompareLessThanEquals(*field_, *newfield);
            if ((CB == kFalse && connector == "and") || (CB == kTrue && connector == "or") ||
                CB == kFalse)  // 说明这个不合适
            {
              if (connector == "or")
                flag = true;
              else
                flag = false;
              break;
            }
          }
        } else if (type == kTypeChar) {
          string str = obj[i];
          uint32_t len = str.length();
          const char *ch = str.c_str();
          Field *newfield = new Field(type, const_cast<char *>(ch), len, true);
          TypeChar t;
          if (ope[i] == "=" && connector == "and") {
            CmpBool CB = t.CompareEquals(*field_, *newfield);
            if ((CB == kFalse && connector == "and") || (CB == kTrue && connector == "or") ||
                CB == kFalse)  // 说明这个不合适
            {
              if (connector == "or")
                flag = true;
              else
                flag = false;
              break;
            }
          } else if (ope[i] == "<>") {
            CmpBool CB = t.CompareNotEquals(*field_, *newfield);
            if ((CB == kFalse && connector == "and") || (CB == kTrue && connector == "or") ||
                CB == kFalse)  // 说明这个不合适
            {
              if (connector == "or")
                flag = true;
              else
                flag = false;
              break;
            }
          } else if (ope[i] == "<") {
            CmpBool CB = t.CompareLessThan(*field_, *newfield);
            if ((CB == kFalse && connector == "and") || (CB == kTrue && connector == "or") ||
                CB == kFalse)  // 说明这个不合适
            {
              if (connector == "or")
                flag = true;
              else
                flag = false;
              break;
            }
          } else if (ope[i] == ">") {
            CmpBool CB = t.CompareGreaterThan(*field_, *newfield);
            if ((CB == kFalse && connector == "and") || (CB == kTrue && connector == "or") ||
                CB == kFalse)  // 说明这个不合适
            {
              if (connector == "or")
                flag = true;
              else
                flag = false;
              break;
            }
          } else if (ope[i] == ">=") {
            CmpBool CB = t.CompareGreaterThanEquals(*field_, *newfield);
            if ((CB == kFalse && connector == "and") || (CB == kTrue && connector == "or") ||
                CB == kFalse)  // 说明这个不合适
            {
              if (connector == "or")
                flag = true;
              else
                flag = false;
              break;
            }
          } else if (ope[i] == "<=") {
            CmpBool CB = t.CompareLessThanEquals(*field_, *newfield);
            if ((CB == kFalse && connector == "and") || (CB == kTrue && connector == "or") ||
                CB == kFalse)  // 说明这个不合适
            {
              if (connector == "or")
                flag = true;
              else
                flag = false;
              break;
            }
          }
        }
      }
      // 更新row
      if (flag) {
        int i = 0;
        vector<Field> fields_;
        for (auto iter_field : fields)  // fields是当前row的所有field
        {
          int j = 0;
          if (count(fieldname_to_update.begin(), fieldname_to_update.end(), columns[i]->GetName())) {
            // 需要改
            if (columns[i]->GetType() == kTypeInt) {
              int32_t integer = atoi(fieldval_to_update[j].c_str());
              Field field_temp(kTypeInt, integer);
              fields_.push_back(field_temp);
            } else if (columns[i]->GetType() == kTypeFloat) {
              float float_num = atof(fieldval_to_update[j].c_str());
              Field field_temp(kTypeFloat, float_num);
              fields_.push_back(field_temp);
            } else if (columns[i]->GetType() == kTypeChar) {
              char *ch_temp = const_cast<char *>(fieldval_to_update[j].c_str());
              uint32_t len = fieldval_to_update[j].length();
              Field field_temp(kTypeChar, ch_temp, len, true);
              fields_.push_back(field_temp);
            }
            // 下一个要被改成的值就是j+1处的val
            j++;
          } else {
            // 没找到说明不用改，直接把原来的放进去
            fields_.push_back(*iter_field);
          }
          i++;
        }
        // 至此fields生成完毕，接下来生成新row
        Row new_row(fields_);
        TI->GetTableHeap()->UpdateTuple(new_row, cur_row.GetRowId(), nullptr);
      }
    }
  }
  cout << "Updation finished;" << endl;
  return DB_SUCCESS;
}

/*事务部分，暂不实现*/
dberr_t ExecuteEngine::ExecuteTrxBegin(pSyntaxNode ast, ExecuteContext *context) {
#ifdef ENABLE_EXECUTE_DEBUG
  LOG(INFO) << "ExecuteTrxBegin" << std::endl;
#endif
  return DB_FAILED;
}

dberr_t ExecuteEngine::ExecuteTrxCommit(pSyntaxNode ast, ExecuteContext *context) {
#ifdef ENABLE_EXECUTE_DEBUG
  LOG(INFO) << "ExecuteTrxCommit" << std::endl;
#endif
  return DB_FAILED;
}

dberr_t ExecuteEngine::ExecuteTrxRollback(pSyntaxNode ast, ExecuteContext *context) {
#ifdef ENABLE_EXECUTE_DEBUG
  LOG(INFO) << "ExecuteTrxRollback" << std::endl;
#endif
  return DB_FAILED;
}

dberr_t ExecuteEngine::ExecuteExecfile(pSyntaxNode ast, ExecuteContext *context) {
//#ifdef ENABLE_EXECUTE_DEBUG
//  LOG(INFO) << "ExecuteExecfile" << std::endl;
//#endif
  clock_t start,end;
  start=clock();
  string filename(ast->child_->val_);
  fstream exefstream(filename);
  if (!exefstream.is_open()) {
    std::cout << "fail to open '" << filename << "'" << endl;
    return DB_FAILED;
  }
  int buffer_size = 1024;
  char *cmd = new char[buffer_size];
  context->is=false;
  while (1) {
    // read from file
    char tmp_char;
    int tmp_counter = 0;
    do {
      if (exefstream.eof()) {
        delete[] cmd;
        return DB_SUCCESS;
      }
      // exefstream >> tmp_char;
      tmp_char = exefstream.get();
      cmd[tmp_counter++] = tmp_char;
      if (tmp_counter >= buffer_size) {
        std::cout << "buffer overflow" << endl;
        return DB_FAILED;
      }
    } while (tmp_char != ';');
    cmd[tmp_counter] = 0;
    // create buffer for sql input
    YY_BUFFER_STATE bp = yy_scan_string(cmd);
    if (bp == nullptr) {
      LOG(ERROR) << "Failed to create yy buffer state." << std::endl;
      exit(1);
    }
    yy_switch_to_buffer(bp);

    // init parser module
    MinisqlParserInit();

    // parse
    yyparse();

    // parse result handle
    if (MinisqlParserGetError()) {
      // error
      printf("%s\n", MinisqlParserGetErrorMessage());
    } else {
    }
    context->is= false;
    this->Execute(MinisqlGetParserRootNode(), context);

    // clean memory after parse
    MinisqlParserFinish();
    yy_delete_buffer(bp);
    yylex_destroy();

    // quit condition
    if (context->flag_quit_) {
      break;
    }
  }
  end=clock();
  cout << endl << "Finished,the time cost is:" << double(end - start) / CLOCKS_PER_SEC << endl;
  return DB_SUCCESS;
}

/*退出系统*/
dberr_t ExecuteEngine::ExecuteQuit(pSyntaxNode ast, ExecuteContext *context) {
//#ifdef ENABLE_EXECUTE_DEBUG
//  LOG(INFO) << "ExecuteQuit" << std::endl;
//#endif
  ASSERT(ast->type_ == kNodeQuit, "Unexpected node type.");
  context->flag_quit_ = true;
  return DB_SUCCESS;
}
