#include "catalog/table.h"

uint32_t TableMetadata::SerializeTo(char *buf) const
{
    char* p = buf;

    // 写入 table_id_
    MACH_WRITE_UINT32(buf, this->table_id_);
    buf += sizeof (uint32_t);

    // 写入 table_name_
    MACH_WRITE_UINT32(buf, this->table_name_.size());
    buf += sizeof (uint32_t);
    MACH_WRITE_STRING(buf, this->table_name_);
    buf += this->table_name_.size();

    // 写入 root_page_id_
    MACH_WRITE_INT32(buf, this->root_page_id_);
    buf += sizeof (int);

    // 写入 schema_
    buf += schema_->SerializeTo(buf);

    return buf - p;
}

uint32_t TableMetadata::GetSerializedSize() const
{
    return this->table_name_.size() + 2 * sizeof (uint32_t) + sizeof (int) + this->schema_->GetSerializedSize();
}

/**
 * @param heap Memory heap passed by TableInfo
 */
uint32_t TableMetadata::DeserializeFrom(char *buf, TableMetadata *&table_meta, MemHeap *heap)
{
    char *p = buf;

    // 读出 table_id_
    uint32_t tableID = MACH_READ_UINT32(buf);
    buf += sizeof (uint32_t);

    // 读出 table_name_
    uint32_t tableNameLength = MACH_READ_UINT32(buf);
    buf += sizeof (uint32_t);
    string tableName;
    char tableNameUnit;
    for (unsigned i = 0; i < tableNameLength; i ++)
    {
        tableNameUnit = MACH_READ_FROM(char, buf);
        buf ++;
        tableName += tableNameUnit;
    }

    // 读出 root_page_id_
    page_id_t rootPageId = MACH_READ_INT32(buf);
    buf += sizeof (int);

    // 读出 schema_
    Schema* schema;
    buf += Schema::DeserializeFrom(buf, schema, heap);

    // 生成 TableMetadata 对象
    table_meta = ALLOC_P(heap, TableMetadata)(tableID, tableName, rootPageId, schema);

    return buf - p;
}

/**
 * Only called by create table
 *
 * @param heap Memory heap passed by TableInfo
 */
TableMetadata *TableMetadata::Create(table_id_t table_id, std::string table_name,
                                     page_id_t root_page_id, TableSchema *schema, MemHeap *heap) {
  // allocate space for table metadata
  void *buf = heap->Allocate(sizeof(TableMetadata));
  return new(buf)TableMetadata(table_id, table_name, root_page_id, schema);
}

TableMetadata::TableMetadata(table_id_t table_id, std::string table_name, page_id_t root_page_id, TableSchema *schema)
        : table_id_(table_id), table_name_(table_name), root_page_id_(root_page_id), schema_(schema) {}
