#include "catalog/indexes.h"
#include <iostream>

IndexMetadata *IndexMetadata::Create(const index_id_t index_id, const string &index_name,
                                     const table_id_t table_id, const vector<uint32_t> &key_map,
                                     MemHeap *heap)
{
    void *buf = heap->Allocate(sizeof(IndexMetadata));
    return new(buf)IndexMetadata(index_id, index_name, table_id, key_map);
}

uint32_t IndexMetadata::SerializeTo(char *buf) const
{
    char* p = buf;

    // 写入 index_id_
    MACH_WRITE_UINT32(buf, this->index_id_);
    buf += sizeof (uint32_t);

//    std::cout << "IndexMetadata::SerializeTo: this->root_page_id_: " << this->root_page_id_ << std::endl;

    // 写入 root_page_id_
    MACH_WRITE_INT32(buf, this->root_page_id_);
    buf += sizeof (int);

    // 写入 index_name_
    MACH_WRITE_UINT32(buf, this->index_name_.size());
    buf += sizeof (uint32_t);
    MACH_WRITE_STRING(buf, this->index_name_);
    buf += this->index_name_.size();

    // 写入 table_id_
    MACH_WRITE_UINT32(buf, this->table_id_);
    buf += sizeof (uint32_t);

    // 写入 key_map_
    MACH_WRITE_UINT32(buf, this->key_map_.size());
    buf += sizeof (uint32_t);

    for (unsigned i = 0; i < this->key_map_.size(); i++)
    {
        MACH_WRITE_UINT32(buf, key_map_[i]);
        buf += sizeof (uint32_t);
    }

    return buf - p;
}

uint32_t IndexMetadata::GetSerializedSize() const
{
    return this->index_name_.size() + (4 + this->key_map_.size()) * sizeof (uint32_t) + sizeof (int);
}

uint32_t IndexMetadata::DeserializeFrom(char *buf, IndexMetadata *&index_meta, MemHeap *heap)
{
    char* p = buf;

    // 获取 index_id_
    uint32_t indexId = MACH_READ_UINT32(buf);
    buf += sizeof (uint32_t);

    // 获取 root_page_id_
    int rootPageId = MACH_READ_INT32(buf);
    buf += sizeof (int);

    // 获取 index_name_
    uint32_t nameLength = MACH_READ_UINT32(buf);
    buf += sizeof (uint32_t);
    string indexName;
    char indexNameUnit;
    for (unsigned i = 0; i < nameLength; i++)
    {
        indexNameUnit = MACH_READ_FROM(char, buf);
        buf ++;
        indexName += indexNameUnit;
    }

    // 获取 table_id
    uint32_t tableId = MACH_READ_UINT32(buf);
    buf += sizeof (uint32_t);

    // 获取 key_map_
    uint32_t keyMapSize = MACH_READ_UINT32(buf);
    buf += sizeof (uint32_t);
    std::vector<uint32_t> keyMap;
    for (unsigned i = 0; i < keyMapSize; i++)
    {
        keyMap.push_back(MACH_READ_UINT32(buf));
        buf += sizeof (uint32_t);
    }

    // 生成对象
    index_meta = ALLOC_P(heap, IndexMetadata)(indexId, indexName, tableId, keyMap);
    index_meta->setRootPageId(rootPageId);

    return buf - p;
}