#include "catalog/catalog.h"
#include <algorithm>
#include <iostream>

CatalogMeta::CatalogMeta(std::map<table_id_t, page_id_t> &table_meta_pages_,
                         std::map<index_id_t, page_id_t> &index_meta_pages_)
{
    this->table_meta_pages_ = table_meta_pages_;
    this->index_meta_pages_ = index_meta_pages_;
}

void CatalogMeta::SerializeTo(char *buf) const
{
    // 写入 table_meta_pages_
    MACH_WRITE_UINT32(buf, table_meta_pages_.size());
    buf += sizeof (uint32_t);
    auto iter_t = table_meta_pages_.begin();
    while (iter_t != table_meta_pages_.end())
    {
        MACH_WRITE_UINT32(buf, iter_t->first);
        buf += sizeof (uint32_t);
        MACH_WRITE_INT32(buf, iter_t->second);
        buf += sizeof (int);
        iter_t ++;
    }

    // 写入 index_meta_pages_
    MACH_WRITE_UINT32(buf, index_meta_pages_.size());
    buf += sizeof (uint32_t);
    auto iter_i = index_meta_pages_.begin();
    while (iter_i != index_meta_pages_.end())
    {
        MACH_WRITE_UINT32(buf, iter_i->first);
        buf += sizeof (uint32_t);
        MACH_WRITE_INT32(buf, iter_i->second);
        buf += sizeof (int);
        iter_i ++;
    }
}

CatalogMeta *CatalogMeta::DeserializeFrom(char *buf, MemHeap *heap)
{
    // 读入 table_meta_pages_
    uint32_t tableMetaPagesSize = MACH_READ_UINT32(buf);
    buf += sizeof (uint32_t);

    std::map<table_id_t, page_id_t> tableMetaPages;
    unsigned key;
    page_id_t value;

    for (unsigned i = 0; i < tableMetaPagesSize; i++)
    {
        key = MACH_READ_UINT32(buf);
        buf += sizeof (uint32_t);
        value = MACH_READ_INT32(buf);
        buf += sizeof (int);
        tableMetaPages[key] = value;
    }

    // 读入 index_meta_pages_
    uint32_t indexMetaPagesSize = MACH_READ_UINT32(buf);
    buf += sizeof (uint32_t);

    std::map<index_id_t , page_id_t> indexMetaPages;

    for (unsigned i = 0; i < indexMetaPagesSize; i++)
    {
        key = MACH_READ_UINT32(buf);
        buf += sizeof (uint32_t);
        value = MACH_READ_INT32(buf);
        buf += sizeof (int);
        indexMetaPages[key] = value;
    }

    // 生成对象
    return ALLOC_P(heap, CatalogMeta)(tableMetaPages, indexMetaPages);
}

uint32_t CatalogMeta::GetSerializedSize() const
{
    return (table_meta_pages_.size() + index_meta_pages_.size()) * (sizeof (uint32_t) + sizeof (int)) + 2 * sizeof(uint32_t);
}

CatalogMeta::CatalogMeta() {}


CatalogManager::CatalogManager(BufferPoolManager *buffer_pool_manager, LockManager *lock_manager,
                               LogManager *log_manager, bool init)
        : buffer_pool_manager_(buffer_pool_manager), lock_manager_(lock_manager),
          log_manager_(log_manager), heap_(new SimpleMemHeap())
{
    if (init)
    {
        catalog_meta_ = CatalogMeta::NewInstance(heap_);
        next_table_id_ = 0;
        next_index_id_ = 0;
    } else {
        // 获取对应的页面
        Page* catalogMetaPage = buffer_pool_manager->FetchPage(CATALOG_META_PAGE_ID);

        // 反序列化相关信息
        catalog_meta_ = CatalogMeta::DeserializeFrom(catalogMetaPage->GetData(), heap_);

        // 存储信息
        next_table_id_ = catalog_meta_->GetNextTableId();
        next_index_id_ = catalog_meta_->GetNextIndexId();

        auto iter_t = catalog_meta_->table_meta_pages_.begin();
        while (iter_t != catalog_meta_->table_meta_pages_.end())
        {
            if (iter_t->second != INVALID_PAGE_ID)
            {
                LoadTable(iter_t->first, iter_t->second);
            }
            iter_t ++;
        }

        auto iter_i = catalog_meta_->index_meta_pages_.begin();
        while (iter_i != catalog_meta_->index_meta_pages_.end())
        {
            if (iter_i->second != INVALID_PAGE_ID)
            {
                LoadIndex(iter_i->first, iter_i->second);
            }
            iter_i ++;
        }

        // 释放相关页面
        buffer_pool_manager->UnpinPage(CATALOG_META_PAGE_ID, false);
    }
}

CatalogManager::~CatalogManager()
{
    // 将更新后的数据写回磁盘

    // 获取 CatalogMeta 数据页
    Page* catalogMetaPage = buffer_pool_manager_->FetchPage(CATALOG_META_PAGE_ID);
    if (catalogMetaPage == nullptr)
    {
        std::cout << "all pages pinned while CatalogManager::~CatalogManager()" << std::endl;
        exit(-1);
    }
    // 将更新后的数据序列化
    catalog_meta_->SerializeTo(catalogMetaPage->GetData());
    // 释放页面
    buffer_pool_manager_->UnpinPage(CATALOG_META_PAGE_ID, true);

    // 将 CatalogMeta 维护的索引数据持久化
    auto iter = indexes_.begin();
    while (iter != indexes_.end())
    {
        // 首先获取对应的页面
        // 获取页面的逻辑页号
        page_id_t indexPageId = this->catalog_meta_->index_meta_pages_.at(iter->first);
        Page* indexPage = buffer_pool_manager_->FetchPage(indexPageId);
        if (indexPage == nullptr)
        {
            std::cout << "all pages pinned while CatalogManager::~CatalogManager()" << std::endl;
            exit(-1);
        }
        // 序列化
        iter->second->meta_data_->SerializeTo(indexPage->GetData());
        // 释放页面
        buffer_pool_manager_->UnpinPage(indexPageId, true);

        iter ++;
    }

    delete heap_;
}

dberr_t CatalogManager::CreateTable(const string &table_name, TableSchema *schema,
                                    Transaction *txn, TableInfo *&table_info)
{
    // 获取新的页面 ID
    table_id_t newTableId = next_table_id_;

    if (table_names_.find(table_name) != table_names_.end())
    {
        // 当前页面已经存在
        return DB_TABLE_ALREADY_EXIST;
    }

    // 获取新页来存放相关信息
    page_id_t newTablePageId;
    auto newPage = buffer_pool_manager_->NewPage(newTablePageId);
    if (newPage == nullptr)
    {
        throw runtime_error("all page pinned while CatalogManager::CreateTable");
    }

    // 更新 CatalogMeta
    catalog_meta_->table_meta_pages_[newTableId] = newTablePageId;
    catalog_meta_->table_meta_pages_[newTableId + 1] = INVALID_PAGE_ID;

    // 生成新的 TableInfo
    table_info = TableInfo::Create(heap_);
    auto* tableHeap = TableHeap::Create(buffer_pool_manager_, schema, txn,
                                        log_manager_, lock_manager_, table_info->GetMemHeap());
    auto* tableMetaData = TableMetadata::Create(newTableId, table_name,
                                                tableHeap->GetFirstPageId(), schema, table_info->GetMemHeap());
    // 将新生成的信息序列化到数据页
    tableMetaData->SerializeTo(newPage->GetData());
    // 表信息页初始化
    table_info->Init(tableMetaData, tableHeap);
    // 释放申请的页面
    buffer_pool_manager_->UnpinPage(newTablePageId, true);

    // 更新 CatalogManager
    next_table_id_ ++;
    table_names_.emplace(table_name, newTableId);
    tables_.emplace(newTableId, table_info);

    // 创建完成
    return DB_SUCCESS;
}

dberr_t CatalogManager::GetTable(const string &table_name, TableInfo *&table_info)
{
    if (table_names_.find(table_name) == table_names_.end())
    {
        // 要获取的表不存在
        return DB_TABLE_NOT_EXIST;
    }
    return GetTable(table_names_[table_name], table_info);
}

dberr_t CatalogManager::GetTable(const table_id_t table_id, TableInfo *&table_info)
{
    if (tables_.find(table_id) == tables_.end())
    {
        // 要获取的表不存在
        return DB_FAILED;
    }
    table_info = tables_[table_id];
    return DB_SUCCESS;
}

dberr_t CatalogManager::GetTables(vector<TableInfo *> &tables) const
{
    auto iter = tables_.begin();
    while (iter != tables_.end())
    {
        tables.push_back(iter->second);
        iter ++;
    }
    return DB_SUCCESS;
}

dberr_t CatalogManager::CreateIndex(const std::string &table_name, const string &index_name,
                                    const std::vector<std::string> &index_keys, Transaction *txn,
                                    IndexInfo *&index_info)
{
    // 首先判断要建立索引的表是否存在
    if (table_names_.find(table_name) == table_names_.end())
    {
        return DB_TABLE_NOT_EXIST;
    }

    // 判断要创建的索引在该表上是否已经存在
    if (index_names_[table_name].find(index_name) != index_names_[table_name].end())
    {
        return DB_INDEX_ALREADY_EXIST;
    }

    // 判断索引包含的列是否存在
    for (const auto & index_key : index_keys)
    {
        bool isExist = false;
        for (auto column : tables_[table_names_[table_name]]->GetSchema()->GetColumns())
        {
            if (column->GetName() == index_key)
            {
                isExist = true;
                break;
            }
        }
        if (!isExist)
        {
            return DB_COLUMN_NAME_NOT_EXIST;
        }
    }

    // 申请一个新页存储新索引的数据
    page_id_t newIndexPageId;
    Page* page = buffer_pool_manager_->NewPage(newIndexPageId);
    if (page == nullptr)
    {
        throw runtime_error("all pages pinned while CatalogManager::CreateIndex");
    }

    // 获取下一个索引 Id
    index_id_t newIndexId = next_index_id_;

    // 更新 CatalogMeta
    catalog_meta_->index_meta_pages_[newIndexId] = newIndexPageId;
    catalog_meta_->index_meta_pages_[newIndexId + 1] = INVALID_PAGE_ID;

    // 创建新的 IndexInfo
    index_info = IndexInfo::Create(heap_);

    // 将索引包含的列放入数组
    std::vector<uint32_t> keyMap;
    for (auto column : tables_[table_names_[table_name]]->GetSchema()->GetColumns())
    {
        if (std::find(index_keys.begin(), index_keys.end(), column->GetName()) != index_keys.end())
        {
            keyMap.push_back(column->GetTableInd());
        }
    }

    // 创建 IndexMeta
    auto* indexMeatData = IndexMetadata::Create(newIndexId, index_name, table_names_[table_name],
                                               keyMap, index_info->GetMemHeap());
    // 数据序列化
    indexMeatData->SerializeTo(page->GetData());
    // 初始化 IndexInfo
    index_info->Init(indexMeatData, tables_[table_names_[table_name]], buffer_pool_manager_);
    // 释放页面
    buffer_pool_manager_->UnpinPage(newIndexPageId, true);

    // 更新 CatalogManager
    next_index_id_ ++;
    index_names_[table_name].emplace(index_name, newIndexId);
    indexes_.emplace(newIndexId, index_info);

//      auto table_heap = tables_[table_names_[table_name]]->GetTableHeap();
//      for(auto iter = table_heap->Begin(nullptr); iter != table_heap->End(); iter++) {
//        vector<Field> fields;
//        for(auto i : key_map) { fields.emplace_back(*iter->GetFields()[i]); }
//        index_info->GetIndex()->InsertEntry(Row(fields), iter->GetRowId(), nullptr ,);
//      }
    return DB_SUCCESS;
}

//dberr_t CatalogManager::CreateIndex(const std::string &table_name, const string &index_name,
//                                    const vector<uint32_t>& key_map, Transaction *txn,
//                                    IndexInfo *&index_info) {
//  if(table_names_.find(table_name) == table_names_.end()) return DB_TABLE_NOT_EXIST;
//  page_id_t new_index_page_id;
//  index_id_t new_index_id = next_index_id_;
//  if(index_names_[table_name].find(index_name) != index_names_[table_name].end()) return DB_INDEX_ALREADY_EXIST;
//  auto new_page = buffer_pool_manager_->NewPage(new_index_page_id);
//  if(new_page == nullptr) return DB_FAILED;
//  //更新catalog_meta
//  catalog_meta_->index_meta_pages_[new_index_id] = new_index_page_id;
//  catalog_meta_->index_meta_pages_[new_index_id + 1] = INVALID_PAGE_ID;
//  auto catalog_meta_page = buffer_pool_manager_->FetchPage(CATALOG_META_PAGE_ID);
//  catalog_meta_->SerializeTo(catalog_meta_page->GetData());
//  buffer_pool_manager_->UnpinPage(CATALOG_META_PAGE_ID, true);
//  //返回new_index_info
//  index_info = IndexInfo::Create(heap_);
//  /*vector<uint32_t> key_map;
//  for(const auto& column_name : index_keys){
//    bool is_exist = false;
//    for(auto column : tables_[table_names_[table_name]]->GetSchema()->GetColumns()){
//      if(column->GetName() == column_name) { is_exist = true; break; }
//    }
//    if(!is_exist) return DB_COLUMN_NAME_NOT_EXIST;
//  }
//  for(auto column : tables_[table_names_[table_name]]->GetSchema()->GetColumns()){
//    if(std::find(index_keys.begin(), index_keys.end(), column->GetName()) != index_keys.end()) key_map.emplace_back(column->GetTableInd());
//  }*/
//  auto index_metadata =  IndexMetadata::Create(new_index_id, index_name, table_names_[table_name], key_map, index_info->GetMemHeap());
//  index_metadata->SerializeTo(new_page->GetData());
//  index_info->Init(index_metadata, tables_[table_names_[table_name]], buffer_pool_manager_);
//  buffer_pool_manager_->UnpinPage(new_index_page_id, true);
//  //更新CatalogManager
//  next_index_id_++;
//  index_names_[table_name].emplace(index_name, new_index_id);
//  indexes_.emplace(new_index_id, index_info);
//  auto table_heap = tables_[table_names_[table_name]]->GetTableHeap();
//  for(auto iter = table_heap->Begin(); iter != table_heap->End(); iter++) {
//    vector<Field> fields;
//    for(auto i : key_map) { fields.emplace_back(*iter->GetFields()[i]); }
//    index_info->GetIndex()->InsertEntry(Row(fields), iter->GetRowId(), txn);
//  }
//  return DB_SUCCESS;
//}

dberr_t CatalogManager::GetIndex(const std::string &table_name, const std::string &index_name,
                                 IndexInfo *&index_info) const
{
    if (index_names_.at(table_name).find(index_name) == index_names_.at(table_name).end())
    {
        return DB_INDEX_NOT_FOUND;
    }
    index_info = indexes_.at(index_names_.at(table_name).at(index_name));
    return DB_SUCCESS;
}

dberr_t CatalogManager::GetTableIndexes(const std::string &table_name, std::vector<IndexInfo *> &indexes) const
{
    if(index_names_.size()==0)
      return DB_SUCCESS;
    auto iter = index_names_.at(table_name).begin();
    while (iter != index_names_.at(table_name).end())
    {
        indexes.push_back(indexes_.at(iter->second));
        iter ++;
    }
    return DB_SUCCESS;
}

dberr_t CatalogManager::DropTable(const string &table_name)
{
    // 首先判断要删除的表是否存在
    if (table_names_.find(table_name) == table_names_.end())
    {
        return DB_TABLE_NOT_EXIST;
    }

    // 获取表的 Id
    table_id_t tableId = table_names_[table_name];

    // 删除对应的表和数据页
    tables_[tableId]->GetTableHeap()->deleteTable();
    buffer_pool_manager_->DeletePage(catalog_meta_->table_meta_pages_[tableId]);

    // 更新 CatalogMeta
    catalog_meta_->table_meta_pages_.erase(tableId);

    // 释放堆中的空间
    heap_->Free(tables_[tableId]);

    // 删除 CatalogManager 中关于表的记录
    tables_.erase(tableId);
    table_names_.erase(table_name);
    return DB_SUCCESS;
}

dberr_t CatalogManager::DropIndex(const string &table_name, const string &index_name)
{
    // 首先判断要删除的索引是否存在
    if (index_names_[table_name].find(index_name) == index_names_[table_name].end())
    {
        return DB_INDEX_NOT_FOUND;
    }

    // 获取要删除的索引的 ID
    index_id_t indexId = index_names_[table_name][index_name];
    // 删除索引和数据页
    indexes_[indexId]->GetIndex()->Destroy();
    buffer_pool_manager_->DeletePage(catalog_meta_->index_meta_pages_[indexId]);

    // 更新 CatalogMeta
    catalog_meta_->index_meta_pages_.erase(indexId);

    // 释放堆空间
    heap_->Free(indexes_[indexId]);

    // 删除 CatalogManager 中关于索引的记录
    indexes_.erase(indexId);
    index_names_[table_name].erase(index_name);

    return DB_SUCCESS;
}


dberr_t CatalogManager::FlushCatalogMetaPage() const
{
    if (buffer_pool_manager_->FlushPage(CATALOG_META_PAGE_ID))
    {
        return DB_SUCCESS;
    }
    return DB_FAILED;
}

dberr_t CatalogManager::LoadTable(const table_id_t table_id, const page_id_t page_id)
{
    // 首先获取对应的页面
    Page* page = buffer_pool_manager_->FetchPage(page_id);
    if (page == nullptr)
    {
        throw runtime_error("all pages pinned while CatalogManager::LoadTable");
    }
    // 创建对应的 TableInfo
    TableInfo* tableInfo = TableInfo::Create(heap_);
    // 反序列化 TableMetadata
    TableMetadata* tableMetaData = nullptr;
    TableMetadata::DeserializeFrom(page->GetData(), tableMetaData, tableInfo->GetMemHeap());
    if (tableMetaData == nullptr)
    {
        buffer_pool_manager_->UnpinPage(page_id, false);
        return DB_FAILED;
    }
    // 创建 TableHeap
    TableHeap* tableHeap = TableHeap::Create(buffer_pool_manager_, tableMetaData->GetFirstPageId(),
                                             tableMetaData->GetSchema(), log_manager_, lock_manager_,
                                             tableInfo->GetMemHeap());
    // 初始化 tableInfo
    tableInfo->Init(tableMetaData, tableHeap);

    // 更新 CatalogManager 中的信息
    tables_.emplace(table_id, tableInfo);
    table_names_.emplace(tableMetaData->GetTableName(), table_id);

    // 释放相应的页面
    buffer_pool_manager_->UnpinPage(page_id, false);

    return DB_SUCCESS;
}

dberr_t CatalogManager::LoadIndex(const index_id_t index_id, const page_id_t page_id)
{
    // 首先获取数据页
    Page* page = buffer_pool_manager_->FetchPage(page_id);
    if (page == nullptr)
    {
        throw runtime_error("all pages pinned while CatalogManager::LoadIndex");
    }

    // 创建对应的 IndexInfo
    IndexInfo* indexInfo = IndexInfo::Create(heap_);

    // 反序列化 IndexMetadata
    IndexMetadata* indexMetadata;
    IndexMetadata::DeserializeFrom(page->GetData(), indexMetadata, indexInfo->GetMemHeap());
    if (indexMetadata == nullptr)
    {
        buffer_pool_manager_->UnpinPage(page_id, false);
        return DB_FAILED;
    }

    // 初始化 IndexInfo
    indexInfo->Init(indexMetadata, tables_[indexMetadata->GetTableId()], buffer_pool_manager_);
    // 设置根节点页面
    indexInfo->setRootPageId();

//    std::cout << "CatalogManager::LoadIndex: indexInfo->meta_data_->getRootPageId(): " << indexInfo->meta_data_->getRootPageId() << std::endl;


    // 更新 CatalogManager 中的信息
    indexes_.emplace(index_id, indexInfo);
    index_names_[tables_[indexMetadata->GetTableId()]->GetTableName()].emplace(indexMetadata->GetIndexName(), index_id);

    // 释放页面
    buffer_pool_manager_->UnpinPage(page_id, false);

    return DB_SUCCESS;
}

