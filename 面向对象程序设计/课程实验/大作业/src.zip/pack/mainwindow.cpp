#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QTextEdit>
#include <QDebug>
#include <QFileDialog>
#include <QFile>
#include <QTextStream>
#include <QMessageBox>
#include <QSignalMapper>
#include <QLabel>
#include <QFont>
#include <QFontDialog>
#include <QColorDialog>
#include <QPlainTextEdit>
#include <QTextEdit>
#include <QDateTime>
#include <QDesktopServices>
#include <QUrl>
#include "find.h"
#include "create.h"
MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    this->setWindowTitle(tr("无标题 - 测试记事本[*]"));
    connect(ui->action_New, SIGNAL(triggered()), this, SLOT(NewCreate()));//新建文件
    connect(ui->action_Open, SIGNAL(triggered()), this, SLOT(OpenFile()));//打开文件
    connect(ui->action_Save, SIGNAL(triggered()), this, SLOT(SaveFile()));//保存文件
    connect(ui->action_SaveAs, SIGNAL(triggered()), this, SLOT(SaveAsFile()));//另存文件
    connect(ui->action_Close, SIGNAL(triggered()), this, SLOT(close()));//关闭
    connect(ui->action_Font,SIGNAL(triggered(bool)),this,SLOT(SetFont()));//设置字体
    connect(ui->action_Color, SIGNAL(triggered(bool)),this, SLOT(SetClolor()));//设置颜色
    connect(ui->action_create, SIGNAL(triggered(bool)),this, SLOT(Find()));
    connect(ui->action_Create, SIGNAL(triggered(bool)),this, SLOT(create()));
    connect(ui->textEdit->document(), &QTextDocument::contentsChanged,this, &MainWindow::documentWasModified);

    //Edit Option
    connect(ui->action_Uodo, SIGNAL(triggered(bool)), ui->textEdit->document(), SLOT(undo()));//撤销
    connect(ui->action_Cut, SIGNAL(triggered(bool)), ui->textEdit, SLOT(cut()));//剪贴
    connect(ui->action_Copy, SIGNAL(triggered(bool)), ui->textEdit, SLOT(copy()));//复制
    connect(ui->action_Paste, SIGNAL(triggered(bool)), ui->textEdit, SLOT(paste()));//粘贴
    connect(ui->action_SelectAll, SIGNAL(triggered(bool)), ui->textEdit, SLOT(selectAll()));//全选

    //一开始为选中文字时，标签不可用，只有当选中文字的时候才可用
    ui->action_Cut->setEnabled(false);
    ui->action_Copy->setEnabled(false);
    ui->action_delete->setEnabled(false);

    //当text被选中时，发出copyAvailable信号
    connect(ui->textEdit, SIGNAL(copyAvailable(bool)), ui->action_Cut, SLOT(setEnabled(bool)));
    connect(ui->textEdit, SIGNAL(copyAvailable(bool)), ui->action_Copy, SLOT(setEnabled(bool)));
    connect(ui->textEdit, SIGNAL(copyAvailable(bool)), ui->action_delete, SLOT(setEnabled(bool)));

    //添加状态栏,临时消息显示2秒
    ui->statusBar->showMessage(tr("欢迎使用"),2000);

}

MainWindow::~MainWindow()
{
    delete ui;
}
void MainWindow::Find()
{
    FindDialog *finddialog=new FindDialog;
    finddialog->show();
}
void MainWindow::create()
{
    CREATEUSER *createuser=new CREATEUSER;
    createuser->show();
}

void MainWindow::documentWasModified()
{
    setWindowModified(ui->textEdit->document()->isModified());
}

//新建文档
void MainWindow::NewCreate()
{
    bool isModified = ui->textEdit->document()->isModified();//当前文档已经改变
       if(isModified)//已经改变
       {
           if(fileName.isEmpty())//this doucument is new
           {
               switch (MyMessageBox(tr("是否将更改保存到 无标题？"),tr("记事本")))
               {
                   case QMessageBox::Save:
                       SaveAsFile();
                       break;
                   case QMessageBox::Discard:
                       break;
                   case QMessageBox::Cancel:
                       return;
                   default:
                       break;
               }
           }
           else
           {
               SaveFile();
           }
       }
       ui->textEdit->clear();
       fileName.clear();
       this->setWindowTitle(tr("无标题 - 测试记事本[*]"));
       setWindowModified(false);//窗口不显示被更改标志
}

//打开文档
void MainWindow::OpenFile()
{
    if(ui->textEdit->document()->isModified())//如果已经被修改过了，应该先保存再打开
       {
           QString text(tr("是否将更改保存到 "));
           text += fileName.isEmpty()?(tr("无标题？")):fileName;
           switch (MyMessageBox(text,tr(("记事本"))))
           {
               case QMessageBox::Save:
                   SaveFile();
                   break;
               case QMessageBox::Discard:
                   break;
               case QMessageBox::Cancel:
                   return;
               default:
                   break;
           }
       }

 QString openfileName = QFileDialog::getOpenFileName(this, tr("Open File"),
                                                         QDir::currentPath(),
                                                         tr("Images (*.png *.xpm *.jpg *.*)"));
       if(openfileName.isEmpty())
           return;

       QFile file;
       file.setFileName(openfileName);//设置文件名称
       bool ok = file.open(QIODevice::ReadOnly);
       if(ok)
       {
           QTextStream in(&file);
           ui->textEdit->setText(in.readAll());
           file.close();

           fileName = openfileName;
           ui->textEdit->document()->setModified(false);//文档没有别修改过
           setWindowModified(false);//窗口不显示被更改标志

           QFileInfo fi = QFileInfo(fileName);
           this->setWindowTitle(fi.fileName()+"[*]");
       }
       else
       {
           QMessageBox::information(this, tr("错误提示"), tr("打开文件错误")+file.errorString(),
                                    QMessageBox::Abort);
           return ;
       }
}

void MainWindow::WriteFile(QString filepath)
{
    if(ui->textEdit->document()->isModified())
    {
        QFile file;
        file.setFileName(filepath);//设置文件名称
        bool ok = file.open(QIODevice::WriteOnly);
        if(ok)
        {
            QTextStream out(&file);
            out<<ui->textEdit->toPlainText();
            file.close();
            ui->textEdit->document()->setModified(false);
            setWindowModified(false);

            QFileInfo fi = QFileInfo(filepath);
            this->setWindowTitle(fi.fileName()+"[*]");
        }
        else
        {
            QMessageBox::information(this, tr("错误提示"), tr("打开文件错误:")+filepath,
                                     QMessageBox::Abort);
        }
    }
}

//保存文档
void MainWindow::SaveFile()
{
    if(fileName.isEmpty())
        SaveAsFile();//如果文件名为空则另存为
    else
        WriteFile(fileName);
}

//另存为文档
void MainWindow::SaveAsFile()
{
   fileName = QFileDialog::getSaveFileName(this, tr("另存为"), "*.txt", tr("文本文档(*.txt);;所有文件 (*.*)"));
    if(!fileName.isEmpty())
        WriteFile(fileName);
}

int MainWindow::MyMessageBox(QString Title, QString string)
{
    QMessageBox msgBox;
    msgBox.setWindowTitle(string);
    msgBox.setText(Title);
    msgBox.setStandardButtons(QMessageBox::Save | QMessageBox::Discard | QMessageBox::Cancel);
    msgBox.setButtonText(QMessageBox::Save,tr("保存"));
    msgBox.setButtonText(QMessageBox::Discard,tr("不保存"));
    msgBox.setButtonText(QMessageBox::Cancel,tr("取消"));
    return msgBox.exec();
}

//重写关闭对话框事件
void MainWindow::closeEvent(QCloseEvent * e )
{
    bool isModified = ui->textEdit->document()->isModified();//当前文档已经改变
    if(isModified)
    {
        QString text(tr("是否将更改保存到 "));
        text += fileName.isEmpty()?(tr("无标题？")):fileName;
        switch (MyMessageBox(text,tr(("记事本"))))
        {
            case QMessageBox::Save:
                SaveFile();
                break;
            case QMessageBox::Discard:
                break;
            case QMessageBox::Cancel:
                e->ignore();//忽略退出信号
                break;
            default:
                break;
        }
    }
}

//设置字体
void MainWindow::SetFont()
{
    bool ok;

    QFont font = QFontDialog::getFont(
                  &ok, QFont("微软雅黑", 12),this,tr("选择字体"));
    if (ok)
    {
      ui->textEdit->setFont(font);
    } else {
        QMessageBox::information(this, tr("选择字体"),tr("选择字体错误"));
    }
}
//设置颜色
void MainWindow::SetClolor()
{
    QColor color = QColorDialog::getColor(Qt::red,this,tr("选择颜色"));
    if(color.isValid())
    {
        ui->textEdit->setTextColor(color);
    }
}

