#include<QtGui>
#include"create.h"
#include<QHBoxLayout>
#include<QVBoxLayout>
#include <io.h>
#include<vector>
#include <direct.h>
#include <string>
#include<iostream>
#include<cstring>
#include<cstdio>
#include<fstream>
#include<map>
#include<QDir>
#include<QFileInfo>
//构造函数
CREATEUSER::CREATEUSER(QWidget *parent):QDialog(parent)
{
    /**************1.创建子控件*****************/
    //第一部分：查找内容
    label=new QLabel(tr("user &what:"));//创建一个标签
    lineEdit=new QLineEdit;//创建一个文本框
    label->setBuddy(lineEdit);//将文本框作为标签的友好控件

    //第二部分：触发按钮
    createButton=new QPushButton(tr("&Create"));//创建查找按钮
    createButton->setDefault(true);//将查找按钮设置为默认按钮
    createButton->setEnabled(false);//查找按钮默认不使能
    closeButton=new QPushButton(tr("close"));//创建关闭按钮
    deleteButton=new QPushButton(tr("&Delete"));
    deleteButton->setDefault(true);//将查找按钮设置为默认按钮
    deleteButton->setEnabled(false);//查找按钮默认不使能
    outputButton=new QPushButton(tr("&output"));
    outputButton->setDefault(true);//将查找按钮设置为默认按钮
    outputButton->setEnabled(false);//查找按钮默认不使能
    allButton=new QPushButton(tr("&alluser"));
    /*****************2.连接信号槽**********************/
    connect(lineEdit,SIGNAL(textChanged(const QString &)),this,SLOT(enableFindButton(const QString &)));//只要查找内容改变，调用查找按键使能函数
    connect(createButton,SIGNAL(clicked()),this,SLOT(createClicked()));//当create按键按下，触发createClicked函数
    connect(closeButton,SIGNAL(clicked()),this,SLOT(close()));//当close按键按下，关闭当前对话框
    connect(deleteButton,SIGNAL(clicked()),this,SLOT(deleteClicked()));//当delete按键按下，触发deleteClicked函数
    connect(outputButton,SIGNAL(clicked()),this,SLOT(output()));//当output按键按下，触发output函数
    connect(allButton,SIGNAL(clicked()),this,SLOT(showall()));//当allbutton按键按下，触发showall函数
    /*****************3.布局子控件**********************/
    //需要注意的是，布局共用了两种布局类：
    //QHBoxLayout:水平排列
    //QVBoxLayout：垂直排列
    QHBoxLayout *topLayout=new QHBoxLayout;//创建上布局，包括标签和文本框
    topLayout->addWidget(label);
    topLayout->addWidget(lineEdit);

    QVBoxLayout *leftLayout=new QVBoxLayout;//创建左布局，包括上布局和两个复选框
    leftLayout->addLayout(topLayout);

    QVBoxLayout *rightLayout=new QVBoxLayout;//创建右布局，包括三各按键
    rightLayout->addWidget(createButton);
    rightLayout->addWidget(deleteButton);
    rightLayout->addWidget(outputButton);
    rightLayout->addWidget(closeButton);
    rightLayout->addWidget(allButton);
    rightLayout->addStretch();//填充空白，增加分隔符

    QHBoxLayout *mainLayout=new QHBoxLayout;//创建主分布，包括左分布和右分布
    mainLayout->addLayout(leftLayout);
    mainLayout->addLayout(rightLayout);

    setLayout(mainLayout);
    /*****************4.设置对话框自身属性********************/
    setWindowTitle("user");
    setFixedHeight(sizeHint().height());
}


//按键按下槽函数
void CREATEUSER::createClicked()
{
    QString username=lineEdit->text();//获得创造的用户名
    std::string prefix =".\\user\\"+username.toStdString();
    if (_access(prefix.c_str(), 0) == -1)	//如果文件夹不存在
    {
        qDebug()<<"用户创建成功";
        _mkdir(prefix.c_str());				//则创建
    }
    else{
       qDebug()<<"该用户已存在";
    }
}

void CREATEUSER::deleteClicked()
{
    QString username=lineEdit->text();//获得删除的用户名
    QString prefix =".\\user\\"+username;
    if (_access(prefix.toStdString().c_str(), 0) != -1)	//如果文件夹存在
    {
        qDebug()<<"用户删除成功";
        QDir qDir(prefix);
        qDir.removeRecursively();
    }
    else{
       qDebug()<<"该用户不存在";
    }
}
void CREATEUSER::output(){
    QString username=lineEdit->text();//获得输出的用户名
    QString prefix =".\\user\\"+username;
    if (_access(prefix.toStdString().c_str(), 0) != -1)	//如果文件夹存在
    {
           QDir dir(prefix);
           QFileInfoList fileInfoList = dir.entryInfoList(QDir::Files | QDir::NoDotAndDotDot | QDir::Dirs);
              foreach (auto fileInfo, fileInfoList) {
                    qDebug() << fileInfo.absoluteFilePath();
                  //  qDebug()<<endl;
            }
    }
    else{
       qDebug()<<"该用户不存在";
    }
}
void  CREATEUSER::showall()
{
    QString prefix =".\\user";
    QDir dir(prefix);
    QFileInfoList fileInfoList = dir.entryInfoList(QDir::Files | QDir::NoDotAndDotDot | QDir::Dirs);
       foreach (auto fileInfo, fileInfoList) {
             qDebug() << fileInfo.absoluteFilePath();
     }
}

//按键使能
void CREATEUSER::enableFindButton(const QString &text)
{
   createButton->setEnabled(!text.isEmpty());
   deleteButton->setEnabled(!text.isEmpty());
   outputButton->setEnabled(!text.isEmpty());
}
