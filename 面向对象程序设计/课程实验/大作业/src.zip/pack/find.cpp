#include<QtGui>
#include"find.h"
#include<QHBoxLayout>
#include<QVBoxLayout>
#include<string>
#include<QString>
#include<QDir>
#include<QFile>
#include<QFileDialog>
#include<QFileInfoList>
#include<QStringList>
//构造函数
FindDialog::FindDialog(QWidget *parent):QDialog(parent)
{
    /**************1.创建子控件*****************/
    //第一部分：查找内容
    label=new QLabel(tr("Find &what:"));//创建一个标签
    label1=new QLabel(tr("user &what:"));
    lineEdit=new QLineEdit;//创建一个文本框
    lineEdit1=new QLineEdit;
    label->setBuddy(lineEdit);//将文本框作为标签的友好控件
    label1->setBuddy(lineEdit1);
    //第二部分：查找选项
    //caseCheckBox=new QCheckBox(tr("Match &case"));//大小写敏感选项
   // backwardCheckBox=new QCheckBox(tr("Search &back"));//查找方向选项

    //第三部分：触发按钮
    findButton=new QPushButton(tr("&Find"));//创建查找按钮
    findButton->setDefault(true);//将查找按钮设置为默认按钮
    findButton->setEnabled(false);//查找按钮默认不使能
    closeButton=new QPushButton(tr("close"));//创建关闭按钮

    /*****************2.连接信号槽**********************/
    connect(lineEdit,SIGNAL(textChanged(const QString &)),this,SLOT(enableFindButton(const QString &)));//只要查找内容改变，调用查找按键使能函数
    connect(findButton,SIGNAL(clicked()),this,SLOT(findClicked()));//当find按键按下，触发findClicked函数
    connect(closeButton,SIGNAL(clicked()),this,SLOT(close()));//当close按键按下，关闭当前对话框


    /*****************3.布局子控件**********************/
    //需要注意的是，布局共用了两种布局类：
    //QHBoxLayout:水平排列
    //QVBoxLayout：垂直排列
    QHBoxLayout *topLayout=new QHBoxLayout;//创建上布局，包括标签和文本框
    topLayout->addWidget(label);
    topLayout->addWidget(lineEdit);
    topLayout->addWidget(label1);
    topLayout->addWidget(lineEdit1);
    QVBoxLayout *leftLayout=new QVBoxLayout;//创建左布局，包括上布局和两个复选框
    leftLayout->addLayout(topLayout);
    QVBoxLayout *rightLayout=new QVBoxLayout;//创建右布局，包括两个按键
    rightLayout->addWidget(findButton);
    rightLayout->addWidget(closeButton);
    rightLayout->addStretch();//填充空白，增加分隔符

    QHBoxLayout *mainLayout=new QHBoxLayout;//创建主分布，包括左分布和右分布
    mainLayout->addLayout(leftLayout);
    mainLayout->addLayout(rightLayout);

    setLayout(mainLayout);
    /*****************4.设置对话框自身属性********************/
    setWindowTitle("Find");
    setFixedHeight(sizeHint().height());
}

//按键按下槽函数
void FindDialog::findClicked()
{
    QString text=lineEdit->text();//获得查询的内容
    QString text1=lineEdit1->text();
 //   Qt::CaseSensitivity cs=caseCheckBox->isChecked() ? Qt::CaseSensitive : Qt::CaseInsensitive;//设置查找大小写是否敏感
    QString prefix =".\\user";
    QDir dir(prefix);
    QFileInfoList fileInfoList = dir.entryInfoList(QDir::Files | QDir::NoDotAndDotDot | QDir::Dirs);

       foreach (auto fileInfo, fileInfoList) {
               QString prefix1=fileInfo.absoluteFilePath();
               QString filename=fileInfo.fileName();
             //  qDebug()<<filename;
               if(text1.length()>0&&text1.compare(filename))continue;
            //   qDebug()<< prefix1;
               QDir dir1(prefix1);
               QFileInfoList fileInfoList1 = dir1.entryInfoList(QDir::Files | QDir::NoDotAndDotDot | QDir::Dirs);
                  foreach (auto fileInfo1, fileInfoList1) {

                     // qDebug()<< fileInfo1.absoluteFilePath();
                     QFile file1(fileInfo1.absoluteFilePath());
                      if(file1.open(QFile::ReadOnly)){//只读模式打开
                          while (!file1.atEnd())
                                  {
                                      QByteArray line = file1.readLine();
                                      QString str(line);
                                      QStringList str1=str.split(" ");
                                      for(int i=0;i<str1.length();i++)
                                      {
                                         // qDebug()<<str1[i].toUtf8().data();
                                          if(!text.compare(str1[i]))
                                          {
                                              qDebug()<< fileInfo1.absoluteFilePath();
                                          }
                                      }
                                     // qDebug()<<str.toUtf8().data();
                                  }
                            file1.close();//close file
                         }else{
                             qDebug()<<"error";
                         }
                }
             //qDebug() << fileInfo.absoluteFilePath();
     }

}

//按键使能
void FindDialog::enableFindButton(const QString &text)
{
    findButton->setEnabled(!text.isEmpty());
}

