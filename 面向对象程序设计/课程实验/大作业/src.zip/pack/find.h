#ifndef FIND_H
#define FIND_H
#include<QDialog>//QT对话框的基类
#include<QLabel>
#include<QLineEdit>
#include<QCheckBox>
#include<QPushButton>
//对话框中用到的QT类 声明
class QCheckBox;
class QLabel;
class QLineEdit;
class QPushButton;

class FindDialog:public QDialog
{
    //对于定义信号和槽的类，这个宏是必需的
    Q_OBJECT

public:
    FindDialog(QWidget *parent=0);

signals://信号
//    void findNext(const QString &str,Qt::CaseSensitivity cs);
   // void findPrevious(const QString &str,Qt::CaseSensitivity cs);

private slots://槽
    void findClicked();
    void enableFindButton(const QString &text);


private:
    QLabel *label;//标签控件
    QLabel *label1;
    QLineEdit *lineEdit;//文本框
    QLineEdit *lineEdit1;
    QPushButton *findButton;//查找按键
    QPushButton *closeButton;//关闭按键

};

#endif // FIND_H
