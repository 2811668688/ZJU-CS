#ifndef CREATE_H
#define CREATE_H
#include<QDialog>//QT对话框的基类
#include<QLabel>
#include<QLineEdit>
#include<QCheckBox>
#include<QPushButton>
//对话框中用到的QT类 声明
class QLabel;
class QLineEdit;
class QPushButton;

class CREATEUSER:public QDialog
{
    //对于定义信号和槽的类，这个宏是必需的
    Q_OBJECT

public:
    CREATEUSER(QWidget *parent=0);

private slots://槽
    void createClicked();
    void enableFindButton(const QString &text);
    void deleteClicked();
    void output();//输出一个用户所有文件
    void showall();
private:
    QLabel *label;//标签控件
    QLineEdit *lineEdit;//文本框
    QPushButton *createButton;//创造按键
    QPushButton *closeButton;//关闭按键
    QPushButton *deleteButton;//删除按键
    QPushButton *outputButton;//输出按键
    QPushButton *allButton;
};
#endif // CREATE_H
