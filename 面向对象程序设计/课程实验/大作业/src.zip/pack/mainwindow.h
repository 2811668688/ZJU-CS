#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QCloseEvent>
#include "find.h"
#include "create.h"
namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();
    int MyMessageBox(QString string, QString Title);
    void closeEvent(QCloseEvent *event);
    QString fileName;//全局变量，文件名称
    void WriteFile(QString filepath);//写文件
    void MaybeSaveFile();

private slots:
    void NewCreate();//新建文件
    void OpenFile();//打开文件
    void SaveFile();//保存文件
    void SetFont();//字体设置
    void SetClolor();//颜色设置
    void SaveAsFile();//文件另存为
    void documentWasModified();//判断该文件是否改变了内容
    void create();//创造新用户
    void Find();
    private:
    Ui::MainWindow *ui;
};

#endif // MAINWINDOW_H
