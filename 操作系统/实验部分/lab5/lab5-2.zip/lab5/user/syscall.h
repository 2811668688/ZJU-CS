#ifndef __SYSCALL_H__
#define __SYSCALL_H__

#define SYS_WRITE   64
#define SYS_GETPID  172

// #include "stddef.h"
// #include "print.h"
// #include "types.h"
// #include "defs.h"
// #include "proc.h"

// extern struct task_struct* current;

// unsigned long sys_write(unsigned int fd, const char* buf, size_t count) {
//     if (fd == 1) {
//         puts(buf); 
//         return count;
//     } else {
//         return 0;
//     }
// }

// unsigned long sys_getpid() {
//     return current->pid;
// }

#endif
