#include "print.h"
#include "sbi.h"
#define sbi_putchar(x) sbi_ecall(SBI_PUTCHAR, 0, x, 0, 0, 0, 0, 0)

void puts(char *s) {
    while (*s != '\0'){
        sbi_putchar(*s);
        s++;
    }
}

void puti(int x) {
    if (x < 0){
        sbi_putchar('-'); x = -x;
    }
    if (x == 0){
        sbi_putchar('0'); return;
    }
    int t = x, digit = 0;
    int a[10];
    while (t){
        a[digit++] = t%10;
        t/=10;
    }
    for (int i=digit-1; i>=0; --i)
        sbi_putchar('0'+a[i]);
}
