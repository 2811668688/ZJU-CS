#ifndef _TRAP_H
#define _TRAP_H
#include "types.h"
#define TRAP_MASK (1UL << 63)
#define STI 0X5
#define ecall_U 0X8
#define ecall_S 0X9

void trap_handler(uint64 scause, uint64 sepc, struct pt_regs* regs);
#endif