#ifndef _CLOCK_H
#define _CLOCK_H

#define SBI_SETTIMER 0x0

unsigned long get_cycles();
void clock_set_next_event();

#endif
