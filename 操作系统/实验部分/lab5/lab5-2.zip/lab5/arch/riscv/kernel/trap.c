#include "printk.h"
#include "trap.h"
#include "types.h"
#include "clock.h"
#include "proc.h"

#define SYS_WRITE   64
#define SYS_GETPID  172

extern struct task_struct* current;

uint64 sys_write(uint64 fd,const char* buf, size_t count){
    if(fd == 1){
        for(int i = 0; i < count; i++){
            char out = buf[i];
            putc(out);
        }
        return count;
    }
    return -1;
}

uint64 sys_getpid() {
    return current->pid;
}

void trap_handler(uint64 scause, uint64 sepc, struct pt_regs* regs) {
    // 通过 `scause` 判断trap类型
    // 如果是interrupt 判断是否是timer interrupt
    // 如果是timer interrupt 则打印输出相关信息, 
    //并通过 `clock_set_next_event()` 设置下⼀次时钟中断
    // `clock_set_next_event()` ⻅ 4.5 节
    // 其他interrupt / exception 可以直接忽略
    uint64 ret = -1 ;
    
    if (scause & TRAP_MASK){                //说明是interrupt
        if ((scause & ~TRAP_MASK) == STI){
            // printk("[S] Supervisor Mode Timer Interrupt\n");
            clock_set_next_event();
            do_timer(); //lab3 add
            
        }
    } else {
        if (scause == ecall_U){ //ecall from User-mode
            // printk("ecall trap,");
            // uint64 sys_write(unsigned int fd, const char* buf, size_t count)
            // 系统调用号放在a7,返回值需要放在a0,三个参数分别a0,a1,a2
            // uint64 sys_getpid() 
            // 系统调用号放在a7,返回值需要放在a0
            switch (regs->regs[16]) {
            case SYS_WRITE:
                // printk("it's sys_write\n");
                ret = sys_write(regs->regs[9],regs->regs[10],regs->regs[11]);
                break;
            case SYS_GETPID: 
                // printk("it's sys_getpid\n");
                ret = sys_getpid();
                break;
            default:
                printk("other trap,scause = 0x%lx",scause);
                break;
            }
            // 让sepc+4，跳过ecall
            // 返回值放入结构体中
            regs->sepc = regs->sepc + 0x4;
            regs->regs[9] = ret;
        }
    }
}