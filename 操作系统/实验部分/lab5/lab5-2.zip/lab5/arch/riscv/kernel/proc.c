#include "proc.h"
#include "mm.h"
#include "printk.h"
#include "rand.h"
#include "defs.h"
#include "vm.h"
#include "elf.h"
#include "string.h"

extern void __switch_to(struct task_struct* prev, struct task_struct* next);
extern void __dummy();
extern unsigned long swapper_pg_dir[512];
extern char _stext[];
extern char _etext[];
extern char _srodata[];
extern char _erodata[];
extern char _sdata[];
extern char _edata[];
extern char uapp_start[];
extern char uapp_end[];

struct task_struct* idle; // idle process
struct task_struct* current; // 指向当前运行线程的 `task_struct`
struct task_struct* task[NR_TASKS]; // 线程数组, 所有的线程都保存在此

void print_task(struct task_struct* this);
static uint64 load_program(uint64 cnt);
uint64 get_page_cnt(uint64 size);

void task_init(){
    // printk("task_init started\n");
    // 1. 调用 kalloc() 为 idle 分配一个物理页
    idle = (struct task_struct*)kalloc();
    // 2. 设置 state 为 TASK_RUNNING;
    idle->state = TASK_RUNNING;
    // 3. 由于 idle 不参与调度 可以将其 counter / priority 设置为 0
    idle->counter = 0;
    idle->priority = 0;
    // 4. 设置 idle 的 pid 为 0
    idle->pid = 0;
    // 5. 将 current 和 task[0] 指向 idle
    current = idle;
    task[0] = idle;
    // 为 task[1] ~ task[NR_TASKS - 1] 进行初始化
    int i;
    for (int i = 1;i<NR_TASKS;i++){
        task[i] = (struct task_struct*)alloc_page();
        task[i]->state = TASK_RUNNING;
        // task[i]->counter = 0;
        // task[i]->priority = rand();
        task[i]->counter = 3;
        task[i]->priority = i;
        task[i]->pid = i;
        // thread_struct 中的 `ra` 设置为 __dummy
        task[i]->thread.ra = (uint64)&__dummy;
        // `sp` 设置为 该线程申请的物理页的高地址
        task[i]->thread.sp = (uint64)task[i] + PGSIZE;
        // 将 sepc 修改为 USER_START //elf注释
        // task[i]->thread.sepc = USER_START;
        // 配置 sstatus 中的 :
        // 1. SPP  （ 使得 sret 返回至 U-Mode ） spp = 0 
        // 2. SPIE （ sret 之后开启中断 ） spie = 1 
        // 3. SUM  （ S-Mode 可以访问 User 页面 ） sum = 1
        uint64 sstatus = csr_read(sstatus);
        sstatus &= ~(1<<8);     // set sstatus[SPP] = 0
        sstatus |= 1<<5;        // set sstatus[SPIE] = 1
        sstatus |= 1<<18;       // set sstatus[SUM] = 1
        task[i]->thread.sstatus = sstatus;
        // sscratch 设置为 U-Mode 的 sp，其值为 USER_END
        task[i]->thread.sscratch = USER_END;

        // 创建页表,复制内核页表
        task[i]->pgd = (pagetable_t)alloc_page();
        memcpy(task[i]->pgd, swapper_pg_dir, PGSIZE);

        // 创建,映射 user stack
        uint64 user_stack = alloc_page();
        create_mapping((uint64*)task[i]->pgd, USER_END - PGSIZE,
            user_stack - PA2VA_OFFSET, PGSIZE, 0x17);
        
        // // 复制用户文件,为用户文件创建映射
        // // elf注释
        // uint64 user_page = alloc_page();
        // memcpy((uint64*)user_page,uapp_start,PGSIZE);
        // create_mapping((uint64*)task[i]->pgd, USER_START, 
        //     user_page - PA2VA_OFFSET, PGSIZE, 0x1f);
        
        load_program(i);
        // printk("task %d init done\n",i);     
    }
    printk("...proc_init done!\n");

}

/* 在时钟中断处理中被调用 用于判断是否需要进行调度 */
void do_timer(void) {
    if (current == idle)  //如果当前线程是 idle 线程 直接进行调度
        schedule();
    else {//如果当前线程不是idle,当前线程的运行剩余时间减1,如果仍然大于0,则直接返回,否则进行调度
        current->counter --;
        if (current->counter <= 0) {
            schedule();
        }
    }
}

/* 调度程序 选择出下一个运行的线程 */
void schedule(){
    uint64 re_schedule = 1;
    int i;
    /* 如果所有'运行状态'下的线程运行剩余时间都为0, 
    则对task[NR_TASKS]运行剩余时间重新赋值,之后再重新进行调度。*/
    while (1){
        for (i=1;i<NR_TASKS;i++){
            if (task[i]->state == TASK_RUNNING && task[i]->counter != 0){
                re_schedule = 0;
                break;
            }
        }
        if (re_schedule == 0) break;
        for (i=1;i<NR_TASKS;i++) {
            if (task[i]->state == TASK_RUNNING) 
                // task[i]->counter = rand();
                task[i]->counter = 3;
        }
        for (i=1;i<NR_TASKS;i++){
            // printk("SET ");print_task(task[i]);
        }
    }
    /*遍历线程指针数组task(不包括 idle), 
    在所有运行状态下的线程运行剩余时间最少的线程作为下一个执行的线程。*/
    uint64 selected = 0;
    uint64 select_counter = 0;
    uint64 select_priority = 0;
// 短作业优先调度
#ifdef SJF
    for (i=1;i<NR_TASKS;i++){
        if (task[i]->counter > 0 && task[i]->state == TASK_RUNNING) { //can be selected
            if (selected == 0 || //nothing selected yet
                task[i]->counter < select_counter || //short first
                (task[i]->counter == select_counter && task[i]->priority > select_priority) //same time,high priority first
            ){ 
                selected = i;
                select_counter = task[i]->counter;
                select_priority = task[i]->priority;
            } 
        } 
    }
#endif
// 优先级调度
#ifndef SJF
    for (i=1;i<NR_TASKS;i++){
        if (task[i]->counter > 0 && task[i]->state == TASK_RUNNING) { //can be selected
            if (selected == 0 || //nothing selected yet
                task[i]->priority > select_priority || //high priority first
                (task[i]->priority == select_priority && task[i]->counter < select_counter) //same priority,short time first
            ){ 
                selected = i;
                select_counter = task[i]->counter;
                select_priority = task[i]->priority;
            } 
        } 
    }
#endif

    switch_to(task[selected]);
}

/* 线程切换入口函数*/
void switch_to(struct task_struct* next){
/* 判断下一个执行的线程 next 与当前的线程 current 是否为同一个线程, 如果是同一个线程,
   则无需做任何处理, 否则调用 __switch_to 进行线程切换。 */
    if (current == next){
        ;
    } else {
        // printk("switch to "); print_task(next);
        // 因为调用__switch_to之后不会回来了，所以要先改current
        struct task_struct *tmp = current;
        current = next;
        __switch_to(tmp,next);
    }
}

/* dummy funciton: 一个循环程序, 循环输出自己的 pid 以及一个自增的局部变量 */
void dummy() {
    uint64 MOD = 1000000007;
    uint64 auto_inc_local_var = 0;
    int last_counter = -1;
    while(1) {
        if (last_counter == -1 || current->counter != last_counter) {
            last_counter = current->counter;
            auto_inc_local_var = (auto_inc_local_var + 1) % MOD;
            printk("[PID = %d] is running. thread space begin at 0x%lx\n",
            current->pid, (unsigned long)current);
        }
    }
}

void print_task(struct task_struct* this){
    printk("SET [PID = %d PRIOTITY = %d COUNTER = %d]\n",this->pid,this->priority,this->counter);;
}

static uint64 load_program(uint64 cnt) {
    // printk("task id:%d\n",task[cnt]->pid);
    Elf64_Ehdr *ehdr = (Elf64_Ehdr*)uapp_start;
    uint64 phdr_start = (uint64_t)ehdr+ehdr->e_phoff;
    int phdr_cnt = ehdr->e_phnum;
    Elf64_Phdr *phdr;
    int load_phdr_cnt = 0;
    for (int i = 0; i < phdr_cnt; i++) {
        phdr= (Elf64_Phdr*)(phdr_start + sizeof(Elf64_Phdr) *i);
        if (phdr->p_type == PT_LOAD) {
            // copy the program section to another space 
            uint64 mem_sz = phdr->p_memsz;
            uint64 file_sz = phdr->p_filesz;
            uint64 pg_cnt = get_page_cnt(mem_sz);
            uint64 user_space = alloc_page(pg_cnt);

            uint64 ph_start = (uint64)uapp_start + phdr->p_offset;
            uint64 offset = phdr->p_vaddr & 0xfff;
            memset((char*)user_space, 0, pg_cnt*PGSIZE); 
            memcpy((char*)user_space+offset,(char*)ph_start,file_sz);
            // memset((char*)(user_space + file_sz), 0, mem_sz - file_sz); 
            
            // mapping the program section with corresponding size and flag 
            uint64 va = phdr->p_vaddr;
            
            uint64 pa = user_space - PA2VA_OFFSET;
            uint64 flag = (phdr->p_flags <<1)| 0x11;
            // printk("flag = 0x%lx\n",flag);
            create_mapping((uint64*)(task[cnt]->pgd),va,pa,mem_sz,flag);
            // printk("load_program part %d finish\n",i);
        }  
    }
    // pc for the user program
    task[cnt]->thread.sepc = ehdr->e_entry;
}

uint64 get_page_cnt(uint64 size){
    uint64 cnt = 1;
    uint64 cur = PGSIZE;
    while (cur < size){
        cnt++;
        cur += PGSIZE;
    }
    return cnt;
}