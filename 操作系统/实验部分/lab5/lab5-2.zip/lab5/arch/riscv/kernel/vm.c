#include "defs.h"
#include "mm.h"
#include "string.h"
#include "types.h"
#include "printk.h"
#include "vm.h"

extern char _stext[];
extern char _etext[];
extern char _srodata[];
extern char _erodata[];
extern char _sdata[];
extern char _edata[];

/* early_pgtbl: ⽤于 setup_vm 进⾏ 1GB 的 映射。*/
unsigned long early_pgtbl[512] __attribute__((__aligned__(0x1000)));  //按照八字节对齐
unsigned long swapper_pg_dir[512] __attribute__((__aligned__(0x1000)));

void setup_vm(void) {
    /*
    1. 由于是进⾏ 1GB 的映射 这⾥不需要使⽤多级⻚表
    2. 将 va 的 64bit 作为如下划分： | high bit | 9 bit | 30 bit |
        high bit 可以忽略
        中间9 bit 作为 early_pgtbl 的 index
        低 30 bit 作为 ⻚内偏移 这⾥注意到 30 = 9 + 9 + 12， 
        即我们只使⽤根⻚表， 根⻚表的每个 entry 都对应 1GB 的区域。
    3. Page Table Entry 的权限 V | R | W | X 位设置为 1
    */
    
    //页表值的低十位为状态值，高位为物理地址
    //PTE:page table entry,去掉offset(12位)，给protection bits留位置(10位)
    unsigned long PTE = ((PHY_START >> 12) << 10) | 0x000000000000000f;
    //等值映射地址为物理地址数值，由于低30位为页偏移量
    unsigned long addr_low = (PHY_START >> 30) & 0x1ff;     // 0-8bit = 1
    //高映射地址为PHY+offset
    unsigned long addr_high = (VM_START >> 30) & 0x1ff;
    
    early_pgtbl[addr_low] = PTE;
    early_pgtbl[addr_high] = PTE;
}

/* 创建多级⻚表映射关系 */
void create_mapping(uint64 *pgtbl, uint64 va, uint64 pa, uint64 sz, int perm) {
    /*
    pgtbl 为根⻚表的基地址
    va, pa 为需要映射的虚拟地址、物理地址
    sz 为映射的⼤⼩
    perm 为映射的读写权限，可设置不同section所在⻚的属性，完成对不同section的保护
    创建多级⻚表的时候可以使⽤ kalloc() 来获取⼀⻚作为⻚表⽬录
    可以使⽤ V bit 来判断⻚表项是否存在
    */
    uint64 PTE[3];
    uint64 VPN[3];
    uint64* pgtbl_new[3];
    uint64 va_end = va + sz;
    uint64 cnt = 0;
    // printk("start create_map,pa:0x%lx,va:0x%lx,len:%d\n",pa,va,sz);
    while (va < va_end){
        
        uint64* page;
        VPN[0] = (va >> 12) & 0x1ff;
        VPN[1] = (va >> 21) & 0x1ff;
        VPN[2] = (va >> 30) & 0x1ff;

        //三级页表的低地址为我们传入的pgtbl
        pgtbl_new[2] = pgtbl;
        PTE[2] = pgtbl_new[2][VPN[2]];
        if (!(PTE[2] & 1)){       //判断页表值中的valid位是否为1
            //生成的page值为我们的虚拟存储地址
            page = (uint64*)kalloc();       //注意一定要加入类型转换！
            cnt = cnt + 1;
            
            //需要转换成物理地址之后存入,同时设置valid位为1
            PTE[2] = ((((uint64)page - PA2VA_OFFSET) >> 12) << 10) | 1;
            pgtbl_new[2][VPN[2]] = PTE[2];
        }

        //二级页表的低地址为存储在三级页表中的值
        pgtbl_new[1] = (uint64*)(((PTE[2] >> 10) << 12) + PA2VA_OFFSET);
        PTE[1] = pgtbl_new[1][VPN[1]];
        if (!(PTE[1] & 1)){       //判断页表值中的valid位是否为1
            //生成的page值为我们的虚拟存储地址
            page = (uint64*)kalloc();       //!!!
            cnt = cnt + 1;
            //需要转换成物理地址之后存入,同时设置valid位为1
            PTE[1] = ((((uint64)page - PA2VA_OFFSET) >> 12) << 10) | 1;
            pgtbl_new[1][VPN[1]] = PTE[1];
        }

        //一级页表的低地址为存储在二级页表中的值
        pgtbl_new[0] = (uint64*)(((PTE[1] >> 10) << 12) + PA2VA_OFFSET);
        //一级页表中存储的是我们的实际物理地址，包括读写权限
        PTE[0] = ((pa >> 12) << 10) | (perm & 31);
        pgtbl_new[0][VPN[0]] = PTE[0];

        va += PGSIZE; pa += PGSIZE;
    }
    // printk("create_map success,page_cnt:%d\n",cnt);
    return;
}

void setup_vm_final(void) {
    memset(swapper_pg_dir, 0x0, PGSIZE);
    // No OpenSBI mapping required
    // mapping kernel text X|-|R|V
    create_mapping((uint64*)swapper_pg_dir, (uint64)_stext, (uint64)(_stext-PA2VA_OFFSET),
        (uint64)(_etext - _stext), 0xb);
    // mapping kernel rodata -|-|R|V
    create_mapping((uint64*)swapper_pg_dir, (uint64)_srodata, (uint64)(_srodata-PA2VA_OFFSET),
        (uint64)(_erodata - _srodata), 0x3);
    // mapping other memory -|W|R|V
    // 此处不使用_edata，由于物理页较大
    create_mapping((uint64*)swapper_pg_dir, (uint64)_sdata, (uint64)(_sdata-PA2VA_OFFSET),
        PHY_END + PA2VA_OFFSET - (uint64)_sdata,  0x7);
    // set satp with swapper_pg_dir
    // 此处仍然为satp寄存器存储格式，模式号为8
    uint64 _satp = 0x8000000000000000 | (((uint64)swapper_pg_dir - PA2VA_OFFSET) >> 12);
    csr_write(satp, _satp);

    // flush TLB
    asm volatile("sfence.vma zero, zero");
    
    return;
}
