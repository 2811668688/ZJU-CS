#include "sbi.h"
#include "clock.h"
unsigned long TIMECLOCK = 10000000;

unsigned long get_cycles() {
    // 使⽤ rdtime 编写内联汇编，获取 time 寄存器中 (也就是mtime 寄存器 )的值并返回
    unsigned long ti;
    asm volatile("rdtime %0" : "=r"(ti));
    return ti;
}

void clock_set_next_event() {
    // 下⼀次 时钟中断 的时间点
    unsigned long next = get_cycles() + TIMECLOCK;
    // 使⽤ sbi_ecall 来完成对下⼀次时钟中断的设置
    sbi_ecall(SBI_SETTIMER, 0, next, 0, 0, 0, 0, 0);
}