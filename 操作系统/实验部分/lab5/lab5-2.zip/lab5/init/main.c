#include "printk.h"
#include "sbi.h"
#include "proc.h"

extern char _stext[];
extern char _etext[];
extern char _srodata[];
extern char _erodata[];
extern char _sdata[];
extern char _edata[];
extern void test();

int start_kernel() {
    printk("Hello RISC-V\n");
    schedule();
    test(); // DO NOT DELETE !!!

	return 0;
}
