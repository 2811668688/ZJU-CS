#include "printk.h"
#include "defs.h"

// Please do not modify

void test() {
    while (1){
	int i = 0;
	for(i = 0;i < 10000000;i++){
	}
    }
}
