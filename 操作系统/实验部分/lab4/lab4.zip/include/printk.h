#pragma once

#include "stddef.h"

int printk(const char *, ...);
