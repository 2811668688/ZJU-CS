#include "types.h"

#define SEED 5
uint64 rand();
