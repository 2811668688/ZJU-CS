#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<time.h>
#define WATER_SHED 20
#define ROW_TIMES 12
#define MAX 1200 
typedef struct node* Huffnode;
struct node{
	int value;
	Huffnode Left;
	Huffnode Right;
}Heap[MAX]; 
Huffnode Root;
int Size,N,M,wpl;//Size of the Heap
int value[MAX];
int ch[MAX];
int row;
double start_time[ROW_TIMES];
double end_time[ROW_TIMES];
void Insert(struct node X);//Insert one node into the heap
struct node FindMin();//Get the first one in the heap
struct node DeleteMin();//Delete the first ond of the heap
int WPL(Huffnode Node,int dep);//Get the WPL
int check(Huffnode Root);//tell whether we habe the right answer
Huffnode BuildHuffman();
void Input_rest(int cnt);
void START();
void END();

/*----------------------------------------
�����Ҿ��ÿ��Կ��ǵķ��� 
ʱ�䷽�棺1.�����ֻ�ܿ����Ż���������check�ڣ��ǲ���flag=0��Ҳ����֪������������ܵ�ʱ��ֱ�����������������ݣ��Ͳ���������ж���
		  2.�Ƿ����һ����Ķѣ�������ʵ���������ǲ����ɾ��
�ռ䷽�棺1. Huffman Tree��������wplֵ�ģ��ǲ��ǿ��Ժ���ֱ��free��
*/ 
	 		
int main()
{
	for(row = 0; row<ROW_TIMES; row++){
	scanf("%d",&N);
	getchar();
//	START();
	for (int i=0; i<N; i++)
	{
		scanf("%d %d",&ch[i],&value[i]);
//		getchar();
//		getchar();
		struct node tmp;
		tmp.value=value[i];
		tmp.Left=tmp.Right=NULL;
		Insert(tmp);//�Ȱ�����Ԫ�ز��뽨��һ���� 
	}
	Root=BuildHuffman();//ͨ���ѵķ���������һ��Huffman�� 
//	printf("The time for building heap is: ");
//	END();
	scanf("%d",&M);
	START();
	for (int i=0; i<M; i++)
	{
		if (check(Root))
			printf("Yes\n");
		else printf("No\n"); 
	}
//	printf("The time for checking correctness is:");
	END();
	}
	double avg_time = 0;
	for(int col = 2; col<ROW_TIMES; col++)
	{
		printf("<%d> %lf s\n", col-2, (end_time[col]-start_time[col])/1000);
		avg_time += (end_time[col]-start_time[col])/1000;
	}
	printf("The avg time for checking correctness is %lf s", avg_time/(ROW_TIMES-2));
	return 0;
}
void FREE(Huffnode T)
{
	if (T->Left!=NULL)
	  FREE(T->Left);
	if (T->Right!=NULL)
	  FREE(T->Right);
	free(T);
}
int check(Huffnode Root)
{
	int flag = 1;
	int ans = 0;	
	int c;
	char cc[MAX];
	int tmpvalue=0,j,i; 
	if(1) //N�ֽ�ʹ�ý�������
	{
		/*--------------------------------*/
		Huffnode T,tmpnode;//�������ķ�������һ���� 
		T=(Huffnode)(malloc(sizeof(struct node)));
		T->Left=T->Right=NULL;
		T->value=0;
		for (i=0; i<N; i++)
		{
			scanf("\n%d %s",&c,cc);
			if (strlen(cc)>=N) 
			{
//				Input_rest(N-i-1);
//				return 0;	
				flag = 0;
			}
			else 
			{
				for (j=0; c!=ch[j] && j<N; j++);
				if (j>=N) 
				{
//					Input_rest(N-i-1);
//					return 0;
					flag = 0;	
				}
				tmpvalue=value[j];
				tmpnode=T;
				for (j=0; j<strlen(cc); j++)
				{
					if (cc[j]=='0')
					{
						if (tmpnode->Left==NULL)//������� 
						{
							Huffnode a=Huffnode(malloc(sizeof(struct node)));
							a->Left=a->Right=NULL;
							a->value=0; 
							tmpnode->Left=a;
						}
						tmpnode=tmpnode->Left;
					}	
					else if (cc[j]=='1')//���ұ��� 
					{
						if (tmpnode->Right==NULL)
						{
							Huffnode a=Huffnode(malloc(sizeof(struct node)));
							a->Left=a->Right=NULL;
							a->value=0; 
							tmpnode->Right=a;
						}
						tmpnode=tmpnode->Right;
					}
					if (tmpnode->value) //��Ϊÿ������Ľ����Ҫ��ֵ�ģ�����·�ϵ�ÿ���㶼�������Ѿ�����ֵ�ĵ� 
					{
//						Input_rest(N-i-1);
//						return 0;	
						flag = 0;
					}
				}
				if(tmpnode->Left || tmpnode->Right)
				{
//					Input_rest(N-i-1);
//					return 0;
					flag = 0;	
				}//����������Ҷ�� 
				else
					tmpnode->value=tmpvalue;//����ڵ����Ȩ��
			}
					ans+=strlen(cc)*tmpnode->value;
		}
		FREE(T);
	/*--------------------------------*/
	} 

	else
	{
		/*--------------------------------*/
		//ʹ���ַ����ж� 
		int code_c;
		char huff_code[MAX][MAX];
		int k;
		for (int i = 0; i<N; i++)
		{
			scanf("\n%d %s", &code_c, huff_code[i]);
			if (strlen(huff_code[i])>=N)
			{
				Input_rest(N-i-1);
				return 0;	
			}
			else
			{
				for (k=0; code_c!=ch[k] && k<N; k++);
				if (k>=N) 
				{
					Input_rest(N-i-1);
					return 0;
				}
				for(int j = 0; j<i; j++) 
				{
					if(strlen(huff_code[i])<=strlen(huff_code[j]) && strstr(huff_code[j], huff_code[i])==huff_code[j])
					{
//						Input_rest(N-i-1);
//						return 0;
						flag = 0;
					}
				}
				ans+=strlen(huff_code[i])*value[k];
			} 
		}
	}
	/*--------------------------------*/
	
	if (flag==0) return 0;
	if (ans!=wpl) return 0;
        return 1;
}

struct node DeleteMin() 
{
    int Child,i; 
    struct node MinElement,LastElement; 
    MinElement=Heap[1];  /* save the min element */
    LastElement=Heap[Size--];  /* take last and reset size */
    for (i=1; i*2<=Size; i=Child) 
	{  /* Find smaller child */ 
         Child=i*2; 
         if (Child!=Size && (Heap[Child+1].value<Heap[Child].value)) 
	       Child++;     
         if (LastElement.value>Heap[Child].value)   /* Percolate one level */ 
	       Heap[i]=Heap[Child]; 
         else break;   /* find the proper position */
    } 
    Heap[i]=LastElement; 
    return MinElement; 
}
void Insert(struct node X) 
{
     int k;//The size
     for (k=++Size; Heap[k/2].value>X.value; k/=2) 
	 Heap[k]=Heap[k/2]; //find the position
     Heap[k]=X; 
}
struct node FindMin()
{
	return Heap[1];//Just return
}
Huffnode BuildHuffman()
{
	int tmpp=Size;
	for (int i=1; i<tmpp; i++)
	{
		struct node tmp,a,b;
		Huffnode Node;
		a=DeleteMin();
		b=DeleteMin();
		wpl=wpl+a.value+b.value;
		Node=(Huffnode)malloc(sizeof(struct node));
		Node->Left=a.Left; Node->Right=a.Right; Node->value=a.value;
		tmp.Left=Node;
		Node=(Huffnode)malloc(sizeof(struct node));
		Node->Left=b.Left; Node->Right=b.Right; Node->value=b.value;
		tmp.Right=Node;
		tmp.value=tmp.Left->value+tmp.Right->value;
		Insert(tmp);
	}
	struct node a=DeleteMin();
	Huffnode Node=(Huffnode)malloc(sizeof(struct node));
	Node->Left=a.Left; Node->Right=a.Right; Node->value=a.value;
	return (Node);
} 

void Input_rest(int cnt)
{
	int c;
	char cc[MAX];
	int v;
	for(int i = 0; i<cnt; i++)
		scanf("\n%d %s",&c,cc); 
}

void START()
{
	start_time[row] = clock();
}
void END()
{
	end_time[row] = clock();
	
//	printf("%lf s\n", (end_time[row]-start_time[row])/1000);
}
