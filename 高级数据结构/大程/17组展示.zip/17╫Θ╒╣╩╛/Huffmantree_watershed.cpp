#include<stdio.h>
#include<string.h>
#include<stdlib.h>

#define WATER_SHED 20


typedef struct node* Huffnode;
struct node{//when we build a Huffman Tree with the students' answer,we need this 
	int value;
	Huffnode Left;
	Huffnode Right;
}; 
int Size,N,M,wpl;//Size of the Heap
int value[70],Heap[70];//value and ch records the information of every input
char ch[70];

void Insert(int X);//Insert one node into the heap
int FindMin();//Get the first one in the heap
int DeleteMin();//Delete the first ond of the heap
int check();//tell whether we habe the right answer
void BuildHuffman();//Build the HuffmanTree with the request
void Input_rest(int cnt);
	
int main()
{
	scanf("%d",&N);
	for (int i=0; i<N; i++)
	{
		getchar();
		scanf("%c %d",&ch[i],&value[i]);//read all the information we need
		Insert(value[i]);//put it into the heap
	}
	BuildHuffman();//get the wpl value
	scanf("%d",&M);//read the information
	for (int i=0; i<M; i++)
	{
		if (check())//check whether we can get a right answer
			printf("Yes\n");
		else printf("No\n"); 
	}
	return 0;
}
void FREE(Huffnode T)//Free
{
	if (T->Left!=NULL)//if the left subtree is not null,free it
	  FREE(T->Left);
	if (T->Right!=NULL)//if the right subtree is not null,free it
	  FREE(T->Right);
	free(T);
}
int check()
{	
	char c,cc[100];
	int tmpvalue=0,j,i,ans=0,flag=1; 
	if(N>WATER_SHED) //decide we use which way to check
	{
		Huffnode T,tmpnode;//Build an Huffman tree
		T=(Huffnode)(malloc(sizeof(struct node)));
		T->Left=T->Right=NULL;
		T->value=0;//set the head node
		for (i=0; i<N; i++)
		{
			if (!flag) break;//if we have known the answer is false,we only need to pass 
			scanf("\n%c %s",&c,cc);
			if (strlen(cc)>=N)//if the depth of the node is unavailable 
				break;
			else 
			{
				for (j=0; c!=ch[j] && j<N; j++);
				if (j>=N) flag=0;
				tmpvalue=value[j];
				tmpnode=T;//find the node
				for (j=0; j<strlen(cc); j++)
				{
					if (cc[j]=='0')//search in the left subtree
					{
						if (tmpnode->Left==NULL)//not have a node,add one
						{
							Huffnode a=Huffnode(malloc(sizeof(struct node)));//add one node
							a->Left=a->Right=NULL;
							a->value=0; 
							tmpnode->Left=a;
						}
						tmpnode=tmpnode->Left;//change in the left subtree
					}	
					else if (cc[j]=='1')//search in the right subtree
					{
						if (tmpnode->Right==NULL)//not have a node,add one
						{
							Huffnode a=Huffnode(malloc(sizeof(struct node)));//add one node
							a->Left=a->Right=NULL;
							a->value=0; 
							tmpnode->Right=a;
						}
						tmpnode=tmpnode->Right;//change in the right subtree
					}
					if (tmpnode->value) //if the node has one value,means it is a leaf node,false 
						flag=0;
				}
				if(tmpnode->Left || tmpnode->Right)
					flag=0;//when we need to get the leaf a value,if it is not a leaf node
				else
					tmpnode->value=tmpvalue;//five the leaf the value
			}
					ans+=strlen(cc)*tmpnode->value;//get the wpl value
		}
		for (; i<N; i++)
			scanf("\n%c %s",&c,cc);
		FREE(T);
	} 
	else //Use string to judge the legitimacy of students'code
	{
		char code_c;
		char huff_code[100][100];
		int k;
		for (int i = 0; i<N; i++)  
		{
			scanf("\n%c %s", &code_c, huff_code[i]);  
			if (strlen(huff_code[i])>=N) //if the depth of the node is unavailable 
			{
				Input_rest(N-i-1); //take in the rest input
				return 0;	
			}
			else
			{
				for (k=0; code_c!=ch[k] && k<N; k++);  //find the position of code_c in ch[]
				if (k>=N) 
				{
					Input_rest(N-i-1); //take in the rest input
					return 0;
				}
				for(int j = 0; j<i; j++) //compare with the stored string 
				{
					if(strlen(huff_code[i])<=strlen(huff_code[j]) && strstr(huff_code[j], huff_code[i])==huff_code[j])
					{
						Input_rest(N-i-1);
						return 0;
					}
				} 
				ans+=strlen(huff_code[i])*value[k]; //adjust the wpl of the huff_tree 
			} 
		}
	}
	if (flag==0) return 0; 
	if (ans!=wpl) return 0; //if wpl != ans 
        return 1;
}

int DeleteMin() 
{
    int Child,i; 
    int MinElement,LastElement; 
    MinElement=Heap[1];  /* save the min element */
    LastElement=Heap[Size--];  /* take last and reset size */
    for (i=1; i*2<=Size; i=Child) 
	{  /* Find smaller child */ 
         Child=i*2; 
         if (Child!=Size && (Heap[Child+1]<Heap[Child])) 
	       Child++;     
         if (LastElement>Heap[Child])   /* Percolate one level */ 
	       Heap[i]=Heap[Child]; 
         else break;   /* find the proper position */
    } 
    Heap[i]=LastElement; 
    return MinElement; 
}
void Insert(int X) 
{
     int k;//The size
     for (k=++Size; Heap[k/2]>X; k/=2) 
	 Heap[k]=Heap[k/2]; //find the position
     Heap[k]=X; 
}
int FindMin()
{
	return Heap[1];//Just return
}
void BuildHuffman()//To get the wpl
{
	int tmpp=Size;
	for (int i=1; i<tmpp; i++)//we need to do N-1 times
	{
		int a,b;
		a=DeleteMin();
		b=DeleteMin();
		wpl=wpl+a+b;
		Insert(a+b);
	}
} 

void Input_rest(int cnt)
{
	char c;
	char cc[100];
	int v;
	for(int i = 0; i<cnt; i++)
		scanf("\n%c %s",&c,cc); 
}
